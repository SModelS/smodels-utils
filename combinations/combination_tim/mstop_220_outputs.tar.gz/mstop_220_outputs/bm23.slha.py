smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-16-033,ATLAS-SUSY-2016-07,ATLAS-SUSY-2019-09,CMS-SUS-13-012,ATLAS-SUSY-2013-02',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm23.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.464993,
        'upper limit (fb)' : 4.1,
        'expected upper limit (fb)' : 3.72,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-/N2', 214.84),
            ('C1+/C1-', 214.8),
            ('N1/N1~', 174.7)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR3_Njet5_Nb0_HT500_MHT_500',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 1.089023,
        'r_expected' : 1.200267,
        'Width (GeV)' : [
            ('C1-/N2', 5.0882e-05),
            ('C1+/C1-', 5.0715e-05),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 6.869073e-06,
        'l_max' : 9.755716e-05,
        'l_SM' : 9.555076e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.600094,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 174.7),
            ('N1', 174.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.7373707,
        'r_expected' : 0.7583386,
        'Width (GeV)' : [
            ('C1-', 5.0715e-05),
            ('C1+', 5.0715e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 9.11775e-05,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.09721427,
        'upper limit (fb)' : 0.2308611,
        'expected upper limit (fb)' : 0.2460852,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4210942,
        'r_expected' : 0.3950432,
        'Width (GeV)' : None,
        'likelihood' : 2.622546e-38,
        'l_max' : 4.4270760000000007e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3130468,
        'upper limit (fb)' : 1.34,
        'expected upper limit (fb)' : 0.833,
        'TxNames' : ['T1bbbb', 'T6bbWWoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_600MHTinf',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.233617,
        'r_expected' : 0.3758065,
        'Width (GeV)' : None,
        'likelihood' : 0.00496817,
        'l_max' : 0.005396484,
        'l_SM' : 0.002530291
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07139365,
        'upper limit (fb)' : 0.43344,
        'expected upper limit (fb)' : 0.33172,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 174.7),
            ('N1', 174.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR3j',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.164714,
        'r_expected' : 0.2152226,
        'Width (GeV)' : [
            ('C1-', 5.0715e-05),
            ('C1+', 5.0715e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.04862163,
        'l_max' : 0.04953626,
        'l_SM' : 0.03774128
    },
    {
        'maxcond' : 1.3719780277696408e-06,
        'theory prediction (fb)' : 0.0834759,
        'upper limit (fb)' : 0.813,
        'expected upper limit (fb)' : 1.19,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 174.7),
            ('N1', 174.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-SF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1026764,
        'r_expected' : 0.07014782,
        'Width (GeV)' : [
            ('C1-', 5.0715e-05),
            ('C1+', 5.0715e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001060581,
        'l_max' : 0.001267591,
        'l_SM' : 0.001267591
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01171128,
        'upper limit (fb)' : 0.2957342,
        'expected upper limit (fb)' : 0.5765561,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.03960069,
        'r_expected' : 0.02031247,
        'Width (GeV)' : None,
        'likelihood' : 9.840795000000002e-33,
        'l_max' : 1.0786820000000003e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02287417,
        'upper limit (fb)' : 0.7154384,
        'expected upper limit (fb)' : 0.8554646,
        'TxNames' : ['TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.03197224,
        'r_expected' : 0.02673888,
        'Width (GeV)' : None,
        'likelihood' : 0.111479,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04206127,
        'upper limit (fb)' : 1.568893,
        'expected upper limit (fb)' : 1.140414,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 220.6),
            ('C1+/C1-', 214.8),
            ('N1', 174.7),
            ('N1/N1~', 174.7)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.02680951,
        'r_expected' : 0.03688245,
        'Width (GeV)' : [
            ('N2', 7.6748e-05),
            ('C1+/C1-', 5.0715e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.611539090425739e-72,
        'l_max' : 7.028815247787728e-72,
        'l_SM' : 4.2441968280750914e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001707382,
        'upper limit (fb)' : 1.411607,
        'expected upper limit (fb)' : 1.07434,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 220.6),
            ('C1+/C1-', 214.8),
            ('N1', 174.7),
            ('N1/N1~', 174.7)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.001209531,
        'r_expected' : 0.001589238,
        'Width (GeV)' : [
            ('N2', 7.6748e-05),
            ('C1+/C1-', 5.0715e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.7658500000000006e-20,
        'l_max' : 3.2156220000000003e-20,
        'l_SM' : 2.7600510000000006e-20
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-02,ATLAS-SUSY-2016-07,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033',
        'r' : 1.37901,
        'r_expected' : 1.679109,
        'likelihood' : 3.9676647148799955e-51,
        'l_max' : 1.4107355710668715e-49,
        'l_SM' : 1.2071312588033803e-49
    }
],
'Total xsec for missing topologies (fb)' : 6234.023,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3868.945,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1287.974,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 340.2888,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 319.6817,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 163.5726,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 40.35018,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 39.64443,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 24.2173,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.03024,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 16.32467,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 6234.023,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3868.945,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1287.974,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 340.2888,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 319.6817,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 163.5726,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 40.35018,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 39.64443,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 24.2173,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.03024,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 16.32467,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7475.789,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7453.556,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.53195,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.31921,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2124387,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.08456681,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04289124,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02129165,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02052215,
        'SMS' : 'PV > (b,b,MET), (b,b,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,ATLAS-SUSY-2013-04',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm521.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.170099,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.8667401,
        'r_expected' : 1.147156,
        'Width (GeV)' : None,
        'likelihood' : 0.0008354235,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8178052,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.2,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.5),
            ('su_L', 220.5),
            ('C1-', 141.2),
            ('C1+', 141.2),
            ('N1~', 54.7),
            ('N1', 54.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_1bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.6057816,
        'r_expected' : 0.6815044,
        'Width (GeV)' : [
            ('su_L~', 1.18570903),
            ('su_L', 1.18570903),
            ('C1-', 0.0127633622),
            ('C1+', 0.0127633622),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001393759,
        'l_max' : 0.002394811,
        'l_SM' : 0.002264688
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0519385,
        'upper limit (fb)' : 0.518,
        'expected upper limit (fb)' : 0.555,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 141.2),
            ('C1+', 141.2),
            ('N1~', 54.7),
            ('N1', 54.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWb-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1002674,
        'r_expected' : 0.09358289,
        'Width (GeV)' : [
            ('C1-', 0.0127633622),
            ('C1+', 0.0127633622),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01345418,
        'l_max' : 0.01441039,
        'l_SM' : 0.01441039
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06577389,
        'upper limit (fb)' : 1.015111,
        'expected upper limit (fb)' : 0.7475415,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 141.2),
            ('C1+', 141.2),
            ('N1~', 54.7),
            ('N1', 54.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-02',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.06479477,
        'r_expected' : 0.08798694,
        'Width (GeV)' : [
            ('C1-', 0.0127633622),
            ('C1+', 0.0127633622),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.682841e-40,
        'l_max' : 3.679128e-40,
        'l_SM' : 2.291911e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0001072767,
        'upper limit (fb)' : 0.024,
        'expected upper limit (fb)' : 0.0264,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 141.2),
            ('N2', 148.7),
            ('N1/N1~', 54.7),
            ('N1', 54.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : 'SRWZ_16',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.004469861,
        'r_expected' : 0.00406351,
        'Width (GeV)' : [
            ('C1+/C1-', 0.012763),
            ('N2', 0.0017078),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.5227029,
        'l_max' : 0.5244628,
        'l_SM' : 0.5244628
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,CMS-SUS-13-012',
        'r' : 1.116602,
        'r_expected' : 1.480063,
        'likelihood' : 1.164379e-06,
        'l_max' : 9.304131e-06,
        'l_SM' : 6.837721e-06
    }
],
'Total xsec for missing topologies (fb)' : 2341.971,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1609.575,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 443.0853,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 241.1271,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 42.1986,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.09343,
        'SMS' : 'PV > (Z,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9747775,
        'SMS' : 'PV > (W,W,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.7192815,
        'SMS' : 'PV > (Z,MET), (W,higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4923837,
        'SMS' : 'PV > (Z,W,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4825193,
        'SMS' : 'PV > (Z,higgs,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3349237,
        'SMS' : 'PV > (W,higgs,MET), (W,W,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 2341.971,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1609.575,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 443.0853,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 241.1271,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 42.1986,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.09343,
        'SMS' : 'PV > (Z,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9747775,
        'SMS' : 'PV > (W,W,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.7192815,
        'SMS' : 'PV > (Z,MET), (W,higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4923837,
        'SMS' : 'PV > (Z,W,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4825193,
        'SMS' : 'PV > (Z,higgs,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3349237,
        'SMS' : 'PV > (W,higgs,MET), (W,W,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.02394528,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02394528,
        'SMS' : 'PV > (W,MET), (Z,MET)'
    }
]
}
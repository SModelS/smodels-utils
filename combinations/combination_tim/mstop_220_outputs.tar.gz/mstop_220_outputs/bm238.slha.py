smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,CMS-SUS-13-012,CMS-SUS-16-039-agg,ATLAS-SUSY-2019-09',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm238.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.040061,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 123.6),
            ('N1', 123.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 3.554113,
        'r_expected' : 3.157989,
        'Width (GeV)' : [
            ('C1-', 0.0210507881),
            ('C1+', 0.0210507881),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 3.250495e-10,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.7776772,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.5760572,
        'r_expected' : 0.7624287,
        'Width (GeV)' : None,
        'likelihood' : 0.002477938,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.6972555,
        'upper limit (fb)' : 2.236724,
        'expected upper limit (fb)' : 1.329274,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N3', 227.0),
            ('N1/N1~', 123.6),
            ('N1', 123.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.3117306,
        'r_expected' : 0.5245386,
        'Width (GeV)' : [
            ('C1+/C1-', 0.021051),
            ('N3', 0.0069318),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 9.851973000000002e-20,
        'l_max' : 1.1189670000000002e-19,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07041928,
        'upper limit (fb)' : 0.3336223,
        'expected upper limit (fb)' : 0.2388439,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2110748,
        'r_expected' : 0.2948339,
        'Width (GeV)' : None,
        'likelihood' : 1.815613e-24,
        'l_max' : 1.924525e-24,
        'l_SM' : 1.2066700000000002e-24
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg',
        'r' : 3.136229,
        'r_expected' : 3.3715,
        'likelihood' : 1.4407424398594927e-55,
        'l_max' : 8.875785581337692e-49,
        'l_SM' : 8.728843125794923e-49
    }
],
'Total xsec for missing topologies (fb)' : 123.0004,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 69.52218,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 53.47818,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 123.0004,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 69.52218,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 53.47818,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}
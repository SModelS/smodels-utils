smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,CMS-SUS-16-039-agg,CMS-SUS-13-012,ATLAS-SUSY-2016-24',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm342.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.745563,
        'upper limit (fb)' : 0.518,
        'expected upper limit (fb)' : 0.555,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 114.6),
            ('N1', 114.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWb-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 3.369812,
        'r_expected' : 3.145158,
        'Width (GeV)' : [
            ('C1-', 0.033573455),
            ('C1+', 0.033573455),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.676714e-09,
        'l_max' : 0.01441039,
        'l_SM' : 0.01441039
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.563632,
        'upper limit (fb)' : 2.355862,
        'expected upper limit (fb)' : 1.471874,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6637196,
        'r_expected' : 1.062341,
        'Width (GeV)' : None,
        'likelihood' : 6.836262000000001e-20,
        'l_max' : 8.712048000000001e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.7572087,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.8),
            ('su_L', 220.8),
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 114.6),
            ('N1', 114.6)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.5608954,
        'r_expected' : 0.7423615,
        'Width (GeV)' : [
            ('su_L~', 0.0195118474),
            ('su_L', 0.0195118474),
            ('C1-', 0.033573455),
            ('C1+', 0.033573455),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.00257788,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02019932,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.127,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2/N3', 220.65),
            ('N1/N1~', 114.6),
            ('N1', 114.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.2244369,
        'r_expected' : 0.1590497,
        'Width (GeV)' : [
            ('C1+/C1-', 0.033573),
            ('N2/N3', 0.012981),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1316472,
        'l_max' : 0.2014847,
        'l_SM' : 0.2014847
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0001622978,
        'upper limit (fb)' : 0.02559,
        'expected upper limit (fb)' : 0.02389,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2', 218.0),
            ('N1/N1~', 114.6),
            ('N1', 114.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : 'SRWZ_8',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.006342233,
        'r_expected' : 0.006793543,
        'Width (GeV)' : [
            ('C1+/C1-', 0.033573),
            ('N2', 0.017039),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.361491,
        'l_max' : 0.3669067,
        'l_SM' : 0.3599571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.003413306,
        'upper limit (fb)' : 0.5687,
        'expected upper limit (fb)' : 0.5188,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2/N3', 220.76),
            ('N1/N1~', 114.6),
            ('N1', 114.6)
        ],
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : 'H_SR1',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.006001944,
        'r_expected' : 0.006579232,
        'Width (GeV)' : [
            ('C1+/C1-', 0.033573),
            ('N2/N3', 0.012808),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002416558,
        'l_max' : 0.0002466202,
        'l_SM' : 0.0002410039
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2016-24,CMS-SUS-13-012,CMS-SUS-16-039-agg',
        'r' : 3.10015,
        'r_expected' : 3.605904,
        'likelihood' : 6.210048000000001e-32,
        'l_max' : 2.598376e-25,
        'l_SM' : 2.4195690000000004e-25
    }
],
'Total xsec for missing topologies (fb)' : 82.92218,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 61.52293,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 21.39925,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 82.92218,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 61.52293,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 21.39925,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2016-07,CMS-SUS-16-033,ATLAS-SUSY-2019-09,ATLAS-SUSY-2013-02,CMS-SUS-13-012',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm195.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.986857,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 161.6),
            ('N1', 161.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.9156025,
        'r_expected' : 0.9416386,
        'Width (GeV)' : [
            ('C1-', 0.00012331),
            ('C1+', 0.00012331),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 4.680809e-05,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.50804,
        'upper limit (fb)' : 4.1,
        'expected upper limit (fb)' : 3.72,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 161.6),
            ('N1', 161.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR3_Njet5_Nb0_HT500_MHT_500',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.8556195,
        'r_expected' : 0.9430215,
        'Width (GeV)' : [
            ('C1-', 0.00012331),
            ('C1+', 0.00012331),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.046289e-05,
        'l_max' : 9.755716e-05,
        'l_SM' : 9.555076e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1930417,
        'upper limit (fb)' : 0.311779,
        'expected upper limit (fb)' : 0.3025376,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.619162,
        'r_expected' : 0.638075,
        'Width (GeV)' : None,
        'likelihood' : 2.201383e-38,
        'l_max' : 4.4441740000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1690713,
        'upper limit (fb)' : 0.43344,
        'expected upper limit (fb)' : 0.33172,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 161.6),
            ('N1', 161.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR3j',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.3900685,
        'r_expected' : 0.5096807,
        'Width (GeV)' : [
            ('C1-', 0.00012331),
            ('C1+', 0.00012331),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.04433165,
        'l_max' : 0.04953626,
        'l_SM' : 0.03774128
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3574195,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.5),
            ('su_L', 220.5),
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 161.6),
            ('N1', 161.6)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.2647552,
        'r_expected' : 0.3504112,
        'Width (GeV)' : [
            ('su_L~', 0.017763),
            ('su_L', 0.017763),
            ('C1-', 0.00012331),
            ('C1+', 0.00012331),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003881965,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 1.5329823972426474e-06,
        'theory prediction (fb)' : 0.09241597,
        'upper limit (fb)' : 1.07,
        'expected upper limit (fb)' : 1.17,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 161.6),
            ('N1', 161.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.08637007,
        'r_expected' : 0.07898801,
        'Width (GeV)' : [
            ('C1-', 0.00012331),
            ('C1+', 0.00012331),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002151121,
        'l_max' : 0.002291271,
        'l_SM' : 0.002291271
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.003459757,
        'upper limit (fb)' : 0.0411,
        'expected upper limit (fb)' : 0.0604,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2', 217.7),
            ('N1/N1~', 161.6),
            ('N1', 161.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SROffShell_1_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.084179,
        'r_expected' : 0.05728074,
        'Width (GeV)' : [
            ('C1+/C1-', 0.00012331),
            ('N2', 0.00016107),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01995347,
        'l_max' : 0.02305062,
        'l_SM' : 0.02305062
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.09455577,
        'upper limit (fb)' : 1.650566,
        'expected upper limit (fb)' : 1.191722,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.05728688,
        'r_expected' : 0.07934384,
        'Width (GeV)' : None,
        'likelihood' : 4.901894962902058e-72,
        'l_max' : 6.48648392236768e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001060227,
        'upper limit (fb)' : 0.282,
        'expected upper limit (fb)' : 0.252,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2', 217.7),
            ('N1/N1~', 161.6),
            ('N1', 161.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : 'stop_highMET_PT_12to20',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.003759669,
        'r_expected' : 0.004207248,
        'Width (GeV)' : [
            ('C1+/C1-', 0.00012331),
            ('N2', 0.00016107),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.02425839,
        'l_max' : 0.02506577,
        'l_SM' : 0.02419324
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002654905,
        'upper limit (fb)' : 1.525771,
        'expected upper limit (fb)' : 0.7491514,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.001740041,
        'r_expected' : 0.003543883,
        'Width (GeV)' : None,
        'likelihood' : 2.8149080000000003e-20,
        'l_max' : 1.7983760000000002e-19,
        'l_SM' : 2.7600510000000006e-20
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-02,ATLAS-SUSY-2016-07,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033',
        'r' : 1.414672,
        'r_expected' : 1.735488,
        'likelihood' : 3.6286831204041465e-51,
        'l_max' : 1.7523963392755005e-49,
        'l_SM' : 1.4404129512748844e-49
    }
],
'Total xsec for missing topologies (fb)' : 6219.167,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3864.294,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1283.707,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 360.634,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 319.8001,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 163.8171,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.37525,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 29.99458,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.12026,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.81382,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 17.15667,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 6219.167,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3864.294,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1283.707,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 360.634,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 319.8001,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 163.8171,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.37525,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 29.99458,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.12026,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.81382,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 17.15667,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7481.472,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7395.182,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.87678,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 34.0845,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.459815,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.257407,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5958904,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01495055,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,CMS-SUS-16-039-agg,ATLAS-SUSY-2013-04',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm347.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.901988,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.6681393,
        'r_expected' : 0.884302,
        'Width (GeV)' : None,
        'likelihood' : 0.001877528,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.422439,
        'upper limit (fb)' : 2.36576,
        'expected upper limit (fb)' : 1.419738,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6012609,
        'r_expected' : 1.001903,
        'Width (GeV)' : None,
        'likelihood' : 9.587473000000002e-20,
        'l_max' : 1.0630280000000001e-19,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2841788,
        'upper limit (fb)' : 1.04,
        'expected upper limit (fb)' : 1.23,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 114.0),
            ('N1', 114.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_2ibjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.2732489,
        'r_expected' : 0.2310397,
        'Width (GeV)' : [
            ('su_L~', 0.0458559973),
            ('su_L', 0.0458559973),
            ('C1-', 0.0243239624),
            ('C1+', 0.0243239624),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001492687,
        'l_max' : 0.002115684,
        'l_SM' : 0.002115684
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01649477,
        'upper limit (fb)' : 0.518,
        'expected upper limit (fb)' : 0.555,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 114.0),
            ('N1', 114.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWb-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.03184319,
        'r_expected' : 0.02972031,
        'Width (GeV)' : [
            ('C1-', 0.0243239624),
            ('C1+', 0.0243239624),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01416477,
        'l_max' : 0.01441039,
        'l_SM' : 0.01441039
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0008061607,
        'upper limit (fb)' : 0.05247,
        'expected upper limit (fb)' : 0.03622,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2', 213.0),
            ('N1/N1~', 114.0),
            ('N1', 114.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : 'SRWZ_15',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.01536422,
        'r_expected' : 0.02225734,
        'Width (GeV)' : [
            ('C1+/C1-', 0.024324),
            ('N2', 0.0093387),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.06812565,
        'l_max' : 0.1166689,
        'l_SM' : 0.0635299
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,CMS-SUS-13-012,CMS-SUS-16-039-agg',
        'r' : 0.8800278,
        'r_expected' : 1.457232,
        'likelihood' : 2.686949e-25,
        'l_max' : 6.295596000000001e-25,
        'l_SM' : 1.7630750000000003e-25
    }
],
'Total xsec for missing topologies (fb)' : 1072.278,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 936.9012,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 89.35763,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 40.61679,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.744717,
        'SMS' : 'PV > (W,W,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8789828,
        'SMS' : 'PV > (Z,W,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8578029,
        'SMS' : 'PV > (Z,higgs,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6025429,
        'SMS' : 'PV > (W,higgs,MET), (W,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3035591,
        'SMS' : 'PV > (W,higgs,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2962445,
        'SMS' : 'PV > (W,higgs,MET), (Z,higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2043589,
        'SMS' : 'PV > (Z,W,MET), (W,b,t,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1072.278,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 936.9012,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 89.35763,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 40.61679,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.744717,
        'SMS' : 'PV > (W,W,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8789828,
        'SMS' : 'PV > (Z,W,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8578029,
        'SMS' : 'PV > (Z,higgs,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6025429,
        'SMS' : 'PV > (W,higgs,MET), (W,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3035591,
        'SMS' : 'PV > (W,higgs,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2962445,
        'SMS' : 'PV > (W,higgs,MET), (Z,higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2043589,
        'SMS' : 'PV > (Z,W,MET), (W,b,t,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}
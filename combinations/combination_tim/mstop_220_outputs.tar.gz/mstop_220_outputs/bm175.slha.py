smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2016-07,CMS-SUS-16-033,ATLAS-SUSY-2019-09,ATLAS-SUSY-2013-02',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm175.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.178561,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 162.6),
            ('N1', 162.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 1.003945,
        'r_expected' : 1.032493,
        'Width (GeV)' : [
            ('C1-', 0.0001452),
            ('C1+', 0.0001452),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 3.185733e-05,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.992225,
        'upper limit (fb)' : 4.1,
        'expected upper limit (fb)' : 3.72,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-/N2', 214.84),
            ('C1+/C1-', 214.8),
            ('N1/N1~', 162.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR3_Njet5_Nb0_HT500_MHT_500',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.9737135,
        'r_expected' : 1.073179,
        'Width (GeV)' : [
            ('C1-/N2', 0.00014544),
            ('C1+/C1-', 0.0001452),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 1.220797e-05,
        'l_max' : 9.755716e-05,
        'l_SM' : 9.555076e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2014266,
        'upper limit (fb)' : 0.311859,
        'expected upper limit (fb)' : 0.303274,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.6458899,
        'r_expected' : 0.6641736,
        'Width (GeV)' : None,
        'likelihood' : 2.06638e-38,
        'l_max' : 4.446245e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.151468,
        'upper limit (fb)' : 0.43344,
        'expected upper limit (fb)' : 0.33172,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 162.6),
            ('N1', 162.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR3j',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.3494555,
        'r_expected' : 0.456614,
        'Width (GeV)' : [
            ('C1-', 0.0001452),
            ('C1+', 0.0001452),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0464696,
        'l_max' : 0.04953626,
        'l_SM' : 0.03774128
    },
    {
        'maxcond' : 1.5781652643352059e-06,
        'theory prediction (fb)' : 0.1124904,
        'upper limit (fb)' : 1.07,
        'expected upper limit (fb)' : 1.17,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 162.6),
            ('N1', 162.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1051312,
        'r_expected' : 0.09614566,
        'Width (GeV)' : [
            ('C1-', 0.0001452),
            ('C1+', 0.0001452),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002114681,
        'l_max' : 0.002291271,
        'l_SM' : 0.002291271
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.003181777,
        'upper limit (fb)' : 0.0411,
        'expected upper limit (fb)' : 0.0604,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2', 220.7),
            ('N1/N1~', 162.6),
            ('N1', 162.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SROffShell_1_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0774155,
        'r_expected' : 0.05267843,
        'Width (GeV)' : [
            ('C1+/C1-', 0.0001452),
            ('N2', 0.00018476),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.02019742,
        'l_max' : 0.02305062,
        'l_SM' : 0.02305062
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1053138,
        'upper limit (fb)' : 1.805038,
        'expected upper limit (fb)' : 1.258735,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.05834434,
        'r_expected' : 0.08366638,
        'Width (GeV)' : None,
        'likelihood' : 5.017878994069347e-72,
        'l_max' : 7.151952298356437e-72,
        'l_SM' : 4.2441968280750914e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0008109249,
        'upper limit (fb)' : 0.256,
        'expected upper limit (fb)' : 0.291,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 220.7),
            ('C1+/C1-', 214.8),
            ('N1', 162.6),
            ('N1/N1~', 162.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-12',
        'DataSetID' : 'SR0tau_a_Bin16',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.003167675,
        'r_expected' : 0.002786683,
        'Width (GeV)' : [
            ('N2', 0.00018476),
            ('C1+/C1-', 0.0001452),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.04298368,
        'l_max' : 0.04315095,
        'l_SM' : 0.04315095
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.003079717,
        'upper limit (fb)' : 1.614169,
        'expected upper limit (fb)' : 0.793548,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.001907927,
        'r_expected' : 0.003880946,
        'Width (GeV)' : None,
        'likelihood' : 2.8182610000000006e-20,
        'l_max' : 2.1490270000000002e-19,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.000272538,
        'upper limit (fb)' : 0.351,
        'expected upper limit (fb)' : 0.292,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2', 220.7),
            ('N1/N1~', 162.6),
            ('N1', 162.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : 'stop_lowMET_PT_5to12',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.0007764615,
        'r_expected' : 0.0009333493,
        'Width (GeV)' : [
            ('C1+/C1-', 0.0001452),
            ('N2', 0.00018476),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01561031,
        'l_max' : 0.01720959,
        'l_SM' : 0.01559495
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.702628e-05,
        'upper limit (fb)' : 1.04,
        'expected upper limit (fb)' : 0.936,
        'TxNames' : ['T1bbbb'],
        'Mass (GeV)' : [('N3', 237.9), ('N2', 220.7), ('N1', 162.6)],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 3.560219e-05,
        'r_expected' : 3.955799e-05,
        'Width (GeV)' : [
            ('N3', 2.60348861e-05),
            ('N2', 0.000184756904),
            ('N1', 'stable')
        ],
        'likelihood' : 0.004373351,
        'l_max' : 0.004463612,
        'l_SM' : 0.004373275
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-02,ATLAS-SUSY-2016-07,ATLAS-SUSY-2019-09,CMS-SUS-16-033',
        'r' : 1.580276,
        'r_expected' : 1.819743,
        'likelihood' : 3.734495860514401e-49,
        'l_max' : 5.254025911724948e-47,
        'l_SM' : 4.7707212877526e-47
    }
],
'Total xsec for missing topologies (fb)' : 6228.976,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3899.571,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1295.456,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 358.0127,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 322.8951,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 159.8373,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 39.38189,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 22.0917,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.63204,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.43408,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 13.91903,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,jet,jet,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 6228.976,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3899.571,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1295.456,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 358.0127,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 322.8951,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 159.8373,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 39.38189,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 22.0917,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.63204,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.43408,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 13.91903,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,jet,jet,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7543.571,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7464.53,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 33.33439,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 32.65899,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.996924,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.356304,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6886246,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.006018374,
        'SMS' : 'PV > (b,b,MET), (b,b,MET)'
    }
]
}
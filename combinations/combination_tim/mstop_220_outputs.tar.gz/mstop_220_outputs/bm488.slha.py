smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012,ATLAS-SUSY-2018-16',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm488.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1476443,
        'upper limit (fb)' : 0.2005893,
        'expected upper limit (fb)' : 0.1851732,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 152.4),
            ('C1+/C1-', 146.3),
            ('N1', 120.7),
            ('N1/N1~', 120.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.7360529,
        'r_expected' : 0.7973312,
        'Width (GeV)' : [
            ('N2', 1.6047e-05),
            ('C1+/C1-', 7.2244e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 1.6759450000000002e-38,
        'l_max' : 4.4539600000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9715222,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.8),
            ('su_L', 220.8),
            ('C1-', 146.3),
            ('C1+', 146.3),
            ('N1~', 120.7),
            ('N1', 120.7)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.719646,
        'r_expected' : 0.9524727,
        'Width (GeV)' : [
            ('su_L~', 1.0731),
            ('su_L', 1.0731),
            ('C1-', 7.2244e-06),
            ('C1+', 7.2244e-06),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001564008,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1509032,
        'upper limit (fb)' : 0.4682858,
        'expected upper limit (fb)' : 0.5600331,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.322246,
        'r_expected' : 0.2694541,
        'Width (GeV)' : None,
        'likelihood' : 0.07305693,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03715728,
        'upper limit (fb)' : 0.7707647,
        'expected upper limit (fb)' : 0.8251043,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 152.4),
            ('C1+/C1-', 146.3),
            ('N1', 120.7),
            ('N1/N1~', 120.7)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.04820834,
        'r_expected' : 0.04503344,
        'Width (GeV)' : [
            ('N2', 1.6047e-05),
            ('C1+/C1-', 7.2244e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.124813260369481e-72,
        'l_max' : 4.2441968280750914e-72,
        'l_SM' : 4.2441968280750914e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.005815893,
        'upper limit (fb)' : 0.144,
        'expected upper limit (fb)' : 0.121,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 146.3),
            ('N2', 152.4),
            ('N1/N1~', 120.7),
            ('N1', 120.7)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : 'Ewkino_highMET_M_4to9',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.04038814,
        'r_expected' : 0.04806523,
        'Width (GeV)' : [
            ('C1+/C1-', 7.2244e-06),
            ('N2', 1.6047e-05),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1491764,
        'l_max' : 0.1542599,
        'l_SM' : 0.1420158
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05939745,
        'upper limit (fb)' : 13.292,
        'expected upper limit (fb)' : 11.561,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1+/C1-/N2', 149.75),
            ('C1+/C1-', 146.3),
            ('N1/N1~', 120.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jlm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.004468661,
        'r_expected' : 0.005137743,
        'Width (GeV)' : [
            ('C1+/C1-/N2', 1.2221e-05),
            ('C1+/C1-', 7.2244e-06),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.867521e-05,
        'l_max' : 3.106569e-05,
        'l_SM' : 2.855812e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0004474388,
        'upper limit (fb)' : 2.014837,
        'expected upper limit (fb)' : 1.395591,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 152.4),
            ('C1+/C1-', 146.3),
            ('N1', 120.7),
            ('N1/N1~', 120.7)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.000222072,
        'r_expected' : 0.0003206088,
        'Width (GeV)' : [
            ('N2', 1.6047e-05),
            ('C1+/C1-', 7.2244e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.7619370000000006e-20,
        'l_max' : 4.8009610000000007e-20,
        'l_SM' : 2.7600510000000006e-20
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 1.138396,
        'r_expected' : 1.397451,
        'likelihood' : 1.9149622618201027e-42,
        'l_max' : 1.7519232739608953e-41,
        'l_SM' : 1.5358129351457452e-41
    }
],
'Total xsec for missing topologies (fb)' : 10168.7,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3629.815,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1243.362,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1216.661,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 898.9525,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 722.7818,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 297.6331,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 285.5947,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 242.2659,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 242.2659,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 222.009,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 10168.7,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3629.815,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1243.362,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1216.661,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 898.9525,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 722.7818,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 297.6331,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 285.5947,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 242.2659,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 242.2659,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 222.009,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7513.024,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7418.954,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 76.51787,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 15.4512,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.405315,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4726468,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1176094,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05754185,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04832581,
        'SMS' : 'PV > (MET), (l,l,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm211.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.947456,
        'upper limit (fb)' : 0.3568483,
        'expected upper limit (fb)' : 0.3723157,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 22.27124,
        'r_expected' : 21.34602,
        'Width (GeV)' : [
            ('C1-', 0.0566749406),
            ('C1+', 0.0566749406),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 3.3454199737255447e-248,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.434527,
        'upper limit (fb)' : 0.518,
        'expected upper limit (fb)' : 0.555,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWb-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 4.699859,
        'r_expected' : 4.386535,
        'Width (GeV)' : [
            ('C1-', 0.0566749406),
            ('C1+', 0.0566749406),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.629099e-13,
        'l_max' : 0.01441039,
        'l_SM' : 0.01441039
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.975556,
        'upper limit (fb)' : 0.4452965,
        'expected upper limit (fb)' : 0.5178573,
        'TxNames' : ['TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 4.436496,
        'r_expected' : 3.814866,
        'Width (GeV)' : None,
        'likelihood' : 5.341328163623119e-94,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.115406,
        'upper limit (fb)' : 1.484349,
        'expected upper limit (fb)' : 1.763515,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.7514446,
        'r_expected' : 0.6324902,
        'Width (GeV)' : None,
        'likelihood' : 1.1091547795191732e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.274106,
        'upper limit (fb)' : 2.309268,
        'expected upper limit (fb)' : 1.528824,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.5517359,
        'r_expected' : 0.8333895,
        'Width (GeV)' : None,
        'likelihood' : 6.330707000000001e-20,
        'l_max' : 6.920500000000001e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01768969,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.127,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2/N3', 223.08),
            ('N1/N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.1965521,
        'r_expected' : 0.1392889,
        'Width (GeV)' : [
            ('C1+/C1-', 0.056675),
            ('N2/N3', 0.024237),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1394186,
        'l_max' : 0.2014847,
        'l_SM' : 0.2014847
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01205579,
        'upper limit (fb)' : 0.0725363,
        'expected upper limit (fb)' : 0.07483787,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2', 221.1),
            ('N1/N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1662035,
        'r_expected' : 0.1610921,
        'Width (GeV)' : [
            ('C1+/C1-', 0.056675),
            ('N2', 0.037705),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.1050760000000002e-24,
        'l_max' : 1.2066700000000002e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0123882,
        'upper limit (fb)' : 0.0756,
        'expected upper limit (fb)' : 0.0842,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2/N3', 223.07),
            ('N1/N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SRLow2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1638651,
        'r_expected' : 0.1471283,
        'Width (GeV)' : [
            ('C1+/C1-', 0.056675),
            ('N2/N3', 0.024342),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01197826,
        'l_max' : 0.01363736,
        'l_SM' : 0.01363736
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1497885,
        'upper limit (fb)' : 1.34,
        'expected upper limit (fb)' : 0.833,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_600MHTinf',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.1117825,
        'r_expected' : 0.1798181,
        'Width (GeV)' : [
            ('C1-', 0.0566749406),
            ('C1+', 0.0566749406),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003815024,
        'l_max' : 0.005396484,
        'l_SM' : 0.002530291
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03195782,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2/N3', 223.07),
            ('N1/N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.07609006,
        'r_expected' : 0.1681991,
        'Width (GeV)' : [
            ('C1+/C1-', 0.056675),
            ('N2/N3', 0.024309),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002874947,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
        'r' : 23.89589,
        'r_expected' : 22.71962,
        'likelihood' : 0.0,
        'l_max' : 3.002015297513939e-171,
        'l_SM' : 3.002015297513939e-171
    }
],
'Total xsec for missing topologies (fb)' : 107.5212,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 61.82469,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 45.69647,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 107.5212,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 61.82469,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 45.69647,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm211.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.947456,
        'upper limit (fb)' : 0.3568483,
        'expected upper limit (fb)' : 0.3723157,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 22.27124,
        'r_expected' : 21.34602,
        'Width (GeV)' : [
            ('C1-', 0.0566749406),
            ('C1+', 0.0566749406),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 3.3454199737255447e-248,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.434527,
        'upper limit (fb)' : 0.518,
        'expected upper limit (fb)' : 0.555,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWb-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 4.699859,
        'r_expected' : 4.386535,
        'Width (GeV)' : [
            ('C1-', 0.0566749406),
            ('C1+', 0.0566749406),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.629099e-13,
        'l_max' : 0.01441039,
        'l_SM' : 0.01441039
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.975556,
        'upper limit (fb)' : 0.4452965,
        'expected upper limit (fb)' : 0.5178573,
        'TxNames' : ['TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 4.436496,
        'r_expected' : 3.814866,
        'Width (GeV)' : None,
        'likelihood' : 5.341328163623119e-94,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.115406,
        'upper limit (fb)' : 1.484349,
        'expected upper limit (fb)' : 1.763515,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.7514446,
        'r_expected' : 0.6324902,
        'Width (GeV)' : None,
        'likelihood' : 1.1091547795191732e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.274106,
        'upper limit (fb)' : 2.309268,
        'expected upper limit (fb)' : 1.528824,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.5517359,
        'r_expected' : 0.8333895,
        'Width (GeV)' : None,
        'likelihood' : 6.330707000000001e-20,
        'l_max' : 6.920500000000001e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01768969,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.127,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2/N3', 223.08),
            ('N1/N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.1965521,
        'r_expected' : 0.1392889,
        'Width (GeV)' : [
            ('C1+/C1-', 0.056675),
            ('N2/N3', 0.024237),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1394186,
        'l_max' : 0.2014847,
        'l_SM' : 0.2014847
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01205579,
        'upper limit (fb)' : 0.0725363,
        'expected upper limit (fb)' : 0.07483787,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2', 221.1),
            ('N1/N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1662035,
        'r_expected' : 0.1610921,
        'Width (GeV)' : [
            ('C1+/C1-', 0.056675),
            ('N2', 0.037705),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.1050760000000002e-24,
        'l_max' : 1.2066700000000002e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0123882,
        'upper limit (fb)' : 0.0756,
        'expected upper limit (fb)' : 0.0842,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2/N3', 223.07),
            ('N1/N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SRLow2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1638651,
        'r_expected' : 0.1471283,
        'Width (GeV)' : [
            ('C1+/C1-', 0.056675),
            ('N2/N3', 0.024342),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01197826,
        'l_max' : 0.01363736,
        'l_SM' : 0.01363736
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1497885,
        'upper limit (fb)' : 1.34,
        'expected upper limit (fb)' : 0.833,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_600MHTinf',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.1117825,
        'r_expected' : 0.1798181,
        'Width (GeV)' : [
            ('C1-', 0.0566749406),
            ('C1+', 0.0566749406),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003815024,
        'l_max' : 0.005396484,
        'l_SM' : 0.002530291
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03195782,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2/N3', 223.07),
            ('N1/N1~', 106.0),
            ('N1', 106.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.07609006,
        'r_expected' : 0.1681991,
        'Width (GeV)' : [
            ('C1+/C1-', 0.056675),
            ('N2/N3', 0.024309),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002874947,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
        'r' : 23.89589,
        'r_expected' : 22.71962,
        'likelihood' : 0.0,
        'l_max' : 3.002015297513939e-171,
        'l_SM' : 3.002015297513939e-171
    }
],
'Total xsec for missing topologies (fb)' : 107.5212,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 61.82469,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 45.69647,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 107.5212,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 61.82469,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 45.69647,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm166.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 21.86202,
        'upper limit (fb)' : 0.2831832,
        'expected upper limit (fb)' : 0.3272186,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 83.3),
            ('N1', 83.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 77.20099,
        'r_expected' : 66.81167,
        'Width (GeV)' : [
            ('C1-', 0.0921759142),
            ('C1+', 0.0921759142),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.610109,
        'upper limit (fb)' : 0.3689992,
        'expected upper limit (fb)' : 0.5795129,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 9.783514,
        'r_expected' : 6.229558,
        'Width (GeV)' : None,
        'likelihood' : 1.5584621493653867e-114,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.500472,
        'upper limit (fb)' : 0.531,
        'expected upper limit (fb)' : 0.438,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 83.3),
            ('N1', 83.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWc-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 6.592226,
        'r_expected' : 7.991946,
        'Width (GeV)' : [
            ('C1-', 0.0921759142),
            ('C1+', 0.0921759142),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 3.988377e-22,
        'l_max' : 0.02164771,
        'l_SM' : 0.01893459
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8546428,
        'upper limit (fb)' : 1.398109,
        'expected upper limit (fb)' : 1.667862,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.611285,
        'r_expected' : 0.5124182,
        'Width (GeV)' : None,
        'likelihood' : 1.6399302943724174e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8266389,
        'upper limit (fb)' : 1.614127,
        'expected upper limit (fb)' : 1.455004,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.5121275,
        'r_expected' : 0.5681352,
        'Width (GeV)' : None,
        'likelihood' : 2.1550150000000002e-20,
        'l_max' : 2.9503230000000003e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1379995,
        'upper limit (fb)' : 0.3422273,
        'expected upper limit (fb)' : 0.2964138,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4032394,
        'r_expected' : 0.4655637,
        'Width (GeV)' : None,
        'likelihood' : 1.1633880000000002e-24,
        'l_max' : 1.3246960000000002e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.267252,
        'upper limit (fb)' : 1.04,
        'expected upper limit (fb)' : 0.936,
        'TxNames' : ['TChiWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.2569731,
        'r_expected' : 0.2855256,
        'Width (GeV)' : None,
        'likelihood' : 0.004099003,
        'l_max' : 0.004463612,
        'l_SM' : 0.004373275
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03808759,
        'upper limit (fb)' : 0.35,
        'expected upper limit (fb)' : 0.383,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2/N3', 221.77),
            ('N1/N1~', 83.3),
            ('N1', 83.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-0Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.1088217,
        'r_expected' : 0.0994454,
        'Width (GeV)' : [
            ('C1+/C1-', 0.092176),
            ('N2/N3', 0.066759),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01111331,
        'l_max' : 0.01183074,
        'l_SM' : 0.01183074
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01887154,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2/N3', 221.76),
            ('N1/N1~', 83.3),
            ('N1', 83.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.04493224,
        'r_expected' : 0.0993239,
        'Width (GeV)' : [
            ('C1+/C1-', 0.092176),
            ('N2/N3', 0.066781),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001753258,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00081781,
        'upper limit (fb)' : 0.06567835,
        'expected upper limit (fb)' : 0.06399812,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.01245174,
        'r_expected' : 0.01277866,
        'Width (GeV)' : None,
        'likelihood' : 9.120583e-11,
        'l_max' : 9.126602e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.118334e-05,
        'upper limit (fb)' : 0.03955767,
        'expected upper limit (fb)' : 0.05348738,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 222.7), ('N2', 221.3), ('N1', 83.3)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.001041096,
        'r_expected' : 0.0007699637,
        'Width (GeV)' : [
            ('N3', 0.0596350962),
            ('N2', 0.0703287751),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6115550000000003e-34,
        'l_max' : 1.6144670000000003e-34,
        'l_SM' : 1.6144670000000003e-34
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.002902e-05,
        'upper limit (fb)' : 0.1224745,
        'expected upper limit (fb)' : 0.07843535,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N2', 221.3),
            ('C1+/C1-', 214.8),
            ('N1', 83.3),
            ('N1/N1~', 83.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.0007350839,
        'r_expected' : 0.001147812,
        'Width (GeV)' : [
            ('N2', 0.070329),
            ('C1+/C1-', 0.092176),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 5.4439818145405565e-45,
        'l_max' : 5.464116013570378e-45,
        'l_SM' : 5.4389172595677885e-45
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
        'r' : 84.4458,
        'r_expected' : 72.01084,
        'likelihood' : 0.0,
        'l_max' : 4.999180431726613e-169,
        'l_SM' : 4.999180431726613e-169
    }
],
'Total xsec for missing topologies (fb)' : 87.77365,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 50.53635,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 36.61316,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6241358,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 87.77365,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 50.53635,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 36.61316,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6241358,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 65.17977,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 65.17977,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012,ATLAS-SUSY-2018-16',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm324.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.09654655,
        'upper limit (fb)' : 0.1588199,
        'expected upper limit (fb)' : 0.1508787,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 162.3),
            ('C1+/C1-', 156.4),
            ('N1', 133.6),
            ('N1/N1~', 133.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.6078994,
        'r_expected' : 0.639895,
        'Width (GeV)' : [
            ('N2', 1.0957e-05),
            ('C1+/C1-', 4.5168e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.2133360000000001e-38,
        'l_max' : 4.4611900000000003e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.7824271,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.5),
            ('su_L', 220.5),
            ('C1-', 156.4),
            ('C1+', 156.4),
            ('N1~', 133.6),
            ('N1', 133.6)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.5795757,
        'r_expected' : 0.7670854,
        'Width (GeV)' : [
            ('su_L~', 0.83865),
            ('su_L', 0.83865),
            ('C1-', 4.5168e-06),
            ('C1+', 4.5168e-06),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.00245469,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1327533,
        'upper limit (fb)' : 0.4394811,
        'expected upper limit (fb)' : 0.525572,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3020682,
        'r_expected' : 0.2525882,
        'Width (GeV)' : None,
        'likelihood' : 0.07583578,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002504431,
        'upper limit (fb)' : 0.03355414,
        'expected upper limit (fb)' : 0.0501659,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-41',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.07463852,
        'r_expected' : 0.04992299,
        'Width (GeV)' : None,
        'likelihood' : 0.00207186,
        'l_max' : 0.002358157,
        'l_SM' : 0.002358157
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01117956,
        'upper limit (fb)' : 0.2348036,
        'expected upper limit (fb)' : 0.1538001,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.0476124,
        'r_expected' : 0.07268893,
        'Width (GeV)' : None,
        'likelihood' : 1.1882215612737185e-81,
        'l_max' : 1.470191040309097e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01968553,
        'upper limit (fb)' : 0.4725362,
        'expected upper limit (fb)' : 0.4372414,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0416593,
        'r_expected' : 0.04502211,
        'Width (GeV)' : None,
        'likelihood' : 1.0891370000000003e-32,
        'l_max' : 1.0907900000000003e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01354662,
        'upper limit (fb)' : 0.9838324,
        'expected upper limit (fb)' : 0.747543,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01376924,
        'r_expected' : 0.01812153,
        'Width (GeV)' : None,
        'likelihood' : 4.3579114877313873e-72,
        'l_max' : 5.324972317203952e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0009758057,
        'upper limit (fb)' : 0.08239834,
        'expected upper limit (fb)' : 0.04677259,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.01184254,
        'r_expected' : 0.02086277,
        'Width (GeV)' : None,
        'likelihood' : 5.66920389846248e-45,
        'l_max' : 6.592791692797155e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0303557,
        'upper limit (fb)' : 13.292,
        'expected upper limit (fb)' : 11.561,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('N2', 162.3),
            ('C1+/C1-', 156.4),
            ('N1', 133.6),
            ('N1/N1~', 133.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jlm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.002283757,
        'r_expected' : 0.002625698,
        'Width (GeV)' : [
            ('N2', 1.0957e-05),
            ('C1+/C1-', 4.5168e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.861827e-05,
        'l_max' : 3.106569e-05,
        'l_SM' : 2.855812e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.004717166,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [('C1+/C1-', 156.4), ('N1/N1~', 133.6)],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.002173809,
        'r_expected' : 0.002235624,
        'Width (GeV)' : [('C1+/C1-', 4.5168e-06), ('N1/N1~', 'stable')],
        'likelihood' : 0.0002988995,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0009258399,
        'upper limit (fb)' : 0.5347066,
        'expected upper limit (fb)' : 0.6881978,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.001731492,
        'r_expected' : 0.001345311,
        'Width (GeV)' : None,
        'likelihood' : 2.7561290000000003e-20,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.9506517,
        'r_expected' : 1.147556,
        'likelihood' : 4.120198400075721e-42,
        'l_max' : 1.7315783985649116e-41,
        'l_SM' : 1.5358129351403325e-41
    }
],
'Total xsec for missing topologies (fb)' : 9663.933,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3681.647,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1270.717,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1235.946,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 768.4807,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 636.2777,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 300.5314,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 225.3445,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.6013,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.6013,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 191.3392,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 9663.933,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3681.647,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1270.717,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1235.946,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 768.4807,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 636.2777,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 300.5314,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 225.3445,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.6013,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.6013,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 191.3392,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7643.396,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7570.449,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 57.37939,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 12.34283,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.750121,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2917199,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0773341,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06763971,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.03760898,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012,ATLAS-SUSY-2018-16',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm324.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.09654655,
        'upper limit (fb)' : 0.1588199,
        'expected upper limit (fb)' : 0.1508787,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 162.3),
            ('C1+/C1-', 156.4),
            ('N1', 133.6),
            ('N1/N1~', 133.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.6078994,
        'r_expected' : 0.639895,
        'Width (GeV)' : [
            ('N2', 1.0957e-05),
            ('C1+/C1-', 4.5168e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.2133360000000001e-38,
        'l_max' : 4.4611900000000003e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.7824271,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.5),
            ('su_L', 220.5),
            ('C1-', 156.4),
            ('C1+', 156.4),
            ('N1~', 133.6),
            ('N1', 133.6)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.5795757,
        'r_expected' : 0.7670854,
        'Width (GeV)' : [
            ('su_L~', 0.83865),
            ('su_L', 0.83865),
            ('C1-', 4.5168e-06),
            ('C1+', 4.5168e-06),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.00245469,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1327533,
        'upper limit (fb)' : 0.4394811,
        'expected upper limit (fb)' : 0.525572,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3020682,
        'r_expected' : 0.2525882,
        'Width (GeV)' : None,
        'likelihood' : 0.07583578,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002504431,
        'upper limit (fb)' : 0.03355414,
        'expected upper limit (fb)' : 0.0501659,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-41',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.07463852,
        'r_expected' : 0.04992299,
        'Width (GeV)' : None,
        'likelihood' : 0.00207186,
        'l_max' : 0.002358157,
        'l_SM' : 0.002358157
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01117956,
        'upper limit (fb)' : 0.2348036,
        'expected upper limit (fb)' : 0.1538001,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.0476124,
        'r_expected' : 0.07268893,
        'Width (GeV)' : None,
        'likelihood' : 1.1882215612737185e-81,
        'l_max' : 1.470191040309097e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01968553,
        'upper limit (fb)' : 0.4725362,
        'expected upper limit (fb)' : 0.4372414,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0416593,
        'r_expected' : 0.04502211,
        'Width (GeV)' : None,
        'likelihood' : 1.0891370000000003e-32,
        'l_max' : 1.0907900000000003e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01354662,
        'upper limit (fb)' : 0.9838324,
        'expected upper limit (fb)' : 0.747543,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01376924,
        'r_expected' : 0.01812153,
        'Width (GeV)' : None,
        'likelihood' : 4.3579114877313873e-72,
        'l_max' : 5.324972317203952e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0009758057,
        'upper limit (fb)' : 0.08239834,
        'expected upper limit (fb)' : 0.04677259,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.01184254,
        'r_expected' : 0.02086277,
        'Width (GeV)' : None,
        'likelihood' : 5.66920389846248e-45,
        'l_max' : 6.592791692797155e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0303557,
        'upper limit (fb)' : 13.292,
        'expected upper limit (fb)' : 11.561,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('N2', 162.3),
            ('C1+/C1-', 156.4),
            ('N1', 133.6),
            ('N1/N1~', 133.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jlm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.002283757,
        'r_expected' : 0.002625698,
        'Width (GeV)' : [
            ('N2', 1.0957e-05),
            ('C1+/C1-', 4.5168e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.861827e-05,
        'l_max' : 3.106569e-05,
        'l_SM' : 2.855812e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.004717166,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [('C1+/C1-', 156.4), ('N1/N1~', 133.6)],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.002173809,
        'r_expected' : 0.002235624,
        'Width (GeV)' : [('C1+/C1-', 4.5168e-06), ('N1/N1~', 'stable')],
        'likelihood' : 0.0002988995,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0009258399,
        'upper limit (fb)' : 0.5347066,
        'expected upper limit (fb)' : 0.6881978,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.001731492,
        'r_expected' : 0.001345311,
        'Width (GeV)' : None,
        'likelihood' : 2.7561290000000003e-20,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.9506517,
        'r_expected' : 1.147556,
        'likelihood' : 4.120198400075721e-42,
        'l_max' : 1.7315783985649116e-41,
        'l_SM' : 1.5358129351403325e-41
    }
],
'Total xsec for missing topologies (fb)' : 9663.933,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3681.647,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1270.717,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1235.946,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 768.4807,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 636.2777,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 300.5314,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 225.3445,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.6013,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.6013,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 191.3392,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 9663.933,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3681.647,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1270.717,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1235.946,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 768.4807,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 636.2777,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 300.5314,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 225.3445,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.6013,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.6013,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 191.3392,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7643.396,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7570.449,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 57.37939,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 12.34283,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.750121,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2917199,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0773341,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06763971,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.03760898,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
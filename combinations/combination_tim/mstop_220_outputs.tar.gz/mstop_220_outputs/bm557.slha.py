smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,ATLAS-SUSY-2013-04',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm557.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.246646,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.9234415,
        'r_expected' : 1.222202,
        'Width (GeV)' : None,
        'likelihood' : 0.0006299995,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.7726329,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.2,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('C1-', 146.3),
            ('C1+', 146.3),
            ('N1~', 59.5),
            ('N1', 59.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_1bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.5723207,
        'r_expected' : 0.6438607,
        'Width (GeV)' : [
            ('su_L~', 1.06335434),
            ('su_L', 1.06335434),
            ('C1-', 0.0131544693),
            ('C1+', 0.0131544693),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001502715,
        'l_max' : 0.002394811,
        'l_SM' : 0.002264688
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.09945389,
        'upper limit (fb)' : 1.07,
        'expected upper limit (fb)' : 1.17,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 146.3),
            ('C1+', 146.3),
            ('N1~', 59.5),
            ('N1', 59.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.09294756,
        'r_expected' : 0.08500333,
        'Width (GeV)' : [
            ('C1-', 0.0131544693),
            ('C1+', 0.0131544693),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002138566,
        'l_max' : 0.002291271,
        'l_SM' : 0.002291271
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06677676,
        'upper limit (fb)' : 0.9973737,
        'expected upper limit (fb)' : 0.7419855,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 146.3),
            ('C1+', 146.3),
            ('N1~', 59.5),
            ('N1', 59.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-02',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.06695259,
        'r_expected' : 0.08999739,
        'Width (GeV)' : [
            ('C1-', 0.0131544693),
            ('C1+', 0.0131544693),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.67874e-40,
        'l_max' : 3.583763e-40,
        'l_SM' : 2.291911e-40
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,CMS-SUS-13-012',
        'r' : 1.157512,
        'r_expected' : 1.53658,
        'likelihood' : 9.467096e-07,
        'l_max' : 9.31438e-06,
        'l_SM' : 6.837721e-06
    }
],
'Total xsec for missing topologies (fb)' : 2123.098,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1473.053,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 387.6454,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 220.6535,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 41.74643,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 2123.098,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1473.053,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 387.6454,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 220.6535,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 41.74643,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}
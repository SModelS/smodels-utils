smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2016-07,ATLAS-SUSY-2013-02,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm41.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.266995,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('C1+', 211.8),
            ('N1/N1~', 180.3),
            ('N1', 180.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.5838687,
        'r_expected' : 0.6004716,
        'Width (GeV)' : [
            ('C1+/C1-', 1.9097e-05),
            ('C1+', 1.9097e-05),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0001439058,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1841242,
        'upper limit (fb)' : 0.50301,
        'expected upper limit (fb)' : 0.88617,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('C1+', 211.8),
            ('N1/N1~', 180.3),
            ('N1', 180.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.3660449,
        'r_expected' : 0.2077753,
        'Width (GeV)' : [
            ('C1+/C1-', 1.9097e-05),
            ('C1+', 1.9097e-05),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.000625078,
        'l_max' : 0.001434466,
        'l_SM' : 0.001434466
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05366784,
        'upper limit (fb)' : 0.163016,
        'expected upper limit (fb)' : 0.1576015,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 217.5),
            ('C1+/C1-', 211.8),
            ('N1', 180.3),
            ('N1/N1~', 180.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3292182,
        'r_expected' : 0.3405286,
        'Width (GeV)' : [
            ('N2', 3.4165e-05),
            ('C1+/C1-', 1.9097e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 3.2917130000000005e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8141032,
        'upper limit (fb)' : 2.88,
        'expected upper limit (fb)' : 2.01,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.0),
            ('su_L', 220.0),
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 180.3),
            ('N1', 180.3)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.2826747,
        'r_expected' : 0.4050264,
        'Width (GeV)' : [
            ('su_L~', 0.01566),
            ('su_L', 0.01566),
            ('C1-', 1.9097e-05),
            ('C1+', 1.9097e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0009521743,
        'l_max' : 0.0009521956,
        'l_SM' : 0.0006572509
    },
    {
        'maxcond' : 1.0983943594738399e-06,
        'theory prediction (fb)' : 0.06476748,
        'upper limit (fb)' : 0.813,
        'expected upper limit (fb)' : 1.19,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 180.3),
            ('N1', 180.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-SF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.0796648,
        'r_expected' : 0.05442646,
        'Width (GeV)' : [
            ('C1-', 1.9097e-05),
            ('C1+', 1.9097e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001105708,
        'l_max' : 0.001267591,
        'l_SM' : 0.001267591
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03581272,
        'upper limit (fb)' : 0.7321204,
        'expected upper limit (fb)' : 0.8754472,
        'TxNames' : ['TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.04891644,
        'r_expected' : 0.04090792,
        'Width (GeV)' : None,
        'likelihood' : 0.1095552,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01035104,
        'upper limit (fb)' : 0.4467708,
        'expected upper limit (fb)' : 0.4721066,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2', 217.5),
            ('N1/N1~', 180.3),
            ('N1', 180.3)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.02316858,
        'r_expected' : 0.02192523,
        'Width (GeV)' : [
            ('C1+/C1-', 1.9097e-05),
            ('N2', 3.4165e-05),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.0476330000000003e-32,
        'l_max' : 1.0786820000000003e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01887036,
        'upper limit (fb)' : 1.295985,
        'expected upper limit (fb)' : 0.995341,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 217.5),
            ('C1+/C1-', 211.8),
            ('N1', 180.3),
            ('N1/N1~', 180.3)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01456063,
        'r_expected' : 0.01895869,
        'Width (GeV)' : [
            ('N2', 3.4165e-05),
            ('C1+/C1-', 1.9097e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.375008453582762e-72,
        'l_max' : 5.585228410889222e-72,
        'l_SM' : 4.2441968280750914e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0004022445,
        'upper limit (fb)' : 1.481836,
        'expected upper limit (fb)' : 0.9606421,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 217.5),
            ('C1+/C1-', 211.8),
            ('N1', 180.3),
            ('N1/N1~', 180.3)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.00027145,
        'r_expected' : 0.0004187246,
        'Width (GeV)' : [
            ('N2', 3.4165e-05),
            ('C1+/C1-', 1.9097e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.7629440000000005e-20,
        'l_max' : 5.3324430000000005e-20,
        'l_SM' : 2.7600510000000006e-20
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-02,ATLAS-SUSY-2016-07,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.8850151,
        'r_expected' : 0.8953406,
        'likelihood' : 2.8193616622646843e-48,
        'l_max' : 1.2472532981070398e-47,
        'l_SM' : 1.2472532981070398e-47
    }
],
'Total xsec for missing topologies (fb)' : 6294.473,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3882.748,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1294.018,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 364.1322,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 319.2275,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 197.875,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 47.507,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 28.49325,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 23.43946,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 21.51407,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 17.00665,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,jet,jet,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 6294.473,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3882.748,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1294.018,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 364.1322,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 319.2275,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 197.875,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 47.507,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 28.49325,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 23.43946,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 21.51407,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 17.00665,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,jet,jet,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7529.056,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7505.406,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 22.23935,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.178066,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1947568,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02571167,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01268587,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
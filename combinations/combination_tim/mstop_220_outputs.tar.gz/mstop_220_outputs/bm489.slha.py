smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm489.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.497358,
        'upper limit (fb)' : 1.545966,
        'expected upper limit (fb)' : 1.660536,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.9685584,
        'r_expected' : 0.9017318,
        'Width (GeV)' : None,
        'likelihood' : 6.298549714248576e-73,
        'l_max' : 4.2441968280750914e-72,
        'l_SM' : 4.2441968280750914e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.142703,
        'upper limit (fb)' : 1.424063,
        'expected upper limit (fb)' : 1.447196,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8024244,
        'r_expected' : 0.7895979,
        'Width (GeV)' : None,
        'likelihood' : 8.131995000000001e-21,
        'l_max' : 2.7600690000000005e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8981345,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.6652848,
        'r_expected' : 0.880524,
        'Width (GeV)' : None,
        'likelihood' : 0.001895552,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1349164,
        'upper limit (fb)' : 0.289757,
        'expected upper limit (fb)' : 0.2239212,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4656191,
        'r_expected' : 0.6025174,
        'Width (GeV)' : None,
        'likelihood' : 1.358311e-24,
        'l_max' : 1.5432670000000002e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2554808,
        'upper limit (fb)' : 0.974,
        'expected upper limit (fb)' : 0.765,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 86.1),
            ('N1', 86.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_0bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.2623006,
        'r_expected' : 0.3339618,
        'Width (GeV)' : [
            ('su_L~', 0.202671201),
            ('su_L', 0.202671201),
            ('C1-', 0.0488495254),
            ('C1+', 0.0488495254),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.006276118,
        'l_max' : 0.006278059,
        'l_SM' : 0.004973309
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02109171,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.127,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 191.7),
            ('N2/N3', 199.83),
            ('N1/N1~', 86.1),
            ('N1', 86.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.2343523,
        'r_expected' : 0.1660764,
        'Width (GeV)' : [
            ('C1+/C1-', 0.04885),
            ('N2/N3', 0.022766),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1289568,
        'l_max' : 0.2014847,
        'l_SM' : 0.2014847
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01757483,
        'upper limit (fb)' : 0.0756,
        'expected upper limit (fb)' : 0.0842,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 191.7),
            ('N2/N3', 199.83),
            ('N1/N1~', 86.1),
            ('N1', 86.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SRLow2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.2324713,
        'r_expected' : 0.2087272,
        'Width (GeV)' : [
            ('C1+/C1-', 0.04885),
            ('N2/N3', 0.022738),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0109643,
        'l_max' : 0.01363736,
        'l_SM' : 0.01363736
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04273599,
        'upper limit (fb)' : 0.3195951,
        'expected upper limit (fb)' : 0.3504837,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 86.1),
            ('N1', 86.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1337192,
        'r_expected' : 0.1219343,
        'Width (GeV)' : [
            ('C1-', 0.0488495254),
            ('C1+', 0.0488495254),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.564071e-40,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04260437,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 191.7),
            ('N2/N3', 199.82),
            ('N1/N1~', 86.1),
            ('N1', 86.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.101439,
        'r_expected' : 0.2242336,
        'Width (GeV)' : [
            ('C1+/C1-', 0.04885),
            ('N2/N3', 0.022785),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.004126355,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.032787,
        'upper limit (fb)' : 0.518,
        'expected upper limit (fb)' : 0.555,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 86.1),
            ('N1', 86.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWb-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.06329536,
        'r_expected' : 0.05907567,
        'Width (GeV)' : [
            ('C1-', 0.0488495254),
            ('C1+', 0.0488495254),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01386724,
        'l_max' : 0.01441039,
        'l_SM' : 0.01441039
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.187044,
        'r_expected' : 1.498519,
        'likelihood' : 1.7454350186779253e-143,
        'l_max' : 2.3891495563692814e-142,
        'l_SM' : 1.7996075039939118e-142
    }
],
'Total xsec for missing topologies (fb)' : 1192.691,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1034.393,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 109.1708,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 46.3974,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.72927,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1192.691,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1034.393,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 109.1708,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 46.3974,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.72927,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2016-07,CMS-SUS-16-033,ATLAS-SUSY-2019-09,CMS-SUS-13-012,ATLAS-SUSY-2013-02,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm414.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.270194,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 158.2),
            ('N1', 158.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 1.046172,
        'r_expected' : 1.075921,
        'Width (GeV)' : [
            ('C1-', 0.00015995),
            ('C1+', 0.00015995),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.617135e-05,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.37703,
        'upper limit (fb)' : 4.1,
        'expected upper limit (fb)' : 3.72,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 158.2),
            ('N1', 158.2)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR3_Njet5_Nb0_HT500_MHT_500',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.823666,
        'r_expected' : 0.9078039,
        'Width (GeV)' : [
            ('C1-', 0.00015995),
            ('C1+', 0.00015995),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.323727e-05,
        'l_max' : 9.755716e-05,
        'l_SM' : 9.555076e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.240751,
        'upper limit (fb)' : 0.3104672,
        'expected upper limit (fb)' : 0.3030045,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.7754475,
        'r_expected' : 0.794546,
        'Width (GeV)' : None,
        'likelihood' : 1.4458360000000002e-38,
        'l_max' : 4.4443870000000003e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3860324,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.5),
            ('su_L', 220.5),
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 158.2),
            ('N1', 158.2)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.2859499,
        'r_expected' : 0.3784631,
        'Width (GeV)' : [
            ('su_L~', 0.017629),
            ('su_L', 0.017629),
            ('C1-', 0.00015995),
            ('C1+', 0.00015995),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003859878,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1137154,
        'upper limit (fb)' : 0.43344,
        'expected upper limit (fb)' : 0.33172,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 158.2),
            ('N1', 158.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR3j',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.2623556,
        'r_expected' : 0.3428054,
        'Width (GeV)' : [
            ('C1-', 0.00015995),
            ('C1+', 0.00015995),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0492634,
        'l_max' : 0.04953626,
        'l_SM' : 0.03774128
    },
    {
        'maxcond' : 1.580545617562037e-06,
        'theory prediction (fb)' : 0.115869,
        'upper limit (fb)' : 1.07,
        'expected upper limit (fb)' : 1.17,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 158.2),
            ('N1', 158.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1082888,
        'r_expected' : 0.09903333,
        'Width (GeV)' : [
            ('C1-', 0.00015995),
            ('C1+', 0.00015995),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002108361,
        'l_max' : 0.002291271,
        'l_SM' : 0.002291271
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1278861,
        'upper limit (fb)' : 1.728126,
        'expected upper limit (fb)' : 1.21314,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.07400273,
        'r_expected' : 0.1054174,
        'Width (GeV)' : None,
        'likelihood' : 5.219394725262574e-72,
        'l_max' : 7.162014595175462e-72,
        'l_SM' : 4.2441968280750914e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.007511412,
        'upper limit (fb)' : 0.8126863,
        'expected upper limit (fb)' : 0.5467352,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2', 217.7),
            ('N1/N1~', 158.2),
            ('N1', 158.2)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.009242695,
        'r_expected' : 0.01373866,
        'Width (GeV)' : [
            ('C1+/C1-', 0.00015995),
            ('N2', 0.00019994),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.0971670000000003e-32,
        'l_max' : 1.3827320000000002e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05064229,
        'upper limit (fb)' : 6.276152,
        'expected upper limit (fb)' : 3.118421,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2', 217.7),
            ('N1/N1~', 158.2),
            ('N1', 158.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.008069004,
        'r_expected' : 0.01623972,
        'Width (GeV)' : [
            ('C1+/C1-', 0.00015995),
            ('N2', 0.00019994),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 4.763412027604542e-123,
        'l_max' : 5.75896234101675e-123,
        'l_SM' : 4.533920267286097e-123
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001005183,
        'upper limit (fb)' : 0.256,
        'expected upper limit (fb)' : 0.291,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 217.7),
            ('C1+/C1-', 211.8),
            ('N1', 158.2),
            ('N1/N1~', 158.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-12',
        'DataSetID' : 'SR0tau_a_Bin16',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.003926498,
        'r_expected' : 0.003454239,
        'Width (GeV)' : [
            ('N2', 0.00019994),
            ('C1+/C1-', 0.00015995),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.04294349,
        'l_max' : 0.04315095,
        'l_SM' : 0.04315095
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.004141216,
        'upper limit (fb)' : 1.797145,
        'expected upper limit (fb)' : 0.9105572,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.002304331,
        'r_expected' : 0.004548002,
        'Width (GeV)' : None,
        'likelihood' : 2.8235350000000006e-20,
        'l_max' : 1.841503e-19,
        'l_SM' : 2.7600510000000006e-20
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-02,ATLAS-SUSY-2016-07,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033,CMS-SUS-16-039',
        'r' : 1.494452,
        'r_expected' : 1.816776,
        'likelihood' : 8.726665571349302e-123,
        'l_max' : 7.309292428920639e-121,
        'l_SM' : 6.113396078942602e-121
    }
],
'Total xsec for missing topologies (fb)' : 6199.649,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3871.116,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1284.967,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 364.4924,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 320.3782,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 163.3371,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 37.73839,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.09675,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.81847,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 17.03761,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.09563,
        'SMS' : 'PV > (MET), (b,b,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 6199.649,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3871.116,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1284.967,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 364.4924,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 320.3782,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 163.3371,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 37.73839,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.09675,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.81847,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 17.03761,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.09563,
        'SMS' : 'PV > (MET), (b,b,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7509.16,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7398.61,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 54.03642,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 40.35459,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.899252,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.438814,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8203851,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
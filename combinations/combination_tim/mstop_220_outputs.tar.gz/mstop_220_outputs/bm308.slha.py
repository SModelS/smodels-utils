smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2016-24,ATLAS-SUSY-2018-32,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm308.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.898039,
        'upper limit (fb)' : 0.3767595,
        'expected upper limit (fb)' : 0.3669198,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 110.2),
            ('N1', 110.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 13.00044,
        'r_expected' : 13.34907,
        'Width (GeV)' : [
            ('C1-', 0.0425428167),
            ('C1+', 0.0425428167),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 3.3872819828044665e-136,
        'l_max' : 1.727631e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.882931,
        'upper limit (fb)' : 0.518,
        'expected upper limit (fb)' : 0.555,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 110.2),
            ('N1', 110.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWb-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 3.635003,
        'r_expected' : 3.392669,
        'Width (GeV)' : [
            ('C1-', 0.0425428167),
            ('C1+', 0.0425428167),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 4.214421e-10,
        'l_max' : 0.01441039,
        'l_SM' : 0.01441039
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.485745,
        'upper limit (fb)' : 0.4207867,
        'expected upper limit (fb)' : 0.5193367,
        'TxNames' : ['TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 3.530875,
        'r_expected' : 2.860851,
        'Width (GeV)' : None,
        'likelihood' : 2.322120491649951e-89,
        'l_max' : 1.0563691620372995e-81,
        'l_SM' : 1.0563691620372995e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.043296,
        'upper limit (fb)' : 1.417774,
        'expected upper limit (fb)' : 1.634578,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.7358689,
        'r_expected' : 0.6382661,
        'Width (GeV)' : None,
        'likelihood' : 1.148322967212319e-72,
        'l_max' : 4.2441968280750914e-72,
        'l_SM' : 4.2441968280750914e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8485424,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.6285499,
        'r_expected' : 0.8319043,
        'Width (GeV)' : None,
        'likelihood' : 0.002131981,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.526479,
        'upper limit (fb)' : 2.462212,
        'expected upper limit (fb)' : 1.533494,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6199626,
        'r_expected' : 0.9954261,
        'Width (GeV)' : None,
        'likelihood' : 7.604102000000001e-20,
        'l_max' : 8.832118000000001e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01966325,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.127,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2/N3', 220.41),
            ('N1/N1~', 110.2),
            ('N1', 110.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.2184806,
        'r_expected' : 0.1548288,
        'Width (GeV)' : [
            ('C1+/C1-', 0.042543),
            ('N2/N3', 0.01766),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1332819,
        'l_max' : 0.2014847,
        'l_SM' : 0.2014847
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01775675,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2', 218.1),
            ('N1/N1~', 110.2),
            ('N1', 110.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.04227797,
        'r_expected' : 0.09345657,
        'Width (GeV)' : [
            ('C1+/C1-', 0.042543),
            ('N2', 0.024877),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001676368,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00111196,
        'upper limit (fb)' : 0.05247,
        'expected upper limit (fb)' : 0.03622,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2', 218.1),
            ('N1/N1~', 110.2),
            ('N1', 110.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : 'SRWZ_15',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0211923,
        'r_expected' : 0.03070016,
        'Width (GeV)' : [
            ('C1+/C1-', 0.042543),
            ('N2', 0.024877),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.06985445,
        'l_max' : 0.1166689,
        'l_SM' : 0.0635299
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2016-24,ATLAS-SUSY-2018-32,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
        'r' : 13.66234,
        'r_expected' : 14.0661,
        'likelihood' : 7.162690892159327e-257,
        'l_max' : 4.416296814371049e-146,
        'l_SM' : 4.3860014330517265e-146
    }
],
'Total xsec for missing topologies (fb)' : 80.18079,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 56.12657,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 24.05422,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 80.18079,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 56.12657,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 24.05422,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}
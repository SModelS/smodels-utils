smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm481.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 10.40068,
        'upper limit (fb)' : 0.3587319,
        'expected upper limit (fb)' : 0.3634456,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 101.3),
            ('N1', 101.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 28.9929,
        'r_expected' : 28.61687,
        'Width (GeV)' : [
            ('C1-', 0.0595680065),
            ('C1+', 0.0595680065),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.74553,
        'upper limit (fb)' : 0.518,
        'expected upper limit (fb)' : 0.555,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 101.3),
            ('N1', 101.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWb-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 5.30025,
        'r_expected' : 4.9469,
        'Width (GeV)' : [
            ('C1-', 0.0595680065),
            ('C1+', 0.0595680065),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.514984e-15,
        'l_max' : 0.01441039,
        'l_SM' : 0.01441039
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.068073,
        'upper limit (fb)' : 0.4330955,
        'expected upper limit (fb)' : 0.4842181,
        'TxNames' : ['TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 4.775098,
        'r_expected' : 4.270954,
        'Width (GeV)' : None,
        'likelihood' : 1.7011384214438766e-96,
        'l_max' : 1.0563691620372995e-81,
        'l_SM' : 1.0563691620372995e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.231329,
        'upper limit (fb)' : 1.498769,
        'expected upper limit (fb)' : 1.775157,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8215601,
        'r_expected' : 0.6936451,
        'Width (GeV)' : None,
        'likelihood' : 9.194175886942752e-73,
        'l_max' : 4.2441968280750914e-72,
        'l_SM' : 4.2441968280750914e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.065854,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.7895217,
        'r_expected' : 1.044955,
        'Width (GeV)' : None,
        'likelihood' : 0.001183601,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.194636,
        'upper limit (fb)' : 2.16972,
        'expected upper limit (fb)' : 1.534184,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.5505946,
        'r_expected' : 0.7786784,
        'Width (GeV)' : None,
        'likelihood' : 4.6832990000000007e-20,
        'l_max' : 5.3274370000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1416232,
        'upper limit (fb)' : 0.3669602,
        'expected upper limit (fb)' : 0.2728662,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3859361,
        'r_expected' : 0.5190206,
        'Width (GeV)' : None,
        'likelihood' : 1.7496190000000002e-24,
        'l_max' : 1.7727500000000003e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01836889,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.127,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2/N3', 219.92),
            ('N1/N1~', 101.3),
            ('N1', 101.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.2040988,
        'r_expected' : 0.1446369,
        'Width (GeV)' : [
            ('C1+/C1-', 0.059568),
            ('N2/N3', 0.026242),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1372857,
        'l_max' : 0.2014847,
        'l_SM' : 0.2014847
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.006355697,
        'upper limit (fb)' : 0.0756,
        'expected upper limit (fb)' : 0.0842,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2', 218.1),
            ('N1/N1~', 101.3),
            ('N1', 101.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SRLow2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.08407007,
        'r_expected' : 0.07548334,
        'Width (GeV)' : [
            ('C1+/C1-', 0.059568),
            ('N2', 0.040189),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01294697,
        'l_max' : 0.01363736,
        'l_SM' : 0.01363736
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03383217,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2/N3', 219.91),
            ('N1/N1~', 101.3),
            ('N1', 101.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.08055279,
        'r_expected' : 0.1780641,
        'Width (GeV)' : [
            ('C1+/C1-', 0.059568),
            ('N2/N3', 0.026316),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003071699,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
        'r' : 29.81931,
        'r_expected' : 29.63038,
        'likelihood' : 0.0,
        'l_max' : 2.6267273375183554e-169,
        'l_SM' : 2.6267273375183554e-169
    }
],
'Total xsec for missing topologies (fb)' : 76.12277,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 57.09209,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 16.31201,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.718671,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 76.12277,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 57.09209,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 16.31201,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.718671,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}
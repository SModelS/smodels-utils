smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 18,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2016-07,ATLAS-SUSY-2013-02,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm24.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.402255,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.6462006,
        'r_expected' : 0.664576,
        'Width (GeV)' : [
            ('C1-', 2.9612e-05),
            ('C1+', 2.9612e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0001211512,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1708167,
        'upper limit (fb)' : 0.50301,
        'expected upper limit (fb)' : 0.88617,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.3395891,
        'r_expected' : 0.1927584,
        'Width (GeV)' : [
            ('C1-', 2.9612e-05),
            ('C1+', 2.9612e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0006678359,
        'l_max' : 0.001434466,
        'l_SM' : 0.001434466
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06395525,
        'upper limit (fb)' : 0.1976019,
        'expected upper limit (fb)' : 0.2006056,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 220.5),
            ('C1+/C1-', 214.8),
            ('N1', 179.7),
            ('N1/N1~', 179.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.323657,
        'r_expected' : 0.318811,
        'Width (GeV)' : [
            ('N2', 4.906e-05),
            ('C1+/C1-', 2.9612e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 3.2052070000000004e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3313549,
        'upper limit (fb)' : 1.34,
        'expected upper limit (fb)' : 0.833,
        'TxNames' : ['T1bbbb', 'T6bbWWoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_600MHTinf',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.2472798,
        'r_expected' : 0.397785,
        'Width (GeV)' : None,
        'likelihood' : 0.005058983,
        'l_max' : 0.005396484,
        'l_SM' : 0.002530291
    },
    {
        'maxcond' : 1.2406791149377587e-06,
        'theory prediction (fb)' : 0.08357308,
        'upper limit (fb)' : 0.813,
        'expected upper limit (fb)' : 1.19,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-SF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1027959,
        'r_expected' : 0.07022948,
        'Width (GeV)' : [
            ('C1-', 2.9612e-05),
            ('C1+', 2.9612e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001060349,
        'l_max' : 0.001267591,
        'l_SM' : 0.001267591
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03568186,
        'upper limit (fb)' : 1.012368,
        'expected upper limit (fb)' : 1.210668,
        'TxNames' : ['TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.03524594,
        'r_expected' : 0.02947287,
        'Width (GeV)' : None,
        'likelihood' : 0.1111139,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00146158,
        'upper limit (fb)' : 0.07365478,
        'expected upper limit (fb)' : 0.1475984,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01984365,
        'r_expected' : 0.009902412,
        'Width (GeV)' : None,
        'likelihood' : 1.0239690000000002e-32,
        'l_max' : 1.0786820000000003e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02842767,
        'upper limit (fb)' : 1.556756,
        'expected upper limit (fb)' : 1.232946,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 220.5),
            ('C1+/C1-', 214.8),
            ('N1', 179.7),
            ('N1/N1~', 179.7)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01826084,
        'r_expected' : 0.02305671,
        'Width (GeV)' : [
            ('N2', 4.906e-05),
            ('C1+/C1-', 2.9612e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.386677532427511e-72,
        'l_max' : 5.336873496440659e-72,
        'l_SM' : 4.2441968280750914e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0007420418,
        'upper limit (fb)' : 1.228668,
        'expected upper limit (fb)' : 0.751451,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 220.5),
            ('C1+/C1-', 214.8),
            ('N1', 179.7),
            ('N1/N1~', 179.7)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0006039402,
        'r_expected' : 0.0009874786,
        'Width (GeV)' : [
            ('N2', 4.906e-05),
            ('C1+/C1-', 2.9612e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.7673290000000004e-20,
        'l_max' : 5.586728e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.080011e-05,
        'upper limit (fb)' : 3.17,
        'expected upper limit (fb)' : 5.0,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('N3', 250.6),
            ('C1+/C1-/N2', 216.34),
            ('N1', 179.7),
            ('N1/N1~', 179.7)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR11_Njet7_Nb1_HT300_MHT300',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 1.917984e-05,
        'r_expected' : 1.216002e-05,
        'Width (GeV)' : [
            ('N3', 6.9889e-05),
            ('C1+/C1-/N2', 3.4869e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.347589e-05,
        'l_max' : 4.347692e-05,
        'l_SM' : 4.347692e-05
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-02,ATLAS-SUSY-2016-07,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.8753133,
        'r_expected' : 0.9453151,
        'likelihood' : 1.311948821837437e-47,
        'l_max' : 4.884975653628561e-47,
        'l_SM' : 4.801687723232107e-47
    }
],
'Total xsec for missing topologies (fb)' : 6195.623,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3853.811,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1283.848,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 337.957,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 317.6867,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 168.3596,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 41.68743,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 33.76208,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.63102,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.34043,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 16.78028,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 6195.623,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3853.811,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1283.848,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 337.957,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 317.6867,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 168.3596,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 41.68743,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 33.76208,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.63102,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.34043,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 16.78028,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7470.867,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7449.127,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.15955,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.285754,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2340127,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04053432,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02006035,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
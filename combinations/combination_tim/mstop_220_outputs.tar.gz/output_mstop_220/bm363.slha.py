smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2016-07,CMS-SUS-16-033,ATLAS-SUSY-2019-09,ATLAS-SUSY-2013-02,ATLAS-SUSY-2013-11,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm363.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.763079,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 155.6),
            ('N1', 155.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 1.273308,
        'r_expected' : 1.309516,
        'Width (GeV)' : [
            ('C1-', 0.00024533),
            ('C1+', 0.00024533),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 7.900963e-06,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.691115,
        'upper limit (fb)' : 4.1,
        'expected upper limit (fb)' : 3.72,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 155.6),
            ('N1', 155.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR3_Njet5_Nb0_HT500_MHT_500',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.9002719,
        'r_expected' : 0.9922352,
        'Width (GeV)' : [
            ('C1-', 0.00024533),
            ('C1+', 0.00024533),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.697829e-05,
        'l_max' : 9.755716e-05,
        'l_SM' : 9.555076e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2747307,
        'upper limit (fb)' : 0.3262875,
        'expected upper limit (fb)' : 0.3228456,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.8419897,
        'r_expected' : 0.8509662,
        'Width (GeV)' : None,
        'likelihood' : 1.1433410000000001e-38,
        'l_max' : 4.4313790000000005e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.424354,
        'upper limit (fb)' : 13.292,
        'expected upper limit (fb)' : 11.561,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 155.6),
            ('N1', 155.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jlm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.2576252,
        'r_expected' : 0.2961988,
        'Width (GeV)' : [
            ('C1-', 0.00024533),
            ('C1+', 0.00024533),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 3.0611e-05,
        'l_max' : 3.106569e-05,
        'l_SM' : 2.855812e-05
    },
    {
        'maxcond' : 1.6822543121549677e-06,
        'theory prediction (fb)' : 0.161239,
        'upper limit (fb)' : 1.07,
        'expected upper limit (fb)' : 1.17,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 155.6),
            ('N1', 155.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1506906,
        'r_expected' : 0.1378111,
        'Width (GeV)' : [
            ('C1-', 0.00024533),
            ('C1+', 0.00024533),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002018685,
        'l_max' : 0.002291271,
        'l_SM' : 0.002291271
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1692205,
        'upper limit (fb)' : 1.844099,
        'expected upper limit (fb)' : 1.282911,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.09176324,
        'r_expected' : 0.1319035,
        'Width (GeV)' : None,
        'likelihood' : 5.46252732986819e-72,
        'l_max' : 7.337991717437814e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001144292,
        'upper limit (fb)' : 0.241,
        'expected upper limit (fb)' : 0.272,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2', 220.7),
            ('N1/N1~', 155.6),
            ('N1', 155.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : 'stop_highMET_PT_20to30',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.004748101,
        'r_expected' : 0.004206957,
        'Width (GeV)' : [
            ('C1+/C1-', 0.00024533),
            ('N2', 0.00028472),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.02031031,
        'l_max' : 0.02036404,
        'l_SM' : 0.02036404
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00654165,
        'upper limit (fb)' : 2.053874,
        'expected upper limit (fb)' : 1.096042,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.003185029,
        'r_expected' : 0.005968431,
        'Width (GeV)' : None,
        'likelihood' : 2.8310990000000003e-20,
        'l_max' : 1.6988620000000001e-19,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.491943e-05,
        'upper limit (fb)' : 1.04,
        'expected upper limit (fb)' : 0.936,
        'TxNames' : ['T1bbbb'],
        'Mass (GeV)' : [('N3', 234.9), ('N2', 220.7), ('N1', 155.6)],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 5.280715e-05,
        'r_expected' : 5.867461e-05,
        'Width (GeV)' : [
            ('N3', 4.2002138e-05),
            ('N2', 0.000284723098),
            ('N1', 'stable')
        ],
        'likelihood' : 0.004373388,
        'l_max' : 0.004463612,
        'l_SM' : 0.004373275
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-02,ATLAS-SUSY-2013-11,ATLAS-SUSY-2016-07,ATLAS-SUSY-2019-09,CMS-SUS-16-033,CMS-SUS-16-039',
        'r' : 1.815626,
        'r_expected' : 1.99212,
        'likelihood' : 5.177134837192685e-127,
        'l_max' : 3.649762250707183e-124,
        'l_SM' : 3.510500285979441e-124
    }
],
'Total xsec for missing topologies (fb)' : 6175.67,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3904.947,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1295.8,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 357.1043,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 323.4562,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 151.8188,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 37.4482,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.69556,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 12.61611,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11.1857,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.77329,
        'SMS' : 'PV > (nu,l,MET), (b,b,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 6175.67,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3904.947,
        'SMS' : 'PV > (jet,jet,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1295.8,
        'SMS' : 'PV > (nu,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 357.1043,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 323.4562,
        'SMS' : 'PV > (nu,ta,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 151.8188,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 37.4482,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.69556,
        'SMS' : 'PV > (MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 12.61611,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11.1857,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.77329,
        'SMS' : 'PV > (nu,l,MET), (b,b,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7523.917,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7464.713,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 42.20173,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.86642,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.079282,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.056778,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
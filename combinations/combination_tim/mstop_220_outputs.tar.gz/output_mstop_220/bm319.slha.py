smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm319.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1883615,
        'upper limit (fb)' : 0.233051,
        'expected upper limit (fb)' : 0.2222893,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 162.5),
            ('C1+/C1-', 156.4),
            ('N1', 125.4),
            ('N1/N1~', 125.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.8082417,
        'r_expected' : 0.8473711,
        'Width (GeV)' : [
            ('N2', 3.0745e-05),
            ('C1+/C1-', 1.6438e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 1.2986360000000002e-38,
        'l_max' : 4.4273100000000005e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8699414,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('C1-', 156.4),
            ('C1+', 156.4),
            ('N1~', 125.4),
            ('N1', 125.4)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.644401,
        'r_expected' : 0.8528837,
        'Width (GeV)' : [
            ('su_L~', 0.8358),
            ('su_L', 0.8358),
            ('C1-', 1.6438e-05),
            ('C1+', 1.6438e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002029047,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.08574285,
        'upper limit (fb)' : 0.8373956,
        'expected upper limit (fb)' : 1.001085,
        'TxNames' : ['TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1023923,
        'r_expected' : 0.08564994,
        'Width (GeV)' : None,
        'likelihood' : 0.103051,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04410009,
        'upper limit (fb)' : 1.1187,
        'expected upper limit (fb)' : 0.9320859,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 162.5),
            ('C1+/C1-', 156.4),
            ('N1', 125.4),
            ('N1/N1~', 125.4)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.03942084,
        'r_expected' : 0.04731334,
        'Width (GeV)' : [
            ('N2', 3.0745e-05),
            ('C1+/C1-', 1.6438e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.421908600151857e-72,
        'l_max' : 4.70191148028491e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00502228,
        'upper limit (fb)' : 0.3355153,
        'expected upper limit (fb)' : 0.199963,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 156.4),
            ('N2', 162.5),
            ('N1/N1~', 125.4),
            ('N1', 125.4)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01496885,
        'r_expected' : 0.02511604,
        'Width (GeV)' : [
            ('C1+/C1-', 1.6438e-05),
            ('N2', 3.0745e-05),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.1486720000000002e-32,
        'l_max' : 1.8804710000000003e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05641256,
        'upper limit (fb)' : 13.292,
        'expected upper limit (fb)' : 11.561,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1+/C1-/N2', 159.9),
            ('C1+/C1-', 156.4),
            ('N1/N1~', 125.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jlm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.004244098,
        'r_expected' : 0.004879557,
        'Width (GeV)' : [
            ('C1+/C1-/N2', 2.4639e-05),
            ('C1+/C1-', 1.6438e-05),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.866939e-05,
        'l_max' : 3.106569e-05,
        'l_SM' : 2.855812e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.004629083,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [('C1+/C1-', 156.4), ('N1/N1~', 125.4)],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.002133218,
        'r_expected' : 0.002193878,
        'Width (GeV)' : [('C1+/C1-', 1.6438e-05), ('N1/N1~', 'stable')],
        'likelihood' : 0.0002988981,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00156339,
        'upper limit (fb)' : 2.050119,
        'expected upper limit (fb)' : 1.46637,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 162.5),
            ('C1+/C1-', 156.4),
            ('N1', 125.4),
            ('N1/N1~', 125.4)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0007625853,
        'r_expected' : 0.001066163,
        'Width (GeV)' : [
            ('N2', 3.0745e-05),
            ('C1+/C1-', 1.6438e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.765724e-20,
        'l_max' : 4.3509370000000005e-20,
        'l_SM' : 2.7600510000000006e-20
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 1.035833,
        'r_expected' : 1.285812,
        'likelihood' : 2.634993156609483e-41,
        'l_max' : 1.550932e-40,
        'l_SM' : 1.3366570000000001e-40
    }
],
'Total xsec for missing topologies (fb)' : 9725.857,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3721.279,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1262.372,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1244.849,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 671.9181,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 637.7269,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 306.8922,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 218.8522,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.3336,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.3336,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 167.3914,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 9725.857,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3721.279,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1262.372,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1244.849,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 671.9181,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 637.7269,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 306.8922,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 218.8522,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.3336,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.3336,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 167.3914,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7634.747,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7547.325,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 59.33981,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 24.07834,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.262425,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5458084,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09882539,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04872678,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04831711,
        'SMS' : 'PV > (MET), (l,l,MET)'
    }
]
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm319.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1883615,
        'upper limit (fb)' : 0.233051,
        'expected upper limit (fb)' : 0.2222893,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 162.5),
            ('C1+/C1-', 156.4),
            ('N1', 125.4),
            ('N1/N1~', 125.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.8082417,
        'r_expected' : 0.8473711,
        'Width (GeV)' : [
            ('N2', 3.0745e-05),
            ('C1+/C1-', 1.6438e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 1.2986360000000002e-38,
        'l_max' : 4.4273100000000005e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8699414,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('C1-', 156.4),
            ('C1+', 156.4),
            ('N1~', 125.4),
            ('N1', 125.4)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.644401,
        'r_expected' : 0.8528837,
        'Width (GeV)' : [
            ('su_L~', 0.8358),
            ('su_L', 0.8358),
            ('C1-', 1.6438e-05),
            ('C1+', 1.6438e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002029047,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.08574285,
        'upper limit (fb)' : 0.8373956,
        'expected upper limit (fb)' : 1.001085,
        'TxNames' : ['TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1023923,
        'r_expected' : 0.08564994,
        'Width (GeV)' : None,
        'likelihood' : 0.103051,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04410009,
        'upper limit (fb)' : 1.1187,
        'expected upper limit (fb)' : 0.9320859,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 162.5),
            ('C1+/C1-', 156.4),
            ('N1', 125.4),
            ('N1/N1~', 125.4)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.03942084,
        'r_expected' : 0.04731334,
        'Width (GeV)' : [
            ('N2', 3.0745e-05),
            ('C1+/C1-', 1.6438e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.421908600151857e-72,
        'l_max' : 4.70191148028491e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00502228,
        'upper limit (fb)' : 0.3355153,
        'expected upper limit (fb)' : 0.199963,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 156.4),
            ('N2', 162.5),
            ('N1/N1~', 125.4),
            ('N1', 125.4)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01496885,
        'r_expected' : 0.02511604,
        'Width (GeV)' : [
            ('C1+/C1-', 1.6438e-05),
            ('N2', 3.0745e-05),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.1486720000000002e-32,
        'l_max' : 1.8804710000000003e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05641256,
        'upper limit (fb)' : 13.292,
        'expected upper limit (fb)' : 11.561,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1+/C1-/N2', 159.9),
            ('C1+/C1-', 156.4),
            ('N1/N1~', 125.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jlm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.004244098,
        'r_expected' : 0.004879557,
        'Width (GeV)' : [
            ('C1+/C1-/N2', 2.4639e-05),
            ('C1+/C1-', 1.6438e-05),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.866939e-05,
        'l_max' : 3.106569e-05,
        'l_SM' : 2.855812e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.004629083,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [('C1+/C1-', 156.4), ('N1/N1~', 125.4)],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.002133218,
        'r_expected' : 0.002193878,
        'Width (GeV)' : [('C1+/C1-', 1.6438e-05), ('N1/N1~', 'stable')],
        'likelihood' : 0.0002988981,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00156339,
        'upper limit (fb)' : 2.050119,
        'expected upper limit (fb)' : 1.46637,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 162.5),
            ('C1+/C1-', 156.4),
            ('N1', 125.4),
            ('N1/N1~', 125.4)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0007625853,
        'r_expected' : 0.001066163,
        'Width (GeV)' : [
            ('N2', 3.0745e-05),
            ('C1+/C1-', 1.6438e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.765724e-20,
        'l_max' : 4.3509370000000005e-20,
        'l_SM' : 2.7600510000000006e-20
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 1.035833,
        'r_expected' : 1.285812,
        'likelihood' : 2.634993156609483e-41,
        'l_max' : 1.550932e-40,
        'l_SM' : 1.3366570000000001e-40
    }
],
'Total xsec for missing topologies (fb)' : 9725.857,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3721.279,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1262.372,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1244.849,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 671.9181,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 637.7269,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 306.8922,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 218.8522,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.3336,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.3336,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 167.3914,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 9725.857,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3721.279,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1262.372,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1244.849,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 671.9181,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 637.7269,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 306.8922,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 218.8522,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.3336,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 213.3336,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 167.3914,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7634.747,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7547.325,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 59.33981,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 24.07834,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.262425,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5458084,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09882539,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04872678,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04831711,
        'SMS' : 'PV > (MET), (l,l,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2018-41,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-21-002',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm634.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03737065,
        'upper limit (fb)' : 0.03581938,
        'expected upper limit (fb)' : 0.05134032,
        'TxNames' : [
            'TChiHH',
            'TChiWH',
            'TChiWW',
            'TChiWZ',
            'TChiZH',
            'TChiZZ'
        ],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-41',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 1.043308,
        'r_expected' : 0.7279007,
        'Width (GeV)' : None,
        'likelihood' : 0.0002154107,
        'l_max' : 0.002358157,
        'l_SM' : 0.002358157
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.379583,
        'upper limit (fb)' : 1.347,
        'expected upper limit (fb)' : 1.303,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.1),
            ('su_L', 220.1),
            ('N1~', 184.7),
            ('N1', 184.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-05',
        'DataSetID' : 'SRB',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.1,
        'dataType' : 'efficiencyMap',
        'r' : 1.024189,
        'r_expected' : 1.058774,
        'Width (GeV)' : [
            ('su_L~', 0.195445583),
            ('su_L', 0.195445583),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002485602,
        'l_max' : 0.001971545,
        'l_SM' : 0.00196557
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1696581,
        'upper limit (fb)' : 0.3283808,
        'expected upper limit (fb)' : 0.3926746,
        'TxNames' : ['TChiWWoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.5166503,
        'r_expected' : 0.4320576,
        'Width (GeV)' : None,
        'likelihood' : 0.04840897,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.56738,
        'upper limit (fb)' : 27.19,
        'expected upper limit (fb)' : 27.57,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.1),
            ('su_L', 220.1),
            ('N1~', 184.7),
            ('N1', 184.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-21',
        'DataSetID' : 'M2',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.4989842,
        'r_expected' : 0.4921067,
        'Width (GeV)' : [
            ('su_L~', 0.195445583),
            ('su_L', 0.195445583),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 3.801438e-06,
        'l_max' : 6.346427e-06,
        'l_SM' : 6.346427e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.126021,
        'upper limit (fb)' : 2.88,
        'expected upper limit (fb)' : 2.01,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.1),
            ('su_L', 220.1),
            ('N1~', 184.7),
            ('N1', 184.7)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.3909796,
        'r_expected' : 0.5602096,
        'Width (GeV)' : [
            ('su_L~', 0.195445583),
            ('su_L', 0.195445583),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0009051769,
        'l_max' : 0.0009521956,
        'l_SM' : 0.0006572509
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.109829,
        'upper limit (fb)' : 0.2817164,
        'expected upper limit (fb)' : 0.159688,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.3898565,
        'r_expected' : 0.6877722,
        'Width (GeV)' : None,
        'likelihood' : 3.0493302804263866e-81,
        'l_max' : 3.051616507403693e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.008633729,
        'upper limit (fb)' : 0.03679717,
        'expected upper limit (fb)' : 0.05193548,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 196.7),
            ('C1+/C1-', 191.7),
            ('N1', 184.7),
            ('N1/N1~', 184.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2346303,
        'r_expected' : 0.1662395,
        'Width (GeV)' : [
            ('N2', 1.9855e-07),
            ('C1+/C1-', 1.7769e-08),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.849949e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.5582,
        'upper limit (fb)' : 66.1,
        'expected upper limit (fb)' : 48.8,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.1),
            ('su_L', 220.1),
            ('N1~', 184.7),
            ('N1', 184.7)
        ],
        'AnalysisID' : 'ATLAS-CONF-2013-047',
        'DataSetID' : 'A Loose',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.08408775,
        'r_expected' : 0.1138975,
        'Width (GeV)' : [
            ('su_L~', 0.195445583),
            ('su_L', 0.195445583),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.565908e-06,
        'l_max' : 4.358706e-06,
        'l_SM' : 1.988754e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.006900944,
        'upper limit (fb)' : 0.08513128,
        'expected upper limit (fb)' : 0.04807898,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.08106238,
        'r_expected' : 0.1435335,
        'Width (GeV)' : None,
        'likelihood' : 7.001069862553552e-45,
        'l_max' : 9.51855271994638e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00234818,
        'upper limit (fb)' : 0.1805359,
        'expected upper limit (fb)' : 0.1903075,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01300672,
        'r_expected' : 0.01233888,
        'Width (GeV)' : None,
        'likelihood' : 4.2263478437066574e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002308349,
        'upper limit (fb)' : 0.1785732,
        'expected upper limit (fb)' : 0.1888648,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01292663,
        'r_expected' : 0.01222223,
        'Width (GeV)' : None,
        'likelihood' : 2.753896e-20,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002915972,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 184.7),
            ('N1', 184.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.001343766,
        'r_expected' : 0.001381977,
        'Width (GeV)' : [
            ('C1-', 1.7769e-08),
            ('C1+', 1.7769e-08),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002988716,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2018-41,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-21-002',
        'r' : 1.615253,
        'r_expected' : 1.876454,
        'likelihood' : 5.426404095286665e-180,
        'l_max' : 6.027190296792887e-178,
        'l_SM' : 5.65047944663823e-178
    }
],
'Total xsec for missing topologies (fb)' : 1912.515,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1059.832,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 636.7474,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 181.7957,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.08392,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.22534,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1765818,
        'SMS' : 'PV > (W,MET), (W,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.07925483,
        'SMS' : 'PV > (W,MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.07027901,
        'SMS' : 'PV > (higgs,MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06973487,
        'SMS' : 'PV > (Z,MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06353893,
        'SMS' : 'PV > (higgs,MET), (W,jet,jet,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1912.515,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1059.832,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 636.7474,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 181.7957,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.08392,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.22534,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1765818,
        'SMS' : 'PV > (W,MET), (W,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.07925483,
        'SMS' : 'PV > (W,MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.07027901,
        'SMS' : 'PV > (higgs,MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06973487,
        'SMS' : 'PV > (Z,MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06353893,
        'SMS' : 'PV > (higgs,MET), (W,jet,jet,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 165.6208,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 146.1871,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11.439,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.994721,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    }
]
}
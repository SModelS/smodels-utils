smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-21,CMS-SUS-13-012,ATLAS-SUSY-2018-16,ATLAS-SUSY-2013-05',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm861.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 22.10252,
        'upper limit (fb)' : 27.19,
        'expected upper limit (fb)' : 27.57,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('N1~', 203.2),
            ('N1', 203.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-21',
        'DataSetID' : 'M2',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.8128915,
        'r_expected' : 0.8016874,
        'Width (GeV)' : [
            ('su_L~', 0.0473543258),
            ('su_L', 0.0473543258),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.709808e-06,
        'l_max' : 6.346427e-06,
        'l_SM' : 6.346427e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8676198,
        'upper limit (fb)' : 1.22,
        'expected upper limit (fb)' : 1.38,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('N1~', 203.2),
            ('N1', 203.2)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_600MHTinf',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.7111637,
        'r_expected' : 0.62871,
        'Width (GeV)' : [
            ('su_L~', 0.0473543258),
            ('su_L', 0.0473543258),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0006272271,
        'l_max' : 0.002211824,
        'l_SM' : 0.002211824
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0666875,
        'upper limit (fb)' : 0.2849737,
        'expected upper limit (fb)' : 0.3407202,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2340128,
        'r_expected' : 0.1957251,
        'Width (GeV)' : None,
        'likelihood' : 0.08530827,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3141485,
        'upper limit (fb)' : 1.347,
        'expected upper limit (fb)' : 1.303,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('N1~', 203.2),
            ('N1', 203.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-05',
        'DataSetID' : 'SRB',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.2332209,
        'r_expected' : 0.2410963,
        'Width (GeV)' : [
            ('su_L~', 0.0473543258),
            ('su_L', 0.0473543258),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001811148,
        'l_max' : 0.001971545,
        'l_SM' : 0.00196557
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.249401,
        'upper limit (fb)' : 66.1,
        'expected upper limit (fb)' : 48.8,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('N1~', 203.2),
            ('N1', 203.2)
        ],
        'AnalysisID' : 'ATLAS-CONF-2013-047',
        'DataSetID' : 'A Loose',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.03403028,
        'r_expected' : 0.04609429,
        'Width (GeV)' : [
            ('su_L~', 0.0473543258),
            ('su_L', 0.0473543258),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.218062e-06,
        'l_max' : 4.358706e-06,
        'l_SM' : 1.988754e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0009863103,
        'upper limit (fb)' : 0.68,
        'expected upper limit (fb)' : 0.511,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 206.9),
            ('C1+', 206.9),
            ('N1~', 203.2),
            ('N1', 203.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '5j_Meff_1700',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.001450456,
        'r_expected' : 0.001930157,
        'Width (GeV)' : [
            ('C1-', 6.064e-10),
            ('C1+', 6.064e-10),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003538664,
        'l_max' : 0.004539557,
        'l_SM' : 0.003527935
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,CMS-SUS-13-012',
        'r' : 1.236934,
        'r_expected' : 1.132114,
        'likelihood' : 1.65698e-13,
        'l_max' : 3.170201e-12,
        'l_SM' : 3.170201e-12
    }
],
'Total xsec for missing topologies (fb)' : 1550.282,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 919.4195,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 630.8627,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1550.282,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 919.4195,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 630.8627,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 130.6327,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 114.1373,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.989747,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.464851,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.040829,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
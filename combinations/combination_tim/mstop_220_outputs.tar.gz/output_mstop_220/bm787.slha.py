smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm787.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 15.05717,
        'upper limit (fb)' : 3.17,
        'expected upper limit (fb)' : 5.0,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('N1~', 171.0),
            ('N1', 171.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR11_Njet7_Nb1_HT300_MHT300',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 4.749897,
        'r_expected' : 3.011435,
        'Width (GeV)' : [
            ('su_L~', 0.437254757),
            ('su_L', 0.437254757),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.974773e-16,
        'l_max' : 4.347692e-05,
        'l_SM' : 4.347692e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.843608,
        'upper limit (fb)' : 1.347,
        'expected upper limit (fb)' : 1.303,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('N1~', 171.0),
            ('N1', 171.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-05',
        'DataSetID' : 'SRB',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.1,
        'dataType' : 'efficiencyMap',
        'r' : 1.368677,
        'r_expected' : 1.414895,
        'Width (GeV)' : [
            ('su_L~', 0.437254757),
            ('su_L', 0.437254757),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 4.840033e-05,
        'l_max' : 0.001971545,
        'l_SM' : 0.00196557
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1930831,
        'upper limit (fb)' : 0.3296251,
        'expected upper limit (fb)' : 0.3943011,
        'TxNames' : ['TChiWWoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.5857659,
        'r_expected' : 0.4896846,
        'Width (GeV)' : None,
        'likelihood' : 0.0410057,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.1562,
        'upper limit (fb)' : 27.19,
        'expected upper limit (fb)' : 27.57,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('N1~', 171.0),
            ('N1', 171.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-21',
        'DataSetID' : 'M2',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.4103054,
        'r_expected' : 0.4046501,
        'Width (GeV)' : [
            ('su_L~', 0.437254757),
            ('su_L', 0.437254757),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 4.456804e-06,
        'l_max' : 6.346427e-06,
        'l_SM' : 6.346427e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.037266,
        'upper limit (fb)' : 2.88,
        'expected upper limit (fb)' : 2.01,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('N1~', 171.0),
            ('N1', 171.0)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.3601619,
        'r_expected' : 0.5160528,
        'Width (GeV)' : [
            ('su_L~', 0.437254757),
            ('su_L', 0.437254757),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0009282022,
        'l_max' : 0.0009521956,
        'l_SM' : 0.0006572509
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.006084746,
        'upper limit (fb)' : 0.03183322,
        'expected upper limit (fb)' : 0.04751756,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 181.4),
            ('C1+/C1-', 176.6),
            ('N1', 171.0),
            ('N1/N1~', 171.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1911445,
        'r_expected' : 0.1280526,
        'Width (GeV)' : [
            ('N2', 9.3408e-08),
            ('C1+/C1-', 5.3481e-09),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 3.03597e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.342361,
        'upper limit (fb)' : 66.1,
        'expected upper limit (fb)' : 48.8,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('N1~', 171.0),
            ('N1', 171.0)
        ],
        'AnalysisID' : 'ATLAS-CONF-2013-047',
        'DataSetID' : 'A Loose',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1110796,
        'r_expected' : 0.1504582,
        'Width (GeV)' : [
            ('su_L~', 0.437254757),
            ('su_L', 0.437254757),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.755314e-06,
        'l_max' : 4.358706e-06,
        'l_SM' : 1.988754e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002797551,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 176.6),
            ('C1+', 176.6),
            ('N1~', 171.0),
            ('N1', 171.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.001289194,
        'r_expected' : 0.001325854,
        'Width (GeV)' : [
            ('C1-', 5.3481e-09),
            ('C1+', 5.3481e-09),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002988698,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0004118831,
        'upper limit (fb)' : 0.8576927,
        'expected upper limit (fb)' : 0.8133494,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 181.4),
            ('C1+/C1-', 176.6),
            ('N1', 171.0),
            ('N1/N1~', 171.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0004802222,
        'r_expected' : 0.0005064036,
        'Width (GeV)' : [
            ('N2', 9.3408e-08),
            ('C1+/C1-', 5.3481e-09),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.2441834294800853e-72,
        'l_max' : 3.856096077791653e-72,
        'l_SM' : 4.2441968280598925e-72
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033',
        'r' : 4.824365,
        'r_expected' : 3.714914,
        'likelihood' : 7.4149814248988036e-68,
        'l_max' : 1.8131894229970677e-54,
        'l_SM' : 1.8131894229970677e-54
    }
],
'Total xsec for missing topologies (fb)' : 2283.129,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1167.738,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 817.2223,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 263.7775,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 25.11719,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.274703,
        'SMS' : 'PV > (MET), (b,b,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 2283.129,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1167.738,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 817.2223,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 263.7775,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 25.11719,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.274703,
        'SMS' : 'PV > (MET), (b,b,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 205.5131,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 188.4721,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.41415,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.626885,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm422.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.064987,
        'upper limit (fb)' : 1.326655,
        'expected upper limit (fb)' : 1.629836,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8027614,
        'r_expected' : 0.6534322,
        'Width (GeV)' : None,
        'likelihood' : 9.460183341001057e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8864326,
        'upper limit (fb)' : 1.20612,
        'expected upper limit (fb)' : 1.372714,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.7349459,
        'r_expected' : 0.6457516,
        'Width (GeV)' : None,
        'likelihood' : 8.322765e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8825948,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.6537739,
        'r_expected' : 0.865289,
        'Width (GeV)' : None,
        'likelihood' : 0.001968797,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.137097,
        'upper limit (fb)' : 0.2818005,
        'expected upper limit (fb)' : 0.3256572,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 73.5),
            ('N1', 73.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4865038,
        'r_expected' : 0.4209855,
        'Width (GeV)' : [
            ('C1-', 0.0919940191),
            ('C1+', 0.0919940191),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 8.360100114970828e-41,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.168091,
        'upper limit (fb)' : 0.3538312,
        'expected upper limit (fb)' : 0.3052907,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4750599,
        'r_expected' : 0.5505935,
        'Width (GeV)' : None,
        'likelihood' : 1.0655190000000002e-24,
        'l_max' : 1.3290590000000002e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03227911,
        'upper limit (fb)' : 0.1,
        'expected upper limit (fb)' : 0.124,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.75),
            ('N1/N1~', 73.5),
            ('N1', 73.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-0Jb',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.3227911,
        'r_expected' : 0.2603154,
        'Width (GeV)' : [
            ('C1+/C1-', 0.091994),
            ('N2/N3', 0.066271),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.06914755,
        'l_max' : 0.151876,
        'l_SM' : 0.151876
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07182768,
        'upper limit (fb)' : 0.6166852,
        'expected upper limit (fb)' : 1.058185,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.1164738,
        'r_expected' : 0.06787822,
        'Width (GeV)' : None,
        'likelihood' : 8.840710007310161e-82,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05954183,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 73.5),
            ('N1', 73.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1037314,
        'r_expected' : 0.09217002,
        'Width (GeV)' : [
            ('C1-', 0.0919940191),
            ('C1+', 0.0919940191),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.007885241,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.007136947,
        'upper limit (fb)' : 0.07235045,
        'expected upper limit (fb)' : 0.06065576,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.09864413,
        'r_expected' : 0.1176631,
        'Width (GeV)' : None,
        'likelihood' : 5.152371223264177e-45,
        'l_max' : 5.438918390194371e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02069709,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.75),
            ('N1/N1~', 73.5),
            ('N1', 73.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.0492788,
        'r_expected' : 0.1089321,
        'Width (GeV)' : [
            ('C1+/C1-', 0.091994),
            ('N2/N3', 0.0663),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001885081,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0007323158,
        'upper limit (fb)' : 0.089,
        'expected upper limit (fb)' : 0.0662,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.75),
            ('N1/N1~', 73.5),
            ('N1', 73.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SROffShell_2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.008228267,
        'r_expected' : 0.01106217,
        'Width (GeV)' : [
            ('C1+/C1-', 0.091994),
            ('N2/N3', 0.066282),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01822081,
        'l_max' : 0.02150842,
        'l_SM' : 0.01795068
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0003224911,
        'upper limit (fb)' : 0.2407912,
        'expected upper limit (fb)' : 0.1763776,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 214.5), ('N2', 213.4), ('N1', 73.5)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.001339298,
        'r_expected' : 0.001828413,
        'Width (GeV)' : [
            ('N3', 0.0593811186),
            ('N2', 0.0694903367),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6199620000000004e-34,
        'l_max' : 2.2158170000000005e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.245355,
        'r_expected' : 1.380968,
        'likelihood' : 8.548314427829726e-184,
        'l_max' : 1.5069580478268937e-182,
        'l_SM' : 1.4431597279572667e-182
    }
],
'Total xsec for missing topologies (fb)' : 1053.514,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 943.6057,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 80.42094,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 26.22113,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.680698,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5858402,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1053.514,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 943.6057,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 80.42094,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 26.22113,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.680698,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5858402,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 74.0276,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 74.0276,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm422.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.064987,
        'upper limit (fb)' : 1.326655,
        'expected upper limit (fb)' : 1.629836,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8027614,
        'r_expected' : 0.6534322,
        'Width (GeV)' : None,
        'likelihood' : 9.460183341001057e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8864326,
        'upper limit (fb)' : 1.20612,
        'expected upper limit (fb)' : 1.372714,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.7349459,
        'r_expected' : 0.6457516,
        'Width (GeV)' : None,
        'likelihood' : 8.322765e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8825948,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.6537739,
        'r_expected' : 0.865289,
        'Width (GeV)' : None,
        'likelihood' : 0.001968797,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.137097,
        'upper limit (fb)' : 0.2818005,
        'expected upper limit (fb)' : 0.3256572,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 73.5),
            ('N1', 73.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4865038,
        'r_expected' : 0.4209855,
        'Width (GeV)' : [
            ('C1-', 0.0919940191),
            ('C1+', 0.0919940191),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 8.360100114970828e-41,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.168091,
        'upper limit (fb)' : 0.3538312,
        'expected upper limit (fb)' : 0.3052907,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4750599,
        'r_expected' : 0.5505935,
        'Width (GeV)' : None,
        'likelihood' : 1.0655190000000002e-24,
        'l_max' : 1.3290590000000002e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03227911,
        'upper limit (fb)' : 0.1,
        'expected upper limit (fb)' : 0.124,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.75),
            ('N1/N1~', 73.5),
            ('N1', 73.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-0Jb',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.3227911,
        'r_expected' : 0.2603154,
        'Width (GeV)' : [
            ('C1+/C1-', 0.091994),
            ('N2/N3', 0.066271),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.06914755,
        'l_max' : 0.151876,
        'l_SM' : 0.151876
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07182768,
        'upper limit (fb)' : 0.6166852,
        'expected upper limit (fb)' : 1.058185,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.1164738,
        'r_expected' : 0.06787822,
        'Width (GeV)' : None,
        'likelihood' : 8.840710007310161e-82,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05954183,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 73.5),
            ('N1', 73.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1037314,
        'r_expected' : 0.09217002,
        'Width (GeV)' : [
            ('C1-', 0.0919940191),
            ('C1+', 0.0919940191),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.007885241,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.007136947,
        'upper limit (fb)' : 0.07235045,
        'expected upper limit (fb)' : 0.06065576,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.09864413,
        'r_expected' : 0.1176631,
        'Width (GeV)' : None,
        'likelihood' : 5.152371223264177e-45,
        'l_max' : 5.438918390194371e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02069709,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.75),
            ('N1/N1~', 73.5),
            ('N1', 73.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.0492788,
        'r_expected' : 0.1089321,
        'Width (GeV)' : [
            ('C1+/C1-', 0.091994),
            ('N2/N3', 0.0663),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001885081,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0007323158,
        'upper limit (fb)' : 0.089,
        'expected upper limit (fb)' : 0.0662,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.75),
            ('N1/N1~', 73.5),
            ('N1', 73.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SROffShell_2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.008228267,
        'r_expected' : 0.01106217,
        'Width (GeV)' : [
            ('C1+/C1-', 0.091994),
            ('N2/N3', 0.066282),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01822081,
        'l_max' : 0.02150842,
        'l_SM' : 0.01795068
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0003224911,
        'upper limit (fb)' : 0.2407912,
        'expected upper limit (fb)' : 0.1763776,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 214.5), ('N2', 213.4), ('N1', 73.5)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.001339298,
        'r_expected' : 0.001828413,
        'Width (GeV)' : [
            ('N3', 0.0593811186),
            ('N2', 0.0694903367),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6199620000000004e-34,
        'l_max' : 2.2158170000000005e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.245355,
        'r_expected' : 1.380968,
        'likelihood' : 8.548314427829726e-184,
        'l_max' : 1.5069580478268937e-182,
        'l_SM' : 1.4431597279572667e-182
    }
],
'Total xsec for missing topologies (fb)' : 1053.514,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 943.6057,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 80.42094,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 26.22113,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.680698,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5858402,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1053.514,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 943.6057,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 80.42094,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 26.22113,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.680698,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5858402,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 74.0276,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 74.0276,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
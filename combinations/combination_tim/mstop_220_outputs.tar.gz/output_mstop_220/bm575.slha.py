smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm575.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.554559,
        'upper limit (fb)' : 1.247736,
        'expected upper limit (fb)' : 1.807538,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 1.245904,
        'r_expected' : 0.8600427,
        'Width (GeV)' : None,
        'likelihood' : 1.893247848394423e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.19695,
        'upper limit (fb)' : 1.346089,
        'expected upper limit (fb)' : 1.44241,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8892056,
        'r_expected' : 0.8298265,
        'Width (GeV)' : None,
        'likelihood' : 5.580360000000001e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.17087,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.8673109,
        'r_expected' : 1.147911,
        'Width (GeV)' : None,
        'likelihood' : 0.0008331456,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2187783,
        'upper limit (fb)' : 0.3854582,
        'expected upper limit (fb)' : 0.31068,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.5675798,
        'r_expected' : 0.7041918,
        'Width (GeV)' : None,
        'likelihood' : 1.026442e-24,
        'l_max' : 1.4132400000000001e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1376685,
        'upper limit (fb)' : 0.3098952,
        'expected upper limit (fb)' : 0.3248601,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 186.6),
            ('C1+', 186.6),
            ('N1~', 49.4),
            ('N1', 49.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.444242,
        'r_expected' : 0.4237777,
        'Width (GeV)' : [
            ('C1-', 0.0894192753),
            ('C1+', 0.0894192753),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.060907e-40,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4632141,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.2,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('C1-', 186.6),
            ('C1+', 186.6),
            ('N1~', 49.4),
            ('N1', 49.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_1bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.3431215,
        'r_expected' : 0.3860117,
        'Width (GeV)' : [
            ('su_L~', 0.273197179),
            ('su_L', 0.273197179),
            ('C1-', 0.0894192753),
            ('C1+', 0.0894192753),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.00216564,
        'l_max' : 0.002394811,
        'l_SM' : 0.002264688
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01049299,
        'upper limit (fb)' : 0.05958077,
        'expected upper limit (fb)' : 0.062655,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1761136,
        'r_expected' : 0.1674724,
        'Width (GeV)' : None,
        'likelihood' : 8.411085e-11,
        'l_max' : 9.107398e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07787062,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 186.6),
            ('C1+', 186.6),
            ('N1~', 49.4),
            ('N1', 49.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1356631,
        'r_expected' : 0.1205428,
        'Width (GeV)' : [
            ('C1-', 0.0894192753),
            ('C1+', 0.0894192753),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0075978,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01288771,
        'upper limit (fb)' : 0.131732,
        'expected upper limit (fb)' : 0.1103647,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.09783275,
        'r_expected' : 0.1167738,
        'Width (GeV)' : None,
        'likelihood' : 5.4405169522056346e-45,
        'l_max' : 5.463002458297908e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02355855,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 186.6),
            ('N2/N3', 193.8),
            ('N1/N1~', 49.4),
            ('N1', 49.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.05609178,
        'r_expected' : 0.1239924,
        'Width (GeV)' : [
            ('C1+/C1-', 0.089419),
            ('N2/N3', 0.062114),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002107017,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00791802,
        'upper limit (fb)' : 0.256,
        'expected upper limit (fb)' : 0.33,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N2/N3', 193.98),
            ('C1+/C1-', 186.6),
            ('N1', 49.4),
            ('N1/N1~', 49.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-12',
        'DataSetID' : 'SR2tau_b',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.03092977,
        'r_expected' : 0.023994,
        'Width (GeV)' : [
            ('N2/N3', 0.056371),
            ('C1+/C1-', 0.089419),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.0588847,
        'l_max' : 0.06174326,
        'l_SM' : 0.06174326
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.013183,
        'upper limit (fb)' : 0.43,
        'expected upper limit (fb)' : 0.329,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 186.6),
            ('N2/N3', 193.8),
            ('N1/N1~', 49.4),
            ('N1', 49.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'SR2-low',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.03065814,
        'r_expected' : 0.04006991,
        'Width (GeV)' : [
            ('C1+/C1-', 0.089419),
            ('N2/N3', 0.06211),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.005332102,
        'l_max' : 0.01400734,
        'l_SM' : 0.004554925
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.000421272,
        'upper limit (fb)' : 0.1677234,
        'expected upper limit (fb)' : 0.1377717,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 194.0), ('N2', 193.7), ('N1', 49.4)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.002511707,
        'r_expected' : 0.003057753,
        'Width (GeV)' : [
            ('N3', 0.0556471454),
            ('N2', 0.0654031172),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6184410000000004e-34,
        'l_max' : 1.7277570000000004e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.628526,
        'r_expected' : 1.787583,
        'likelihood' : 1.2933217675373901e-199,
        'l_max' : 2.675517734886183e-197,
        'l_SM' : 2.583838476626637e-197
    }
],
'Total xsec for missing topologies (fb)' : 1311.266,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1107.841,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 115.4574,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 46.73276,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.33715,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.897612,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1311.266,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1107.841,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 115.4574,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 46.73276,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.33715,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.897612,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 95.38945,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 95.38945,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm575.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.554559,
        'upper limit (fb)' : 1.247736,
        'expected upper limit (fb)' : 1.807538,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 1.245904,
        'r_expected' : 0.8600427,
        'Width (GeV)' : None,
        'likelihood' : 1.893247848394423e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.19695,
        'upper limit (fb)' : 1.346089,
        'expected upper limit (fb)' : 1.44241,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8892056,
        'r_expected' : 0.8298265,
        'Width (GeV)' : None,
        'likelihood' : 5.580360000000001e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.17087,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.8673109,
        'r_expected' : 1.147911,
        'Width (GeV)' : None,
        'likelihood' : 0.0008331456,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2187783,
        'upper limit (fb)' : 0.3854582,
        'expected upper limit (fb)' : 0.31068,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.5675798,
        'r_expected' : 0.7041918,
        'Width (GeV)' : None,
        'likelihood' : 1.026442e-24,
        'l_max' : 1.4132400000000001e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1376685,
        'upper limit (fb)' : 0.3098952,
        'expected upper limit (fb)' : 0.3248601,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 186.6),
            ('C1+', 186.6),
            ('N1~', 49.4),
            ('N1', 49.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.444242,
        'r_expected' : 0.4237777,
        'Width (GeV)' : [
            ('C1-', 0.0894192753),
            ('C1+', 0.0894192753),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.060907e-40,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4632141,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.2,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('C1-', 186.6),
            ('C1+', 186.6),
            ('N1~', 49.4),
            ('N1', 49.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_1bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.3431215,
        'r_expected' : 0.3860117,
        'Width (GeV)' : [
            ('su_L~', 0.273197179),
            ('su_L', 0.273197179),
            ('C1-', 0.0894192753),
            ('C1+', 0.0894192753),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.00216564,
        'l_max' : 0.002394811,
        'l_SM' : 0.002264688
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01049299,
        'upper limit (fb)' : 0.05958077,
        'expected upper limit (fb)' : 0.062655,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1761136,
        'r_expected' : 0.1674724,
        'Width (GeV)' : None,
        'likelihood' : 8.411085e-11,
        'l_max' : 9.107398e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07787062,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 186.6),
            ('C1+', 186.6),
            ('N1~', 49.4),
            ('N1', 49.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1356631,
        'r_expected' : 0.1205428,
        'Width (GeV)' : [
            ('C1-', 0.0894192753),
            ('C1+', 0.0894192753),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0075978,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01288771,
        'upper limit (fb)' : 0.131732,
        'expected upper limit (fb)' : 0.1103647,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.09783275,
        'r_expected' : 0.1167738,
        'Width (GeV)' : None,
        'likelihood' : 5.4405169522056346e-45,
        'l_max' : 5.463002458297908e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02355855,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 186.6),
            ('N2/N3', 193.8),
            ('N1/N1~', 49.4),
            ('N1', 49.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.05609178,
        'r_expected' : 0.1239924,
        'Width (GeV)' : [
            ('C1+/C1-', 0.089419),
            ('N2/N3', 0.062114),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002107017,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00791802,
        'upper limit (fb)' : 0.256,
        'expected upper limit (fb)' : 0.33,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N2/N3', 193.98),
            ('C1+/C1-', 186.6),
            ('N1', 49.4),
            ('N1/N1~', 49.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-12',
        'DataSetID' : 'SR2tau_b',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.03092977,
        'r_expected' : 0.023994,
        'Width (GeV)' : [
            ('N2/N3', 0.056371),
            ('C1+/C1-', 0.089419),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.0588847,
        'l_max' : 0.06174326,
        'l_SM' : 0.06174326
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.013183,
        'upper limit (fb)' : 0.43,
        'expected upper limit (fb)' : 0.329,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 186.6),
            ('N2/N3', 193.8),
            ('N1/N1~', 49.4),
            ('N1', 49.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'SR2-low',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.03065814,
        'r_expected' : 0.04006991,
        'Width (GeV)' : [
            ('C1+/C1-', 0.089419),
            ('N2/N3', 0.06211),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.005332102,
        'l_max' : 0.01400734,
        'l_SM' : 0.004554925
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.000421272,
        'upper limit (fb)' : 0.1677234,
        'expected upper limit (fb)' : 0.1377717,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 194.0), ('N2', 193.7), ('N1', 49.4)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.002511707,
        'r_expected' : 0.003057753,
        'Width (GeV)' : [
            ('N3', 0.0556471454),
            ('N2', 0.0654031172),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6184410000000004e-34,
        'l_max' : 1.7277570000000004e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.628526,
        'r_expected' : 1.787583,
        'likelihood' : 1.2933217675373901e-199,
        'l_max' : 2.675517734886183e-197,
        'l_SM' : 2.583838476626637e-197
    }
],
'Total xsec for missing topologies (fb)' : 1311.266,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1107.841,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 115.4574,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 46.73276,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.33715,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.897612,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1311.266,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1107.841,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 115.4574,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 46.73276,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.33715,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.897612,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 95.38945,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 95.38945,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,ATLAS-SUSY-2019-09,ATLAS-SUSY-2018-16',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm160.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.5291857,
        'upper limit (fb)' : 1.04,
        'expected upper limit (fb)' : 0.936,
        'TxNames' : ['T1bbbb', 'T6bbWWoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.5088324,
        'r_expected' : 0.5653693,
        'Width (GeV)' : None,
        'likelihood' : 0.002703297,
        'l_max' : 0.004463612,
        'l_SM' : 0.004373275
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0629989,
        'upper limit (fb)' : 0.1354423,
        'expected upper limit (fb)' : 0.129855,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 187.3),
            ('C1+/C1-', 181.6),
            ('N1', 159.9),
            ('N1/N1~', 159.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4651347,
        'r_expected' : 0.4851481,
        'Width (GeV)' : [
            ('N2', 9.3239e-06),
            ('C1+/C1-', 3.7705e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.9064510000000003e-38,
        'l_max' : 4.46243e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1139861,
        'upper limit (fb)' : 0.4674664,
        'expected upper limit (fb)' : 0.5590368,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2438379,
        'r_expected' : 0.2038972,
        'Width (GeV)' : None,
        'likelihood' : 0.08393914,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.008355658,
        'upper limit (fb)' : 0.4041214,
        'expected upper limit (fb)' : 0.4435194,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.02067611,
        'r_expected' : 0.01883944,
        'Width (GeV)' : None,
        'likelihood' : 1.0679970000000002e-32,
        'l_max' : 1.0786820000000003e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02047712,
        'upper limit (fb)' : 1.221645,
        'expected upper limit (fb)' : 1.014535,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 187.3),
            ('C1+/C1-', 181.6),
            ('N1', 159.9),
            ('N1/N1~', 159.9)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01676193,
        'r_expected' : 0.02018376,
        'Width (GeV)' : [
            ('N2', 9.3239e-06),
            ('C1+/C1-', 3.7705e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.331942179776936e-72,
        'l_max' : 4.781529367540317e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01047218,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [('C1+/C1-', 181.6), ('N1/N1~', 159.9)],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.004825888,
        'r_expected' : 0.004963117,
        'Width (GeV)' : [('C1+/C1-', 3.7705e-06), ('N1/N1~', 'stable')],
        'likelihood' : 0.000298982,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0003679427,
        'upper limit (fb)' : 0.4881632,
        'expected upper limit (fb)' : 0.4587634,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 187.3),
            ('C1+/C1-', 181.6),
            ('N1', 159.9),
            ('N1/N1~', 159.9)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0007537289,
        'r_expected' : 0.0008020315,
        'Width (GeV)' : [
            ('N2', 9.3239e-06),
            ('C1+/C1-', 3.7705e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.761641e-20,
        'l_max' : 2.852545e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0001084334,
        'upper limit (fb)' : 4.2419,
        'expected upper limit (fb)' : 5.5524,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('N3', 242.3),
            ('C1+/C1-/N2', 183.58),
            ('inv', 187.3),
            ('N1/N1~', 159.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR2jm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 2.556245e-05,
        'r_expected' : 1.95291e-05,
        'Width (GeV)' : [
            ('N3', 0.00064048),
            ('C1+/C1-/N2', 5.6958e-06),
            ('inv', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 8.692532e-05,
        'l_max' : 8.692799e-05,
        'l_SM' : 8.692799e-05
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.8164114,
        'r_expected' : 0.8451662,
        'likelihood' : 6.595099231340239e-42,
        'l_max' : 2.2245497241543573e-41,
        'l_SM' : 2.2245497241543573e-41
    }
],
'Total xsec for missing topologies (fb)' : 8465.135,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3592.611,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1244.615,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1206.973,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 493.441,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 418.1731,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 292.6174,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 165.7764,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 165.7764,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 149.3617,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 100.0626,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 8465.135,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3592.611,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1244.615,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1206.973,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 493.441,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 418.1731,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 292.6174,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 165.7764,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 165.7764,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 149.3617,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 100.0626,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7612.721,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7409.305,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 156.8458,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.10928,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.093492,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2666645,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05061851,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02454381,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02304145,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.002148664,
        'SMS' : 'PV > (jet,jet,MET), (b,t,MET)'
    }
]
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,ATLAS-SUSY-2019-09,ATLAS-SUSY-2018-16',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm160.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.5291857,
        'upper limit (fb)' : 1.04,
        'expected upper limit (fb)' : 0.936,
        'TxNames' : ['T1bbbb', 'T6bbWWoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.5088324,
        'r_expected' : 0.5653693,
        'Width (GeV)' : None,
        'likelihood' : 0.002703297,
        'l_max' : 0.004463612,
        'l_SM' : 0.004373275
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0629989,
        'upper limit (fb)' : 0.1354423,
        'expected upper limit (fb)' : 0.129855,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 187.3),
            ('C1+/C1-', 181.6),
            ('N1', 159.9),
            ('N1/N1~', 159.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4651347,
        'r_expected' : 0.4851481,
        'Width (GeV)' : [
            ('N2', 9.3239e-06),
            ('C1+/C1-', 3.7705e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.9064510000000003e-38,
        'l_max' : 4.46243e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1139861,
        'upper limit (fb)' : 0.4674664,
        'expected upper limit (fb)' : 0.5590368,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2438379,
        'r_expected' : 0.2038972,
        'Width (GeV)' : None,
        'likelihood' : 0.08393914,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.008355658,
        'upper limit (fb)' : 0.4041214,
        'expected upper limit (fb)' : 0.4435194,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.02067611,
        'r_expected' : 0.01883944,
        'Width (GeV)' : None,
        'likelihood' : 1.0679970000000002e-32,
        'l_max' : 1.0786820000000003e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02047712,
        'upper limit (fb)' : 1.221645,
        'expected upper limit (fb)' : 1.014535,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 187.3),
            ('C1+/C1-', 181.6),
            ('N1', 159.9),
            ('N1/N1~', 159.9)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01676193,
        'r_expected' : 0.02018376,
        'Width (GeV)' : [
            ('N2', 9.3239e-06),
            ('C1+/C1-', 3.7705e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.331942179776936e-72,
        'l_max' : 4.781529367540317e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01047218,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [('C1+/C1-', 181.6), ('N1/N1~', 159.9)],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.004825888,
        'r_expected' : 0.004963117,
        'Width (GeV)' : [('C1+/C1-', 3.7705e-06), ('N1/N1~', 'stable')],
        'likelihood' : 0.000298982,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0003679427,
        'upper limit (fb)' : 0.4881632,
        'expected upper limit (fb)' : 0.4587634,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 187.3),
            ('C1+/C1-', 181.6),
            ('N1', 159.9),
            ('N1/N1~', 159.9)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0007537289,
        'r_expected' : 0.0008020315,
        'Width (GeV)' : [
            ('N2', 9.3239e-06),
            ('C1+/C1-', 3.7705e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.761641e-20,
        'l_max' : 2.852545e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0001084334,
        'upper limit (fb)' : 4.2419,
        'expected upper limit (fb)' : 5.5524,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('N3', 242.3),
            ('C1+/C1-/N2', 183.58),
            ('inv', 187.3),
            ('N1/N1~', 159.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR2jm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 2.556245e-05,
        'r_expected' : 1.95291e-05,
        'Width (GeV)' : [
            ('N3', 0.00064048),
            ('C1+/C1-/N2', 5.6958e-06),
            ('inv', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 8.692532e-05,
        'l_max' : 8.692799e-05,
        'l_SM' : 8.692799e-05
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.8164114,
        'r_expected' : 0.8451662,
        'likelihood' : 6.595099231340239e-42,
        'l_max' : 2.2245497241543573e-41,
        'l_SM' : 2.2245497241543573e-41
    }
],
'Total xsec for missing topologies (fb)' : 8465.135,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3592.611,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1244.615,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1206.973,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 493.441,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 418.1731,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 292.6174,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 165.7764,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 165.7764,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 149.3617,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 100.0626,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 8465.135,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3592.611,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1244.615,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1206.973,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 493.441,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 418.1731,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 292.6174,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 165.7764,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 165.7764,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 149.3617,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 100.0626,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7612.721,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7409.305,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 156.8458,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.10928,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.093492,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2666645,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05061851,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02454381,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02304145,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.002148664,
        'SMS' : 'PV > (jet,jet,MET), (b,t,MET)'
    }
]
}
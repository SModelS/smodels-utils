smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,CMS-SUS-16-039-agg,ATLAS-SUSY-2013-04',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm475.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.055354,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.7817438,
        'r_expected' : 1.034661,
        'Width (GeV)' : None,
        'likelihood' : 0.001223012,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.64642,
        'upper limit (fb)' : 1.943454,
        'expected upper limit (fb)' : 1.186715,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 191.7),
            ('N3', 204.3),
            ('N1/N1~', 103.5),
            ('N1', 103.5)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.332614,
        'r_expected' : 0.5447139,
        'Width (GeV)' : [
            ('C1+/C1-', 0.015175),
            ('N3', 0.0068316),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 9.051810000000001e-20,
        'l_max' : 9.553471000000002e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1570099,
        'upper limit (fb)' : 0.974,
        'expected upper limit (fb)' : 0.765,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.0),
            ('su_L', 220.0),
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 103.5),
            ('N1', 103.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_0bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1612012,
        'r_expected' : 0.2052417,
        'Width (GeV)' : [
            ('su_L~', 0.195283001),
            ('su_L', 0.195283001),
            ('C1-', 0.0151751716),
            ('C1+', 0.0151751716),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.006093763,
        'l_max' : 0.006278059,
        'l_SM' : 0.004973309
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03750761,
        'upper limit (fb)' : 1.07,
        'expected upper limit (fb)' : 1.17,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 103.5),
            ('N1', 103.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.03505384,
        'r_expected' : 0.03205778,
        'Width (GeV)' : [
            ('C1-', 0.0151751716),
            ('C1+', 0.0151751716),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002240235,
        'l_max' : 0.002291271,
        'l_SM' : 0.002291271
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0001167292,
        'upper limit (fb)' : 0.024,
        'expected upper limit (fb)' : 0.0264,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 191.7),
            ('N2', 198.1),
            ('N1/N1~', 103.5),
            ('N1', 103.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : 'SRWZ_16',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.004863715,
        'r_expected' : 0.004421559,
        'Width (GeV)' : [
            ('C1+/C1-', 0.015175),
            ('N2', 0.0027525),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.522545,
        'l_max' : 0.5244628,
        'l_SM' : 0.5244628
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,CMS-SUS-13-012,CMS-SUS-16-039-agg',
        'r' : 0.8145883,
        'r_expected' : 1.333858,
        'likelihood' : 6.746084000000001e-25,
        'l_max' : 1.2657530000000002e-24,
        'l_SM' : 4.144436000000001e-25
    }
],
'Total xsec for missing topologies (fb)' : 1221.531,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1063.677,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 108.0296,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 47.08917,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.911087,
        'SMS' : 'PV > (Z,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6607673,
        'SMS' : 'PV > (Z,MET), (W,higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.133517,
        'SMS' : 'PV > (Z,MET), (W,b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02183222,
        'SMS' : 'PV > (Z,MET), (Z,b,t,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.008583673,
        'SMS' : 'PV > (Z,MET), (W,t,t,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1221.531,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1063.677,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 108.0296,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 47.08917,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.911087,
        'SMS' : 'PV > (Z,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6607673,
        'SMS' : 'PV > (Z,MET), (W,higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.133517,
        'SMS' : 'PV > (Z,MET), (W,b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02183222,
        'SMS' : 'PV > (Z,MET), (Z,b,t,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.008583673,
        'SMS' : 'PV > (Z,MET), (W,t,t,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.03238956,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.03238956,
        'SMS' : 'PV > (W,MET), (Z,MET)'
    }
]
}
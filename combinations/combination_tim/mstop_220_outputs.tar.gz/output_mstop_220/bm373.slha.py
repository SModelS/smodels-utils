smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039,CMS-SUS-21-002',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm373.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 21.56877,
        'upper limit (fb)' : 0.2794917,
        'expected upper limit (fb)' : 0.3239321,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 73.8),
            ('N1', 73.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 77.17141,
        'r_expected' : 66.58422,
        'Width (GeV)' : [
            ('C1-', 0.0987247173),
            ('C1+', 0.0987247173),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.279725,
        'upper limit (fb)' : 0.3003504,
        'expected upper limit (fb)' : 0.5015524,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 14.24911,
        'r_expected' : 8.532956,
        'Width (GeV)' : None,
        'likelihood' : 6.663934993756573e-132,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.74756,
        'upper limit (fb)' : 0.531,
        'expected upper limit (fb)' : 0.438,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 73.8),
            ('N1', 73.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWc-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 7.057552,
        'r_expected' : 8.556074,
        'Width (GeV)' : [
            ('C1-', 0.0987247173),
            ('C1+', 0.0987247173),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 5.3473490000000004e-24,
        'l_max' : 0.02164771,
        'l_SM' : 0.01893459
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.020623,
        'upper limit (fb)' : 1.29951,
        'expected upper limit (fb)' : 1.611466,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.785391,
        'r_expected' : 0.6333506,
        'Width (GeV)' : None,
        'likelihood' : 9.89074445411716e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8545032,
        'upper limit (fb)' : 1.227497,
        'expected upper limit (fb)' : 1.384211,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6961348,
        'r_expected' : 0.6173216,
        'Width (GeV)' : None,
        'likelihood' : 9.392688000000002e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1913237,
        'upper limit (fb)' : 0.4124958,
        'expected upper limit (fb)' : 0.359217,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4638199,
        'r_expected' : 0.5326132,
        'Width (GeV)' : None,
        'likelihood' : 1.058882e-24,
        'l_max' : 1.3143060000000002e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03452176,
        'upper limit (fb)' : 0.1,
        'expected upper limit (fb)' : 0.124,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2/N3', 218.65),
            ('N1/N1~', 73.8),
            ('N1', 73.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-0Jb',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.3452176,
        'r_expected' : 0.2784013,
        'Width (GeV)' : [
            ('C1+/C1-', 0.098725),
            ('N2/N3', 0.073338),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.06517202,
        'l_max' : 0.151876,
        'l_SM' : 0.151876
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2746573,
        'upper limit (fb)' : 1.04,
        'expected upper limit (fb)' : 0.936,
        'TxNames' : ['TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.2640935,
        'r_expected' : 0.2934372,
        'Width (GeV)' : None,
        'likelihood' : 0.004070036,
        'l_max' : 0.004463612,
        'l_SM' : 0.004373275
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.009077232,
        'upper limit (fb)' : 0.07289871,
        'expected upper limit (fb)' : 0.06122386,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1245184,
        'r_expected' : 0.148263,
        'Width (GeV)' : None,
        'likelihood' : 5.042229353773632e-45,
        'l_max' : 5.438918640578607e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01956918,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2/N3', 218.65),
            ('N1/N1~', 73.8),
            ('N1', 73.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.04659329,
        'r_expected' : 0.1029957,
        'Width (GeV)' : [
            ('C1+/C1-', 0.098725),
            ('N2/N3', 0.073355),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001802758,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0008964521,
        'upper limit (fb)' : 0.06845585,
        'expected upper limit (fb)' : 0.06445659,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.01309533,
        'r_expected' : 0.01390784,
        'Width (GeV)' : None,
        'likelihood' : 9.162181e-11,
        'l_max' : 9.296889e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0005426442,
        'upper limit (fb)' : 0.2313565,
        'expected upper limit (fb)' : 0.1757821,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 219.2), ('N2', 218.4), ('N1', 73.8)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.00234549,
        'r_expected' : 0.003087028,
        'Width (GeV)' : [
            ('N3', 0.0666326862),
            ('N2', 0.0763814427),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6229440000000003e-34,
        'l_max' : 2.0850610000000006e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039,CMS-SUS-21-002',
        'r' : 86.71677,
        'r_expected' : 72.23282,
        'likelihood' : 0.0,
        'l_max' : 4.1810920405651846e-265,
        'l_SM' : 4.1810920405651846e-265
    }
],
'Total xsec for missing topologies (fb)' : 77.91745,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 53.73618,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.2308,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.686809,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.263665,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 77.91745,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 53.73618,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.2308,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.686809,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.263665,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 69.98082,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 69.98082,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
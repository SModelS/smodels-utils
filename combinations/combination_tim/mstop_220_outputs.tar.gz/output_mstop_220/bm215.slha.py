smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm215.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.264283,
        'upper limit (fb)' : 9.5,
        'expected upper limit (fb)' : 7.42,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.2),
            ('su_L', 220.2),
            ('C1-', 214.9),
            ('C1+', 214.9),
            ('N1~', 206.0),
            ('N1', 206.0)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_500HT800_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.5541351,
        'r_expected' : 0.7094721,
        'Width (GeV)' : [
            ('su_L~', 0.0048147),
            ('su_L', 0.0048147),
            ('C1-', 5.6468e-08),
            ('C1+', 5.6468e-08),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 7.133124e-05,
        'l_max' : 0.0001131536,
        'l_SM' : 9.888565e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1338531,
        'upper limit (fb)' : 0.3369653,
        'expected upper limit (fb)' : 0.4029281,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3972311,
        'r_expected' : 0.332201,
        'Width (GeV)' : None,
        'likelihood' : 0.06299124,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01065875,
        'upper limit (fb)' : 0.03746635,
        'expected upper limit (fb)' : 0.05251912,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2844887,
        'r_expected' : 0.20295,
        'Width (GeV)' : None,
        'likelihood' : 2.574419e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002625124,
        'upper limit (fb)' : 0.3382423,
        'expected upper limit (fb)' : 0.3199349,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [('N3', 388.8), ('N1/N1~', 206.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.007761076,
        'r_expected' : 0.008205183,
        'Width (GeV)' : [('N3', 0.6518), ('N1/N1~', 'stable')],
        'likelihood' : 1.721904e-40,
        'l_max' : 1.75256e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00217149,
        'upper limit (fb)' : 0.721441,
        'expected upper limit (fb)' : 0.9626498,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.003009934,
        'r_expected' : 0.002255742,
        'Width (GeV)' : None,
        'likelihood' : 1.0537450421112788e-81,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0004894936,
        'upper limit (fb)' : 0.1868991,
        'expected upper limit (fb)' : 0.1371538,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [('N3', 388.8), ('N1', 206.0), ('N1/N1~', 206.0)],
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.002619026,
        'r_expected' : 0.00356894,
        'Width (GeV)' : [
            ('N3', 0.6518),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 5.4446420078708067e-45,
        'l_max' : 5.466006776770028e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001695077,
        'upper limit (fb)' : 0.68,
        'expected upper limit (fb)' : 0.511,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.9),
            ('C1+', 214.9),
            ('N1~', 206.0),
            ('N1', 206.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '5j_Meff_1700',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.00249276,
        'r_expected' : 0.003317176,
        'Width (GeV)' : [
            ('C1-', 5.6468e-08),
            ('C1+', 5.6468e-08),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003546351,
        'l_max' : 0.004539557,
        'l_SM' : 0.003527935
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0003082286,
        'upper limit (fb)' : 0.3815237,
        'expected upper limit (fb)' : 0.2094613,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 388.8), ('N1', 206.0)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.0008078885,
        'r_expected' : 0.00147153,
        'Width (GeV)' : [('N3', 0.65180245), ('N1', 'stable')],
        'likelihood' : 1.6225150000000002e-34,
        'l_max' : 5.648652000000001e-34,
        'l_SM' : 1.6144670000000003e-34
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0005581315,
        'upper limit (fb)' : 0.7227058,
        'expected upper limit (fb)' : 0.958844,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0007722804,
        'r_expected' : 0.000582088,
        'Width (GeV)' : None,
        'likelihood' : 4.240542442960513e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.000682171,
        'upper limit (fb)' : 0.8904959,
        'expected upper limit (fb)' : 1.372091,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0007660575,
        'r_expected' : 0.0004971761,
        'Width (GeV)' : None,
        'likelihood' : 2.7569790000000006e-20,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0001259006,
        'upper limit (fb)' : 0.1884772,
        'expected upper limit (fb)' : 0.1400837,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.0006679884,
        'r_expected' : 0.0008987527,
        'Width (GeV)' : None,
        'likelihood' : 9.126207e-11,
        'l_max' : 9.295279e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.633049e-05,
        'upper limit (fb)' : 0.13,
        'expected upper limit (fb)' : 0.162,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [('N3', 388.8), ('N1/N1~', 206.0), ('N1', 206.0)],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'SR2-int',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.0004333114,
        'r_expected' : 0.0003477191,
        'Width (GeV)' : [
            ('N3', 0.6518),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0326026,
        'l_max' : 0.03261751,
        'l_SM' : 0.03261751
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.68424e-05,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.12,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [('N3', 388.8), ('N1/N1~', 206.0), ('N1', 206.0)],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_Int',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.00040936,
        'r_expected' : 0.00030702,
        'Width (GeV)' : [
            ('N3', 0.6518),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1909896,
        'l_max' : 0.1911263,
        'l_SM' : 0.1911263
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.9300118,
        'r_expected' : 0.9328602,
        'likelihood' : 1.156749113374053e-43,
        'l_max' : 5.03000722489341e-43,
        'l_SM' : 5.03000722489341e-43
    }
],
'Total xsec for missing topologies (fb)' : 7400.962,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7254.219,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 116.2353,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.0907,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 13.0302,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.553893,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4791027,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3834537,
        'SMS' : 'PV > (W,MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.33033,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1892793,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1182281,
        'SMS' : 'PV > (higgs,MET), (Z,jet,jet,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 7400.962,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7254.219,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 116.2353,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.0907,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 13.0302,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.553893,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4791027,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3834537,
        'SMS' : 'PV > (W,MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.33033,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1892793,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1182281,
        'SMS' : 'PV > (higgs,MET), (Z,jet,jet,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7989.581,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7871.26,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 100.4981,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 12.18295,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.571705,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06774474,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm215.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.264283,
        'upper limit (fb)' : 9.5,
        'expected upper limit (fb)' : 7.42,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.2),
            ('su_L', 220.2),
            ('C1-', 214.9),
            ('C1+', 214.9),
            ('N1~', 206.0),
            ('N1', 206.0)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_500HT800_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.5541351,
        'r_expected' : 0.7094721,
        'Width (GeV)' : [
            ('su_L~', 0.0048147),
            ('su_L', 0.0048147),
            ('C1-', 5.6468e-08),
            ('C1+', 5.6468e-08),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 7.133124e-05,
        'l_max' : 0.0001131536,
        'l_SM' : 9.888565e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1338531,
        'upper limit (fb)' : 0.3369653,
        'expected upper limit (fb)' : 0.4029281,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3972311,
        'r_expected' : 0.332201,
        'Width (GeV)' : None,
        'likelihood' : 0.06299124,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01065875,
        'upper limit (fb)' : 0.03746635,
        'expected upper limit (fb)' : 0.05251912,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2844887,
        'r_expected' : 0.20295,
        'Width (GeV)' : None,
        'likelihood' : 2.574419e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002625124,
        'upper limit (fb)' : 0.3382423,
        'expected upper limit (fb)' : 0.3199349,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [('N3', 388.8), ('N1/N1~', 206.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.007761076,
        'r_expected' : 0.008205183,
        'Width (GeV)' : [('N3', 0.6518), ('N1/N1~', 'stable')],
        'likelihood' : 1.721904e-40,
        'l_max' : 1.75256e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00217149,
        'upper limit (fb)' : 0.721441,
        'expected upper limit (fb)' : 0.9626498,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.003009934,
        'r_expected' : 0.002255742,
        'Width (GeV)' : None,
        'likelihood' : 1.0537450421112788e-81,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0004894936,
        'upper limit (fb)' : 0.1868991,
        'expected upper limit (fb)' : 0.1371538,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [('N3', 388.8), ('N1', 206.0), ('N1/N1~', 206.0)],
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.002619026,
        'r_expected' : 0.00356894,
        'Width (GeV)' : [
            ('N3', 0.6518),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 5.4446420078708067e-45,
        'l_max' : 5.466006776770028e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001695077,
        'upper limit (fb)' : 0.68,
        'expected upper limit (fb)' : 0.511,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.9),
            ('C1+', 214.9),
            ('N1~', 206.0),
            ('N1', 206.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '5j_Meff_1700',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.00249276,
        'r_expected' : 0.003317176,
        'Width (GeV)' : [
            ('C1-', 5.6468e-08),
            ('C1+', 5.6468e-08),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003546351,
        'l_max' : 0.004539557,
        'l_SM' : 0.003527935
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0003082286,
        'upper limit (fb)' : 0.3815237,
        'expected upper limit (fb)' : 0.2094613,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 388.8), ('N1', 206.0)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.0008078885,
        'r_expected' : 0.00147153,
        'Width (GeV)' : [('N3', 0.65180245), ('N1', 'stable')],
        'likelihood' : 1.6225150000000002e-34,
        'l_max' : 5.648652000000001e-34,
        'l_SM' : 1.6144670000000003e-34
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0005581315,
        'upper limit (fb)' : 0.7227058,
        'expected upper limit (fb)' : 0.958844,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0007722804,
        'r_expected' : 0.000582088,
        'Width (GeV)' : None,
        'likelihood' : 4.240542442960513e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.000682171,
        'upper limit (fb)' : 0.8904959,
        'expected upper limit (fb)' : 1.372091,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0007660575,
        'r_expected' : 0.0004971761,
        'Width (GeV)' : None,
        'likelihood' : 2.7569790000000006e-20,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0001259006,
        'upper limit (fb)' : 0.1884772,
        'expected upper limit (fb)' : 0.1400837,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.0006679884,
        'r_expected' : 0.0008987527,
        'Width (GeV)' : None,
        'likelihood' : 9.126207e-11,
        'l_max' : 9.295279e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.633049e-05,
        'upper limit (fb)' : 0.13,
        'expected upper limit (fb)' : 0.162,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [('N3', 388.8), ('N1/N1~', 206.0), ('N1', 206.0)],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'SR2-int',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.0004333114,
        'r_expected' : 0.0003477191,
        'Width (GeV)' : [
            ('N3', 0.6518),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0326026,
        'l_max' : 0.03261751,
        'l_SM' : 0.03261751
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.68424e-05,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.12,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [('N3', 388.8), ('N1/N1~', 206.0), ('N1', 206.0)],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_Int',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.00040936,
        'r_expected' : 0.00030702,
        'Width (GeV)' : [
            ('N3', 0.6518),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1909896,
        'l_max' : 0.1911263,
        'l_SM' : 0.1911263
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.9300118,
        'r_expected' : 0.9328602,
        'likelihood' : 1.156749113374053e-43,
        'l_max' : 5.03000722489341e-43,
        'l_SM' : 5.03000722489341e-43
    }
],
'Total xsec for missing topologies (fb)' : 7400.962,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7254.219,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 116.2353,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.0907,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 13.0302,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.553893,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4791027,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3834537,
        'SMS' : 'PV > (W,MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.33033,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1892793,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1182281,
        'SMS' : 'PV > (higgs,MET), (Z,jet,jet,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 7400.962,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7254.219,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 116.2353,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.0907,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 13.0302,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.553893,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4791027,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3834537,
        'SMS' : 'PV > (W,MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.33033,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1892793,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1182281,
        'SMS' : 'PV > (higgs,MET), (Z,jet,jet,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7989.581,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7871.26,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 100.4981,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 12.18295,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.571705,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06774474,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm225.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 19.08292,
        'upper limit (fb)' : 0.2860229,
        'expected upper limit (fb)' : 0.3302513,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 83.1),
            ('N1', 83.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 66.71814,
        'r_expected' : 57.78302,
        'Width (GeV)' : [
            ('C1-', 0.0878206203),
            ('C1+', 0.0878206203),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.294709,
        'upper limit (fb)' : 0.4088471,
        'expected upper limit (fb)' : 0.6196033,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 8.058535,
        'r_expected' : 5.317449,
        'Width (GeV)' : None,
        'likelihood' : 3.766065649253359e-107,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.267852,
        'upper limit (fb)' : 0.531,
        'expected upper limit (fb)' : 0.438,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 83.1),
            ('N1', 83.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWc-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 6.154146,
        'r_expected' : 7.460848,
        'Width (GeV)' : [
            ('C1-', 0.0878206203),
            ('C1+', 0.0878206203),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.2127640000000003e-20,
        'l_max' : 0.02164771,
        'l_SM' : 0.01893459
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.937773,
        'upper limit (fb)' : 1.411713,
        'expected upper limit (fb)' : 1.65899,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6642801,
        'r_expected' : 0.5652674,
        'Width (GeV)' : None,
        'likelihood' : 1.461257751915061e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9135202,
        'upper limit (fb)' : 1.61662,
        'expected upper limit (fb)' : 1.450223,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.5650802,
        'r_expected' : 0.6299169,
        'Width (GeV)' : None,
        'likelihood' : 1.9681470000000003e-20,
        'l_max' : 2.9627500000000004e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1532681,
        'upper limit (fb)' : 0.3455611,
        'expected upper limit (fb)' : 0.2987701,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.443534,
        'r_expected' : 0.5129968,
        'Width (GeV)' : None,
        'likelihood' : 1.1090050000000002e-24,
        'l_max' : 1.3264140000000002e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2488906,
        'upper limit (fb)' : 1.04,
        'expected upper limit (fb)' : 0.936,
        'TxNames' : ['TChiWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.2393178,
        'r_expected' : 0.2659087,
        'Width (GeV)' : None,
        'likelihood' : 0.004166698,
        'l_max' : 0.004463612,
        'l_SM' : 0.004373275
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04133415,
        'upper limit (fb)' : 0.35,
        'expected upper limit (fb)' : 0.383,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2/N3', 218.81),
            ('N1/N1~', 83.1),
            ('N1', 83.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-0Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.1180976,
        'r_expected' : 0.1079221,
        'Width (GeV)' : [
            ('C1+/C1-', 0.087821),
            ('N2/N3', 0.062302),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01102393,
        'l_max' : 0.01183074,
        'l_SM' : 0.01183074
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.006218279,
        'upper limit (fb)' : 0.06096982,
        'expected upper limit (fb)' : 0.06445298,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1019895,
        'r_expected' : 0.09647775,
        'Width (GeV)' : None,
        'likelihood' : 8.836304e-11,
        'l_max' : 9.107398e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02113718,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2/N3', 218.81),
            ('N1/N1~', 83.1),
            ('N1', 83.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.05032661,
        'r_expected' : 0.1112483,
        'Width (GeV)' : [
            ('C1+/C1-', 0.087821),
            ('N2/N3', 0.062319),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.00191798,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0004680661,
        'upper limit (fb)' : 0.0385,
        'expected upper limit (fb)' : 0.0252,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N3', 219.9),
            ('C1+/C1-', 211.8),
            ('N1', 83.1),
            ('N1/N1~', 83.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : 'SR_MM_High_MCT',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.01215756,
        'r_expected' : 0.01857405,
        'Width (GeV)' : [
            ('N3', 0.054504),
            ('C1+/C1-', 0.087821),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.1679044,
        'l_max' : 0.1799699,
        'l_SM' : 0.1646724
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.19111e-05,
        'upper limit (fb)' : 0.03393747,
        'expected upper limit (fb)' : 0.04624693,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 219.9), ('N2', 218.3), ('N1', 83.1)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.0006456315,
        'r_expected' : 0.0004737849,
        'Width (GeV)' : [
            ('N3', 0.054503714),
            ('N2', 0.0659358289),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6126340000000003e-34,
        'l_max' : 1.6144670000000003e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
        'r' : 72.59862,
        'r_expected' : 62.34902,
        'likelihood' : 0.0,
        'l_max' : 4.999180431726613e-169,
        'l_SM' : 4.999180431726613e-169
    }
],
'Total xsec for missing topologies (fb)' : 77.56516,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 58.84254,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.49807,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.224554,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 77.56516,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 58.84254,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.49807,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.224554,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 66.87954,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 66.87954,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm225.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 19.08292,
        'upper limit (fb)' : 0.2860229,
        'expected upper limit (fb)' : 0.3302513,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 83.1),
            ('N1', 83.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 66.71814,
        'r_expected' : 57.78302,
        'Width (GeV)' : [
            ('C1-', 0.0878206203),
            ('C1+', 0.0878206203),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.294709,
        'upper limit (fb)' : 0.4088471,
        'expected upper limit (fb)' : 0.6196033,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 8.058535,
        'r_expected' : 5.317449,
        'Width (GeV)' : None,
        'likelihood' : 3.766065649253894e-107,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.267852,
        'upper limit (fb)' : 0.531,
        'expected upper limit (fb)' : 0.438,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 211.8),
            ('C1+', 211.8),
            ('N1~', 83.1),
            ('N1', 83.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWc-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 6.154146,
        'r_expected' : 7.460848,
        'Width (GeV)' : [
            ('C1-', 0.0878206203),
            ('C1+', 0.0878206203),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.2127640000000003e-20,
        'l_max' : 0.02164771,
        'l_SM' : 0.01893459
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.937773,
        'upper limit (fb)' : 1.411713,
        'expected upper limit (fb)' : 1.65899,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6642801,
        'r_expected' : 0.5652674,
        'Width (GeV)' : None,
        'likelihood' : 1.461257751915061e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9135202,
        'upper limit (fb)' : 1.61662,
        'expected upper limit (fb)' : 1.450223,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.5650802,
        'r_expected' : 0.6299169,
        'Width (GeV)' : None,
        'likelihood' : 1.9681470000000003e-20,
        'l_max' : 2.9627500000000004e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1532681,
        'upper limit (fb)' : 0.3455611,
        'expected upper limit (fb)' : 0.2987701,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.443534,
        'r_expected' : 0.5129968,
        'Width (GeV)' : None,
        'likelihood' : 1.1090050000000002e-24,
        'l_max' : 1.3264140000000002e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2488906,
        'upper limit (fb)' : 1.04,
        'expected upper limit (fb)' : 0.936,
        'TxNames' : ['TChiWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.2393178,
        'r_expected' : 0.2659087,
        'Width (GeV)' : None,
        'likelihood' : 0.004166698,
        'l_max' : 0.004463612,
        'l_SM' : 0.004373275
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04133415,
        'upper limit (fb)' : 0.35,
        'expected upper limit (fb)' : 0.383,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2/N3', 218.81),
            ('N1/N1~', 83.1),
            ('N1', 83.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-0Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.1180976,
        'r_expected' : 0.1079221,
        'Width (GeV)' : [
            ('C1+/C1-', 0.087821),
            ('N2/N3', 0.062302),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01102393,
        'l_max' : 0.01183074,
        'l_SM' : 0.01183074
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.006218279,
        'upper limit (fb)' : 0.06096982,
        'expected upper limit (fb)' : 0.06445298,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1019895,
        'r_expected' : 0.09647775,
        'Width (GeV)' : None,
        'likelihood' : 8.836304e-11,
        'l_max' : 9.107398e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02113718,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 211.8),
            ('N2/N3', 218.81),
            ('N1/N1~', 83.1),
            ('N1', 83.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.05032661,
        'r_expected' : 0.1112483,
        'Width (GeV)' : [
            ('C1+/C1-', 0.087821),
            ('N2/N3', 0.062319),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.00191798,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0004680661,
        'upper limit (fb)' : 0.0385,
        'expected upper limit (fb)' : 0.0252,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N3', 219.9),
            ('C1+/C1-', 211.8),
            ('N1', 83.1),
            ('N1/N1~', 83.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : 'SR_MM_High_MCT',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.01215756,
        'r_expected' : 0.01857405,
        'Width (GeV)' : [
            ('N3', 0.054504),
            ('C1+/C1-', 0.087821),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.1679044,
        'l_max' : 0.1799699,
        'l_SM' : 0.1646724
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.19111e-05,
        'upper limit (fb)' : 0.03393747,
        'expected upper limit (fb)' : 0.04624693,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 219.9), ('N2', 218.3), ('N1', 83.1)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.0006456315,
        'r_expected' : 0.0004737849,
        'Width (GeV)' : [
            ('N3', 0.054503714),
            ('N2', 0.0659358289),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6126340000000003e-34,
        'l_max' : 1.6144670000000003e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg,CMS-SUS-21-002',
        'r' : 72.59862,
        'r_expected' : 62.34902,
        'likelihood' : 0.0,
        'l_max' : 4.999180431726613e-169,
        'l_SM' : 4.999180431726613e-169
    }
],
'Total xsec for missing topologies (fb)' : 77.56516,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 58.84254,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.49807,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.224554,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 77.56516,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 58.84254,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.49807,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.224554,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 66.87954,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 66.87954,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
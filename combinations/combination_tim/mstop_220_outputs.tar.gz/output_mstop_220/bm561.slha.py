smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm561.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.517503,
        'upper limit (fb)' : 1.222801,
        'expected upper limit (fb)' : 1.802139,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 1.241006,
        'r_expected' : 0.8420566,
        'Width (GeV)' : None,
        'likelihood' : 1.9257986134489985e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.082527,
        'upper limit (fb)' : 1.145995,
        'expected upper limit (fb)' : 1.401661,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.944617,
        'r_expected' : 0.7723169,
        'Width (GeV)' : None,
        'likelihood' : 3.946642000000001e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.16119,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.8601408,
        'r_expected' : 1.138422,
        'Width (GeV)' : None,
        'likelihood' : 0.0008620769,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2071187,
        'upper limit (fb)' : 0.4174671,
        'expected upper limit (fb)' : 0.3149517,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4961319,
        'r_expected' : 0.6576207,
        'Width (GeV)' : None,
        'likelihood' : 1.4862160000000002e-24,
        'l_max' : 1.6795050000000004e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1428141,
        'upper limit (fb)' : 0.3023775,
        'expected upper limit (fb)' : 0.3205968,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 49.6),
            ('N1', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.472304,
        'r_expected' : 0.4454632,
        'Width (GeV)' : [
            ('C1-', 0.0953362574),
            ('C1+', 0.0953362574),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 9.84697550917089e-41,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3779997,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.2,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.4),
            ('su_L', 220.4),
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 49.6),
            ('N1', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_1bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.2799998,
        'r_expected' : 0.3149998,
        'Width (GeV)' : [
            ('su_L~', 0.200332595),
            ('su_L', 0.200332595),
            ('C1-', 0.0953362574),
            ('C1+', 0.0953362574),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002285754,
        'l_max' : 0.002394811,
        'l_SM' : 0.002264688
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01029879,
        'upper limit (fb)' : 0.0601035,
        'expected upper limit (fb)' : 0.06311333,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.171351,
        'r_expected' : 0.1631794,
        'Width (GeV)' : None,
        'likelihood' : 8.45697e-11,
        'l_max' : 9.107398e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.09210808,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 49.6),
            ('N1', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.160467,
        'r_expected' : 0.1425822,
        'Width (GeV)' : [
            ('C1-', 0.0953362574),
            ('C1+', 0.0953362574),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.007364089,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01398467,
        'upper limit (fb)' : 0.1347238,
        'expected upper limit (fb)' : 0.1120835,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N2/N3', 198.79),
            ('C1+/C1-', 191.7),
            ('N1', 49.6),
            ('N1/N1~', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1038025,
        'r_expected' : 0.1247701,
        'Width (GeV)' : [
            ('N2/N3', 0.062373),
            ('C1+/C1-', 0.095336),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 5.4537127207479633e-45,
        'l_max' : 5.472437388146633e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02187522,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 191.7),
            ('N2/N3', 198.73),
            ('N1/N1~', 49.6),
            ('N1', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.05208387,
        'r_expected' : 0.1151328,
        'Width (GeV)' : [
            ('C1+/C1-', 0.095336),
            ('N2/N3', 0.068454),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001974151,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01297174,
        'upper limit (fb)' : 0.43,
        'expected upper limit (fb)' : 0.329,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 191.7),
            ('N2/N3', 198.73),
            ('N1/N1~', 49.6),
            ('N1', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'SR2-low',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.03016683,
        'r_expected' : 0.03942778,
        'Width (GeV)' : [
            ('C1+/C1-', 0.095336),
            ('N2/N3', 0.068452),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.005319191,
        'l_max' : 0.01400734,
        'l_SM' : 0.004554925
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.007634008,
        'upper limit (fb)' : 0.256,
        'expected upper limit (fb)' : 0.33,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N2/N3', 198.79),
            ('C1+/C1-', 191.7),
            ('N1', 49.6),
            ('N1/N1~', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-12',
        'DataSetID' : 'SR2tau_b',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.02982034,
        'r_expected' : 0.02313336,
        'Width (GeV)' : [
            ('N2/N3', 0.062445),
            ('C1+/C1-', 0.095336),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.05898736,
        'l_max' : 0.06174326,
        'l_SM' : 0.06174326
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0005625479,
        'upper limit (fb)' : 0.1853772,
        'expected upper limit (fb)' : 0.1493013,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 198.8), ('N2', 198.7), ('N1', 49.6)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.003034613,
        'r_expected' : 0.00376787,
        'Width (GeV)' : [
            ('N3', 0.061396783),
            ('N2', 0.0714423849),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6197390000000004e-34,
        'l_max' : 1.7445000000000003e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.555904,
        'r_expected' : 1.726397,
        'likelihood' : 1.886242048134984e-199,
        'l_max' : 2.7117157618590754e-197,
        'l_SM' : 2.583838476626637e-197
    }
],
'Total xsec for missing topologies (fb)' : 1244.589,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1071.5,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 96.16029,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.46412,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 32.56675,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.897343,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1244.589,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1071.5,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 96.16029,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.46412,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 32.56675,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.897343,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 75.7509,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 75.7509,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm561.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.517503,
        'upper limit (fb)' : 1.222801,
        'expected upper limit (fb)' : 1.802139,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 1.241006,
        'r_expected' : 0.8420566,
        'Width (GeV)' : None,
        'likelihood' : 1.9257986134489985e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.082527,
        'upper limit (fb)' : 1.145995,
        'expected upper limit (fb)' : 1.401661,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.944617,
        'r_expected' : 0.7723169,
        'Width (GeV)' : None,
        'likelihood' : 3.946642000000001e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.16119,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.8601408,
        'r_expected' : 1.138422,
        'Width (GeV)' : None,
        'likelihood' : 0.0008620769,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2071187,
        'upper limit (fb)' : 0.4174671,
        'expected upper limit (fb)' : 0.3149517,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4961319,
        'r_expected' : 0.6576207,
        'Width (GeV)' : None,
        'likelihood' : 1.4862160000000002e-24,
        'l_max' : 1.6795050000000004e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1428141,
        'upper limit (fb)' : 0.3023775,
        'expected upper limit (fb)' : 0.3205968,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 49.6),
            ('N1', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.472304,
        'r_expected' : 0.4454632,
        'Width (GeV)' : [
            ('C1-', 0.0953362574),
            ('C1+', 0.0953362574),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 9.84697550917089e-41,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3779997,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.2,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.4),
            ('su_L', 220.4),
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 49.6),
            ('N1', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_1bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.2799998,
        'r_expected' : 0.3149998,
        'Width (GeV)' : [
            ('su_L~', 0.200332595),
            ('su_L', 0.200332595),
            ('C1-', 0.0953362574),
            ('C1+', 0.0953362574),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002285754,
        'l_max' : 0.002394811,
        'l_SM' : 0.002264688
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01029879,
        'upper limit (fb)' : 0.0601035,
        'expected upper limit (fb)' : 0.06311333,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.171351,
        'r_expected' : 0.1631794,
        'Width (GeV)' : None,
        'likelihood' : 8.45697e-11,
        'l_max' : 9.107398e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.09210808,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 49.6),
            ('N1', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.160467,
        'r_expected' : 0.1425822,
        'Width (GeV)' : [
            ('C1-', 0.0953362574),
            ('C1+', 0.0953362574),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.007364089,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01398467,
        'upper limit (fb)' : 0.1347238,
        'expected upper limit (fb)' : 0.1120835,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N2/N3', 198.79),
            ('C1+/C1-', 191.7),
            ('N1', 49.6),
            ('N1/N1~', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1038025,
        'r_expected' : 0.1247701,
        'Width (GeV)' : [
            ('N2/N3', 0.062373),
            ('C1+/C1-', 0.095336),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 5.4537127207479633e-45,
        'l_max' : 5.472437388146633e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02187522,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 191.7),
            ('N2/N3', 198.73),
            ('N1/N1~', 49.6),
            ('N1', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.05208387,
        'r_expected' : 0.1151328,
        'Width (GeV)' : [
            ('C1+/C1-', 0.095336),
            ('N2/N3', 0.068454),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001974151,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01297174,
        'upper limit (fb)' : 0.43,
        'expected upper limit (fb)' : 0.329,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 191.7),
            ('N2/N3', 198.73),
            ('N1/N1~', 49.6),
            ('N1', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'SR2-low',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.03016683,
        'r_expected' : 0.03942778,
        'Width (GeV)' : [
            ('C1+/C1-', 0.095336),
            ('N2/N3', 0.068452),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.005319191,
        'l_max' : 0.01400734,
        'l_SM' : 0.004554925
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.007634008,
        'upper limit (fb)' : 0.256,
        'expected upper limit (fb)' : 0.33,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N2/N3', 198.79),
            ('C1+/C1-', 191.7),
            ('N1', 49.6),
            ('N1/N1~', 49.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-12',
        'DataSetID' : 'SR2tau_b',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.02982034,
        'r_expected' : 0.02313336,
        'Width (GeV)' : [
            ('N2/N3', 0.062445),
            ('C1+/C1-', 0.095336),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.05898736,
        'l_max' : 0.06174326,
        'l_SM' : 0.06174326
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0005625479,
        'upper limit (fb)' : 0.1853772,
        'expected upper limit (fb)' : 0.1493013,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 198.8), ('N2', 198.7), ('N1', 49.6)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.003034613,
        'r_expected' : 0.00376787,
        'Width (GeV)' : [
            ('N3', 0.061396783),
            ('N2', 0.0714423849),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6197390000000004e-34,
        'l_max' : 1.7445000000000003e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.555904,
        'r_expected' : 1.726397,
        'likelihood' : 1.886242048134984e-199,
        'l_max' : 2.7117157618590754e-197,
        'l_SM' : 2.583838476626637e-197
    }
],
'Total xsec for missing topologies (fb)' : 1244.589,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1071.5,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 96.16029,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.46412,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 32.56675,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.897343,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1244.589,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1071.5,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 96.16029,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38.46412,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 32.56675,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.897343,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 75.7509,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 75.7509,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm789.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 17.47213,
        'upper limit (fb)' : 3.17,
        'expected upper limit (fb)' : 5.0,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR11_Njet7_Nb1_HT300_MHT300',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 5.511712,
        'r_expected' : 3.494425,
        'Width (GeV)' : [
            ('su_L~', 0.267581641),
            ('su_L', 0.267581641),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.231665e-19,
        'l_max' : 4.347692e-05,
        'l_SM' : 4.347692e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.737411,
        'upper limit (fb)' : 1.347,
        'expected upper limit (fb)' : 1.303,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-05',
        'DataSetID' : 'SRB',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.1,
        'dataType' : 'efficiencyMap',
        'r' : 1.289838,
        'r_expected' : 1.333393,
        'Width (GeV)' : [
            ('su_L~', 0.267581641),
            ('su_L', 0.267581641),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 7.318569e-05,
        'l_max' : 0.001971545,
        'l_SM' : 0.00196557
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1808216,
        'upper limit (fb)' : 0.3274239,
        'expected upper limit (fb)' : 0.3915406,
        'TxNames' : ['TChiWWoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.5522552,
        'r_expected' : 0.4618208,
        'Width (GeV)' : None,
        'likelihood' : 0.04449222,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4513034,
        'upper limit (fb)' : 0.999,
        'expected upper limit (fb)' : 0.72,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1250HT1500_450MHTinf',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.4517552,
        'r_expected' : 0.6268103,
        'Width (GeV)' : [
            ('su_L~', 0.267581641),
            ('su_L', 0.267581641),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.007007785,
        'l_max' : 0.008064899,
        'l_SM' : 0.005484322
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.82287,
        'upper limit (fb)' : 27.19,
        'expected upper limit (fb)' : 27.57,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-21',
        'DataSetID' : 'M2',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.4348242,
        'r_expected' : 0.428831,
        'Width (GeV)' : [
            ('su_L~', 0.267581641),
            ('su_L', 0.267581641),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 4.277606e-06,
        'l_max' : 6.346427e-06,
        'l_SM' : 6.346427e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.008151863,
        'upper limit (fb)' : 0.03718031,
        'expected upper limit (fb)' : 0.05246921,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 191.6),
            ('C1+/C1-', 186.7),
            ('N1', 179.7),
            ('N1/N1~', 179.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2192521,
        'r_expected' : 0.1553647,
        'Width (GeV)' : [
            ('N2', 1.886e-07),
            ('C1+/C1-', 1.6449e-08),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.945163e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.267466,
        'upper limit (fb)' : 66.1,
        'expected upper limit (fb)' : 48.8,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'ATLAS-CONF-2013-047',
        'DataSetID' : 'A Loose',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.09481794,
        'r_expected' : 0.1284317,
        'Width (GeV)' : [
            ('su_L~', 0.267581641),
            ('su_L', 0.267581641),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.641216e-06,
        'l_max' : 4.358706e-06,
        'l_SM' : 1.988754e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0031822,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 186.7),
            ('C1+', 186.7),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.001466452,
        'r_expected' : 0.001508152,
        'Width (GeV)' : [
            ('C1-', 1.6449e-08),
            ('C1+', 1.6449e-08),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002988758,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033',
        'r' : 5.398886,
        'r_expected' : 4.17729,
        'likelihood' : 3.5407358229908083e-70,
        'l_max' : 1.5129859436283734e-53,
        'l_SM' : 1.5129859436283734e-53
    }
],
'Total xsec for missing topologies (fb)' : 2029.889,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1129.956,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 661.0008,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 195.5091,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.47413,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.73448,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.988819,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.903777,
        'SMS' : 'PV > (MET), (b,t,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9698314,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6982725,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4363246,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 2029.889,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1129.956,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 661.0008,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 195.5091,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.47413,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.73448,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.988819,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.903777,
        'SMS' : 'PV > (MET), (b,t,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9698314,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6982725,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4363246,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 177.9068,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 157.2904,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11.85414,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.762324,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    }
]
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm789.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 17.47213,
        'upper limit (fb)' : 3.17,
        'expected upper limit (fb)' : 5.0,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR11_Njet7_Nb1_HT300_MHT300',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 5.511712,
        'r_expected' : 3.494425,
        'Width (GeV)' : [
            ('su_L~', 0.267581641),
            ('su_L', 0.267581641),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.231665e-19,
        'l_max' : 4.347692e-05,
        'l_SM' : 4.347692e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.737411,
        'upper limit (fb)' : 1.347,
        'expected upper limit (fb)' : 1.303,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-05',
        'DataSetID' : 'SRB',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.1,
        'dataType' : 'efficiencyMap',
        'r' : 1.289838,
        'r_expected' : 1.333393,
        'Width (GeV)' : [
            ('su_L~', 0.267581641),
            ('su_L', 0.267581641),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 7.318569e-05,
        'l_max' : 0.001971545,
        'l_SM' : 0.00196557
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1808216,
        'upper limit (fb)' : 0.3274239,
        'expected upper limit (fb)' : 0.3915406,
        'TxNames' : ['TChiWWoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.5522552,
        'r_expected' : 0.4618208,
        'Width (GeV)' : None,
        'likelihood' : 0.04449222,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4513034,
        'upper limit (fb)' : 0.999,
        'expected upper limit (fb)' : 0.72,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1250HT1500_450MHTinf',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.4517552,
        'r_expected' : 0.6268103,
        'Width (GeV)' : [
            ('su_L~', 0.267581641),
            ('su_L', 0.267581641),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.007007785,
        'l_max' : 0.008064899,
        'l_SM' : 0.005484322
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.82287,
        'upper limit (fb)' : 27.19,
        'expected upper limit (fb)' : 27.57,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-21',
        'DataSetID' : 'M2',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.4348242,
        'r_expected' : 0.428831,
        'Width (GeV)' : [
            ('su_L~', 0.267581641),
            ('su_L', 0.267581641),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 4.277606e-06,
        'l_max' : 6.346427e-06,
        'l_SM' : 6.346427e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.008151863,
        'upper limit (fb)' : 0.03718031,
        'expected upper limit (fb)' : 0.05246921,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 191.6),
            ('C1+/C1-', 186.7),
            ('N1', 179.7),
            ('N1/N1~', 179.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2192521,
        'r_expected' : 0.1553647,
        'Width (GeV)' : [
            ('N2', 1.886e-07),
            ('C1+/C1-', 1.6449e-08),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.945163e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.267466,
        'upper limit (fb)' : 66.1,
        'expected upper limit (fb)' : 48.8,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'ATLAS-CONF-2013-047',
        'DataSetID' : 'A Loose',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.09481794,
        'r_expected' : 0.1284317,
        'Width (GeV)' : [
            ('su_L~', 0.267581641),
            ('su_L', 0.267581641),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.641216e-06,
        'l_max' : 4.358706e-06,
        'l_SM' : 1.988754e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0031822,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 186.7),
            ('C1+', 186.7),
            ('N1~', 179.7),
            ('N1', 179.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.001466452,
        'r_expected' : 0.001508152,
        'Width (GeV)' : [
            ('C1-', 1.6449e-08),
            ('C1+', 1.6449e-08),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002988758,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033',
        'r' : 5.398886,
        'r_expected' : 4.17729,
        'likelihood' : 3.5407358229908083e-70,
        'l_max' : 1.5129859436283734e-53,
        'l_SM' : 1.5129859436283734e-53
    }
],
'Total xsec for missing topologies (fb)' : 2029.889,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1129.956,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 661.0008,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 195.5091,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.47413,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.73448,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.988819,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.903777,
        'SMS' : 'PV > (MET), (b,t,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9698314,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6982725,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4363246,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 2029.889,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1129.956,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 661.0008,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 195.5091,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.47413,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.73448,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.988819,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.903777,
        'SMS' : 'PV > (MET), (b,t,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9698314,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6982725,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4363246,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 177.9068,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 157.2904,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11.85414,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.762324,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    }
]
}
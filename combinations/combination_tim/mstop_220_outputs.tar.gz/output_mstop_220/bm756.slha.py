smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm756.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 12.78239,
        'upper limit (fb)' : 3.17,
        'expected upper limit (fb)' : 5.0,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.2),
            ('su_L', 220.2),
            ('N1~', 157.2),
            ('N1', 157.2)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR11_Njet7_Nb1_HT300_MHT300',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 4.0323,
        'r_expected' : 2.556478,
        'Width (GeV)' : [
            ('su_L~', 0.622221421),
            ('su_L', 0.622221421),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.819369e-13,
        'l_max' : 4.347692e-05,
        'l_SM' : 4.347692e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.159515,
        'upper limit (fb)' : 1.347,
        'expected upper limit (fb)' : 1.303,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.2),
            ('su_L', 220.2),
            ('N1~', 157.2),
            ('N1', 157.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-05',
        'DataSetID' : 'SRB',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.1,
        'dataType' : 'efficiencyMap',
        'r' : 1.603203,
        'r_expected' : 1.657341,
        'Width (GeV)' : [
            ('su_L~', 0.622221421),
            ('su_L', 0.622221421),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.238944e-05,
        'l_max' : 0.001971545,
        'l_SM' : 0.00196557
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2389878,
        'upper limit (fb)' : 0.3476888,
        'expected upper limit (fb)' : 0.4156953,
        'TxNames' : ['TChiWWoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.6873612,
        'r_expected' : 0.574911,
        'Width (GeV)' : None,
        'likelihood' : 0.03163267,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 34.7458,
        'upper limit (fb)' : 82.18,
        'expected upper limit (fb)' : 94.92,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.2),
            ('su_L', 220.2),
            ('N1~', 157.2),
            ('N1', 157.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-21',
        'DataSetID' : 'M1',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.4228011,
        'r_expected' : 0.3660535,
        'Width (GeV)' : [
            ('su_L~', 0.622221421),
            ('su_L', 0.622221421),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 4.831074e-07,
        'l_max' : 8.399753e-07,
        'l_SM' : 8.399753e-07
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9104646,
        'upper limit (fb)' : 2.88,
        'expected upper limit (fb)' : 2.01,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.2),
            ('su_L', 220.2),
            ('N1~', 157.2),
            ('N1', 157.2)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.3161335,
        'r_expected' : 0.4529675,
        'Width (GeV)' : [
            ('su_L~', 0.622221421),
            ('su_L', 0.622221421),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0009480126,
        'l_max' : 0.0009521956,
        'l_SM' : 0.0006572509
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01077848,
        'upper limit (fb)' : 0.04147952,
        'expected upper limit (fb)' : 0.0562766,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 171.7),
            ('C1+/C1-', 166.5),
            ('N1', 157.2),
            ('N1/N1~', 157.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2598507,
        'r_expected' : 0.1915269,
        'Width (GeV)' : [
            ('N2', 5.0219e-07),
            ('C1+/C1-', 7.1746e-08),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.8202770000000005e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.347786,
        'upper limit (fb)' : 66.1,
        'expected upper limit (fb)' : 48.8,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.2),
            ('su_L', 220.2),
            ('N1~', 157.2),
            ('N1', 157.2)
        ],
        'AnalysisID' : 'ATLAS-CONF-2013-047',
        'DataSetID' : 'A Loose',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1262903,
        'r_expected' : 0.1710612,
        'Width (GeV)' : [
            ('su_L~', 0.622221421),
            ('su_L', 0.622221421),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.86166e-06,
        'l_max' : 4.358706e-06,
        'l_SM' : 1.988754e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.006007568,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 166.5),
            ('C1+', 166.5),
            ('N1~', 157.2),
            ('N1', 157.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.002768464,
        'r_expected' : 0.002847188,
        'Width (GeV)' : [
            ('C1-', 7.1746e-08),
            ('C1+', 7.1746e-08),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002989188,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0003501558,
        'upper limit (fb)' : 1.129319,
        'expected upper limit (fb)' : 1.157383,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 171.7),
            ('C1+/C1-', 166.5),
            ('N1', 157.2),
            ('N1/N1~', 157.2)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0003100592,
        'r_expected' : 0.0003025409,
        'Width (GeV)' : [
            ('N2', 5.0219e-07),
            ('C1+/C1-', 7.1746e-08),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.2437163163413286e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033',
        'r' : 4.45916,
        'r_expected' : 3.430048,
        'likelihood' : 9.209967018312497e-67,
        'l_max' : 2.399829330617739e-55,
        'l_SM' : 2.399829330617739e-55
    }
],
'Total xsec for missing topologies (fb)' : 2754.025,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1291.357,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1096.281,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 287.1852,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 37.77159,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30.10218,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.512282,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.497819,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.096384,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9843034,
        'SMS' : 'PV > (W,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.7025003,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 2754.025,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1291.357,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1096.281,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 287.1852,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 37.77159,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30.10218,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.512282,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.497819,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.096384,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9843034,
        'SMS' : 'PV > (W,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.7025003,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 250.0084,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 210.6569,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 27.70633,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11.64521,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    }
]
}
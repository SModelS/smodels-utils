smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2018-41,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm828.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.24231,
        'upper limit (fb)' : 3.17,
        'expected upper limit (fb)' : 5.0,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.8),
            ('su_L', 220.8),
            ('N1~', 153.7),
            ('N1', 153.7)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR11_Njet7_Nb1_HT300_MHT300',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 4.177386,
        'r_expected' : 2.648463,
        'Width (GeV)' : [
            ('su_L~', 0.735709119),
            ('su_L', 0.735709119),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 5.344622e-14,
        'l_max' : 4.347692e-05,
        'l_SM' : 4.347692e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.279996,
        'upper limit (fb)' : 1.347,
        'expected upper limit (fb)' : 1.303,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.8),
            ('su_L', 220.8),
            ('N1~', 153.7),
            ('N1', 153.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-05',
        'DataSetID' : 'SRB',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.1,
        'dataType' : 'efficiencyMap',
        'r' : 1.692648,
        'r_expected' : 1.749805,
        'Width (GeV)' : [
            ('su_L~', 0.735709119),
            ('su_L', 0.735709119),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 7.000986e-06,
        'l_max' : 0.001971545,
        'l_SM' : 0.00196557
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03877331,
        'upper limit (fb)' : 0.03587523,
        'expected upper limit (fb)' : 0.05141451,
        'TxNames' : [
            'TChiHH',
            'TChiWH',
            'TChiWW',
            'TChiWZ',
            'TChiZH',
            'TChiZZ'
        ],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-41',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 1.080782,
        'r_expected' : 0.7541317,
        'Width (GeV)' : None,
        'likelihood' : 0.0001934016,
        'l_max' : 0.002358157,
        'l_SM' : 0.002358157
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2734147,
        'upper limit (fb)' : 0.3925577,
        'expected upper limit (fb)' : 0.4693609,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.6964955,
        'r_expected' : 0.5825254,
        'Width (GeV)' : None,
        'likelihood' : 0.03088255,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1137991,
        'upper limit (fb)' : 0.275627,
        'expected upper limit (fb)' : 0.1561782,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.4128737,
        'r_expected' : 0.728649,
        'Width (GeV)' : None,
        'likelihood' : 3.144788523084785e-81,
        'l_max' : 3.1460135185635977e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4286998,
        'upper limit (fb)' : 1.04,
        'expected upper limit (fb)' : 0.936,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.8),
            ('su_L', 220.8),
            ('N1~', 153.7),
            ('N1', 153.7)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.4122114,
        'r_expected' : 0.4580127,
        'Width (GeV)' : [
            ('su_L~', 0.735709119),
            ('su_L', 0.735709119),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003299716,
        'l_max' : 0.004463612,
        'l_SM' : 0.004373275
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 33.36076,
        'upper limit (fb)' : 82.18,
        'expected upper limit (fb)' : 94.92,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.8),
            ('su_L', 220.8),
            ('N1~', 153.7),
            ('N1', 153.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-21',
        'DataSetID' : 'M1',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.4059475,
        'r_expected' : 0.3514619,
        'Width (GeV)' : [
            ('su_L~', 0.735709119),
            ('su_L', 0.735709119),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 4.988273e-07,
        'l_max' : 8.399753e-07,
        'l_SM' : 8.399753e-07
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01141878,
        'upper limit (fb)' : 0.03622061,
        'expected upper limit (fb)' : 0.05175978,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 166.5),
            ('C1+/C1-', 161.5),
            ('N1', 153.7),
            ('N1/N1~', 153.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3152564,
        'r_expected' : 0.2206111,
        'Width (GeV)' : [
            ('N2', 2.7171e-07),
            ('C1+/C1-', 2.8856e-08),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.3758120000000003e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.224168,
        'upper limit (fb)' : 66.1,
        'expected upper limit (fb)' : 48.8,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 220.8),
            ('su_L', 220.8),
            ('N1~', 153.7),
            ('N1', 153.7)
        ],
        'AnalysisID' : 'ATLAS-CONF-2013-047',
        'DataSetID' : 'A Loose',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1244201,
        'r_expected' : 0.168528,
        'Width (GeV)' : [
            ('su_L~', 0.735709119),
            ('su_L', 0.735709119),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.848617e-06,
        'l_max' : 4.358706e-06,
        'l_SM' : 1.988754e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.007215911,
        'upper limit (fb)' : 0.08515711,
        'expected upper limit (fb)' : 0.04838175,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.08473645,
        'r_expected' : 0.1491453,
        'Width (GeV)' : None,
        'likelihood' : 7.066511588274566e-45,
        'l_max' : 9.573264137848177e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002578258,
        'upper limit (fb)' : 0.1883404,
        'expected upper limit (fb)' : 0.2010786,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01368935,
        'r_expected' : 0.01282214,
        'Width (GeV)' : None,
        'likelihood' : 4.2225913477578413e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002553248,
        'upper limit (fb)' : 0.1886999,
        'expected upper limit (fb)' : 0.2006371,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01353073,
        'r_expected' : 0.0127257,
        'Width (GeV)' : None,
        'likelihood' : 2.752832e-20,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.005172133,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 161.5),
            ('C1+', 161.5),
            ('N1~', 153.7),
            ('N1', 153.7)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.002383471,
        'r_expected' : 0.002451248,
        'Width (GeV)' : [
            ('C1-', 2.8856e-08),
            ('C1+', 2.8856e-08),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002989064,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2018-41,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-033',
        'r' : 5.171099,
        'r_expected' : 3.666725,
        'likelihood' : 6.175802002460507e-115,
        'l_max' : 2.048052630761853e-101,
        'l_SM' : 2.048052630761853e-101
    }
],
'Total xsec for missing topologies (fb)' : 2869.062,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1345.415,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1131.865,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 316.5271,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 32.11699,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30.90164,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.50657,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.956109,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.445926,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9487048,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1885078,
        'SMS' : 'PV > (MET), (Z,l,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 2869.062,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1345.415,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1131.865,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 316.5271,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 32.11699,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30.90164,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.50657,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.956109,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.445926,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9487048,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1885078,
        'SMS' : 'PV > (MET), (Z,l,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 261.779,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 227.1955,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 22.18045,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 12.40309,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    }
]
}
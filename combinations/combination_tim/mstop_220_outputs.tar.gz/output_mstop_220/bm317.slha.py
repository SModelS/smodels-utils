smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm317.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1530734,
        'upper limit (fb)' : 0.258422,
        'expected upper limit (fb)' : 0.2578983,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.5923387,
        'r_expected' : 0.5935417,
        'Width (GeV)' : None,
        'likelihood' : 2.092236e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4788744,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.1),
            ('su_L', 220.1),
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 160.6),
            ('N1', 160.6)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.3547218,
        'r_expected' : 0.4694847,
        'Width (GeV)' : [
            ('su_L~', 0.084567),
            ('su_L', 0.084567),
            ('C1-', 5.4742e-05),
            ('C1+', 5.4742e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003693529,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0535585,
        'upper limit (fb)' : 1.332537,
        'expected upper limit (fb)' : 1.052908,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.04019287,
        'r_expected' : 0.0508672,
        'Width (GeV)' : None,
        'likelihood' : 4.5235622373558766e-72,
        'l_max' : 5.193959416481797e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06008956,
        'upper limit (fb)' : 1.862585,
        'expected upper limit (fb)' : 2.227345,
        'TxNames' : ['TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.03226138,
        'r_expected' : 0.02697811,
        'Width (GeV)' : None,
        'likelihood' : 0.1114472,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0007608024,
        'upper limit (fb)' : 0.03371795,
        'expected upper limit (fb)' : 0.05032991,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-41',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.02256372,
        'r_expected' : 0.01511631,
        'Width (GeV)' : None,
        'likelihood' : 0.002270208,
        'l_max' : 0.002358157,
        'l_SM' : 0.002358157
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01190076,
        'upper limit (fb)' : 0.9295602,
        'expected upper limit (fb)' : 0.5428212,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01280257,
        'r_expected' : 0.02192391,
        'Width (GeV)' : None,
        'likelihood' : 1.1496210000000002e-32,
        'l_max' : 3.1705740000000007e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03478352,
        'upper limit (fb)' : 3.17,
        'expected upper limit (fb)' : 5.0,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-/N2', 204.6),
            ('C1+/C1-', 201.8),
            ('N1/N1~', 160.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR11_Njet7_Nb1_HT300_MHT300',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.01097272,
        'r_expected' : 0.006956703,
        'Width (GeV)' : [
            ('C1-/N2', 6.7739e-05),
            ('C1+/C1-', 5.4742e-05),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.288875e-05,
        'l_max' : 4.347692e-05,
        'l_SM' : 4.347692e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002923189,
        'upper limit (fb)' : 0.3032431,
        'expected upper limit (fb)' : 0.1788753,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.009639754,
        'r_expected' : 0.01634205,
        'Width (GeV)' : None,
        'likelihood' : 1.0980182346710356e-81,
        'l_max' : 1.983643680318896e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01495893,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 160.6),
            ('N1', 160.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.006893515,
        'r_expected' : 0.00708954,
        'Width (GeV)' : [
            ('C1-', 5.4742e-05),
            ('C1+', 5.4742e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002990394,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0002476759,
        'upper limit (fb)' : 0.07285515,
        'expected upper limit (fb)' : 0.04003702,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.003399566,
        'r_expected' : 0.006186172,
        'Width (GeV)' : None,
        'likelihood' : 5.50711645732256e-45,
        'l_max' : 5.781181581328395e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2068071,
        'upper limit (fb)' : 77.8,
        'expected upper limit (fb)' : 97.112,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-/N2', 205.03),
            ('C1+/C1-', 201.8),
            ('N1/N1~', 160.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR2jl',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.002658189,
        'r_expected' : 0.002129573,
        'Width (GeV)' : [
            ('C1-/N2', 6.9771e-05),
            ('C1+/C1-', 5.4742e-05),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 1.134257e-06,
        'l_max' : 1.137494e-06,
        'l_SM' : 1.137494e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001268755,
        'upper limit (fb)' : 1.0102,
        'expected upper limit (fb)' : 0.6791972,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.001255945,
        'r_expected' : 0.001868022,
        'Width (GeV)' : None,
        'likelihood' : 2.777217e-20,
        'l_max' : 5.989781e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 1.3339705190596918e-06,
        'theory prediction (fb)' : 0.0001448325,
        'upper limit (fb)' : 0.813,
        'expected upper limit (fb)' : 1.19,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 160.6),
            ('N1', 160.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-SF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.0001781458,
        'r_expected' : 0.000121708,
        'Width (GeV)' : [
            ('C1-', 5.4742e-05),
            ('C1+', 5.4742e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001267221,
        'l_max' : 0.001267591,
        'l_SM' : 0.001267591
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.6792674,
        'r_expected' : 0.8086612,
        'likelihood' : 7.727734616053e-41,
        'l_max' : 1.451946e-40,
        'l_SM' : 1.3366570000000001e-40
    }
],
'Total xsec for missing topologies (fb)' : 8217.987,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3725.66,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1252.459,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1244.019,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 428.7515,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 308.9087,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 208.0603,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 143.1625,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 143.1625,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 107.5621,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 71.09885,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 8217.987,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3725.66,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1252.459,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1244.019,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 428.7515,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 308.9087,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 208.0603,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 143.1625,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 143.1625,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 107.5621,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 71.09885,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7541.491,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7501.877,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30.47021,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.570974,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2782881,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2136207,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0539945,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02681531,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm317.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1530734,
        'upper limit (fb)' : 0.258422,
        'expected upper limit (fb)' : 0.2578983,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.5923387,
        'r_expected' : 0.5935417,
        'Width (GeV)' : None,
        'likelihood' : 2.092236e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4788744,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.1),
            ('su_L', 220.1),
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 160.6),
            ('N1', 160.6)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.3547218,
        'r_expected' : 0.4694847,
        'Width (GeV)' : [
            ('su_L~', 0.084567),
            ('su_L', 0.084567),
            ('C1-', 5.4742e-05),
            ('C1+', 5.4742e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003693529,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0535585,
        'upper limit (fb)' : 1.332537,
        'expected upper limit (fb)' : 1.052908,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.04019287,
        'r_expected' : 0.0508672,
        'Width (GeV)' : None,
        'likelihood' : 4.5235622373558766e-72,
        'l_max' : 5.193959416481797e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06008956,
        'upper limit (fb)' : 1.862585,
        'expected upper limit (fb)' : 2.227345,
        'TxNames' : ['TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.03226138,
        'r_expected' : 0.02697811,
        'Width (GeV)' : None,
        'likelihood' : 0.1114472,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0007608024,
        'upper limit (fb)' : 0.03371795,
        'expected upper limit (fb)' : 0.05032991,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-41',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.02256372,
        'r_expected' : 0.01511631,
        'Width (GeV)' : None,
        'likelihood' : 0.002270208,
        'l_max' : 0.002358157,
        'l_SM' : 0.002358157
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01190076,
        'upper limit (fb)' : 0.9295602,
        'expected upper limit (fb)' : 0.5428212,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01280257,
        'r_expected' : 0.02192391,
        'Width (GeV)' : None,
        'likelihood' : 1.1496210000000002e-32,
        'l_max' : 3.1705740000000007e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03478352,
        'upper limit (fb)' : 3.17,
        'expected upper limit (fb)' : 5.0,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-/N2', 204.6),
            ('C1+/C1-', 201.8),
            ('N1/N1~', 160.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR11_Njet7_Nb1_HT300_MHT300',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.01097272,
        'r_expected' : 0.006956703,
        'Width (GeV)' : [
            ('C1-/N2', 6.7739e-05),
            ('C1+/C1-', 5.4742e-05),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.288875e-05,
        'l_max' : 4.347692e-05,
        'l_SM' : 4.347692e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002923189,
        'upper limit (fb)' : 0.3032431,
        'expected upper limit (fb)' : 0.1788753,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.009639754,
        'r_expected' : 0.01634205,
        'Width (GeV)' : None,
        'likelihood' : 1.0980182346710356e-81,
        'l_max' : 1.983643680318896e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01495893,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 160.6),
            ('N1', 160.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.006893515,
        'r_expected' : 0.00708954,
        'Width (GeV)' : [
            ('C1-', 5.4742e-05),
            ('C1+', 5.4742e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002990394,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0002476759,
        'upper limit (fb)' : 0.07285515,
        'expected upper limit (fb)' : 0.04003702,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.003399566,
        'r_expected' : 0.006186172,
        'Width (GeV)' : None,
        'likelihood' : 5.50711645732256e-45,
        'l_max' : 5.781181581328395e-45,
        'l_SM' : 5.4389172595677885e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2068071,
        'upper limit (fb)' : 77.8,
        'expected upper limit (fb)' : 97.112,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-/N2', 205.03),
            ('C1+/C1-', 201.8),
            ('N1/N1~', 160.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR2jl',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.002658189,
        'r_expected' : 0.002129573,
        'Width (GeV)' : [
            ('C1-/N2', 6.9771e-05),
            ('C1+/C1-', 5.4742e-05),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 1.134257e-06,
        'l_max' : 1.137494e-06,
        'l_SM' : 1.137494e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001268755,
        'upper limit (fb)' : 1.0102,
        'expected upper limit (fb)' : 0.6791972,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.001255945,
        'r_expected' : 0.001868022,
        'Width (GeV)' : None,
        'likelihood' : 2.777217e-20,
        'l_max' : 5.989781e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 1.3339705190596918e-06,
        'theory prediction (fb)' : 0.0001448325,
        'upper limit (fb)' : 0.813,
        'expected upper limit (fb)' : 1.19,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 160.6),
            ('N1', 160.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-SF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.0001781458,
        'r_expected' : 0.000121708,
        'Width (GeV)' : [
            ('C1-', 5.4742e-05),
            ('C1+', 5.4742e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001267221,
        'l_max' : 0.001267591,
        'l_SM' : 0.001267591
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.6792674,
        'r_expected' : 0.8086612,
        'likelihood' : 7.727734616053e-41,
        'l_max' : 1.451946e-40,
        'l_SM' : 1.3366570000000001e-40
    }
],
'Total xsec for missing topologies (fb)' : 8217.987,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3725.66,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1252.459,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1244.019,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 428.7515,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 308.9087,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 208.0603,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 143.1625,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 143.1625,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 107.5621,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 71.09885,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 8217.987,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3725.66,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1252.459,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1244.019,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 428.7515,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 308.9087,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 208.0603,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 143.1625,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 143.1625,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 107.5621,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 71.09885,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7541.491,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7501.877,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30.47021,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.570974,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2782881,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2136207,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0539945,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02681531,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
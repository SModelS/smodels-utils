smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm705.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.142485,
        'upper limit (fb)' : 1.347,
        'expected upper limit (fb)' : 1.303,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 221.0),
            ('su_L', 221.0),
            ('N1~', 188.5),
            ('N1', 188.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-05',
        'DataSetID' : 'SRB',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.8481701,
        'r_expected' : 0.8768113,
        'Width (GeV)' : [
            ('su_L~', 0.144337321),
            ('su_L', 0.144337321),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0004814409,
        'l_max' : 0.001971545,
        'l_SM' : 0.00196557
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 15.31653,
        'upper limit (fb)' : 27.19,
        'expected upper limit (fb)' : 27.57,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 221.0),
            ('su_L', 221.0),
            ('N1~', 188.5),
            ('N1', 188.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-21',
        'DataSetID' : 'M2',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.5633148,
        'r_expected' : 0.5555506,
        'Width (GeV)' : [
            ('su_L~', 0.144337321),
            ('su_L', 0.144337321),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 3.325483e-06,
        'l_max' : 6.346427e-06,
        'l_SM' : 6.346427e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1645548,
        'upper limit (fb)' : 0.3382451,
        'expected upper limit (fb)' : 0.4043937,
        'TxNames' : ['TChiWWoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4864957,
        'r_expected' : 0.4069173,
        'Width (GeV)' : None,
        'likelihood' : 0.05188021,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.101217,
        'upper limit (fb)' : 2.88,
        'expected upper limit (fb)' : 2.01,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 221.0),
            ('su_L', 221.0),
            ('N1~', 188.5),
            ('N1', 188.5)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.3823672,
        'r_expected' : 0.5478694,
        'Width (GeV)' : [
            ('su_L~', 0.144337321),
            ('su_L', 0.144337321),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0009123332,
        'l_max' : 0.0009521956,
        'l_SM' : 0.0006572509
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01052129,
        'upper limit (fb)' : 0.03524951,
        'expected upper limit (fb)' : 0.05058194,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 201.8),
            ('C1+/C1-', 196.8),
            ('N1', 188.5),
            ('N1/N1~', 188.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2984803,
        'r_expected' : 0.2080048,
        'Width (GeV)' : [
            ('N2', 3.2963e-07),
            ('C1+/C1-', 3.8787e-08),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.456556e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.947768,
        'upper limit (fb)' : 66.1,
        'expected upper limit (fb)' : 48.8,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 221.0),
            ('su_L', 221.0),
            ('N1~', 188.5),
            ('N1', 188.5)
        ],
        'AnalysisID' : 'ATLAS-CONF-2013-047',
        'DataSetID' : 'A Loose',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.07485278,
        'r_expected' : 0.1013887,
        'Width (GeV)' : [
            ('su_L~', 0.144337321),
            ('su_L', 0.144337321),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.501188e-06,
        'l_max' : 4.358706e-06,
        'l_SM' : 1.988754e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.003233769,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 196.8),
            ('C1+', 196.8),
            ('N1~', 188.5),
            ('N1', 188.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.001490216,
        'r_expected' : 0.001532592,
        'Width (GeV)' : [
            ('C1-', 3.8787e-08),
            ('C1+', 3.8787e-08),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002988766,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 1.351039,
        'r_expected' : 1.392753,
        'likelihood' : 1.8615701950779604e-51,
        'l_max' : 4.176399979027781e-50,
        'l_SM' : 4.1704642093698686e-50
    }
],
'Total xsec for missing topologies (fb)' : 1804.672,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1015.764,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 581.7855,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 168.4533,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.11096,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 17.89107,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.54057,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4777404,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3403808,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2023378,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0443604,
        'SMS' : 'PV > (MET), (Z,l,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1804.672,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1015.764,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 581.7855,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 168.4533,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.11096,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 17.89107,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.54057,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4777404,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3403808,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2023378,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0443604,
        'SMS' : 'PV > (MET), (Z,l,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 153.4213,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 132.0308,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.19505,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.195453,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    }
]
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm705.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.142485,
        'upper limit (fb)' : 1.347,
        'expected upper limit (fb)' : 1.303,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 221.0),
            ('su_L', 221.0),
            ('N1~', 188.5),
            ('N1', 188.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-05',
        'DataSetID' : 'SRB',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.8481701,
        'r_expected' : 0.8768113,
        'Width (GeV)' : [
            ('su_L~', 0.144337321),
            ('su_L', 0.144337321),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0004814409,
        'l_max' : 0.001971545,
        'l_SM' : 0.00196557
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 15.31653,
        'upper limit (fb)' : 27.19,
        'expected upper limit (fb)' : 27.57,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 221.0),
            ('su_L', 221.0),
            ('N1~', 188.5),
            ('N1', 188.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-21',
        'DataSetID' : 'M2',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.5633148,
        'r_expected' : 0.5555506,
        'Width (GeV)' : [
            ('su_L~', 0.144337321),
            ('su_L', 0.144337321),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 3.325483e-06,
        'l_max' : 6.346427e-06,
        'l_SM' : 6.346427e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1645548,
        'upper limit (fb)' : 0.3382451,
        'expected upper limit (fb)' : 0.4043937,
        'TxNames' : ['TChiWWoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4864957,
        'r_expected' : 0.4069173,
        'Width (GeV)' : None,
        'likelihood' : 0.05188021,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.101217,
        'upper limit (fb)' : 2.88,
        'expected upper limit (fb)' : 2.01,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 221.0),
            ('su_L', 221.0),
            ('N1~', 188.5),
            ('N1', 188.5)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.3823672,
        'r_expected' : 0.5478694,
        'Width (GeV)' : [
            ('su_L~', 0.144337321),
            ('su_L', 0.144337321),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0009123332,
        'l_max' : 0.0009521956,
        'l_SM' : 0.0006572509
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01052129,
        'upper limit (fb)' : 0.03524951,
        'expected upper limit (fb)' : 0.05058194,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 201.8),
            ('C1+/C1-', 196.8),
            ('N1', 188.5),
            ('N1/N1~', 188.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2984803,
        'r_expected' : 0.2080048,
        'Width (GeV)' : [
            ('N2', 3.2963e-07),
            ('C1+/C1-', 3.8787e-08),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.456556e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.947768,
        'upper limit (fb)' : 66.1,
        'expected upper limit (fb)' : 48.8,
        'TxNames' : ['T2bb'],
        'Mass (GeV)' : [
            ('su_L~', 221.0),
            ('su_L', 221.0),
            ('N1~', 188.5),
            ('N1', 188.5)
        ],
        'AnalysisID' : 'ATLAS-CONF-2013-047',
        'DataSetID' : 'A Loose',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.07485278,
        'r_expected' : 0.1013887,
        'Width (GeV)' : [
            ('su_L~', 0.144337321),
            ('su_L', 0.144337321),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.501188e-06,
        'l_max' : 4.358706e-06,
        'l_SM' : 1.988754e-06
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.003233769,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 196.8),
            ('C1+', 196.8),
            ('N1~', 188.5),
            ('N1', 188.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.001490216,
        'r_expected' : 0.001532592,
        'Width (GeV)' : [
            ('C1-', 3.8787e-08),
            ('C1+', 3.8787e-08),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002988766,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-05,ATLAS-SUSY-2013-21,ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 1.351039,
        'r_expected' : 1.392753,
        'likelihood' : 1.8615701950779604e-51,
        'l_max' : 4.176399979027781e-50,
        'l_SM' : 4.1704642093698686e-50
    }
],
'Total xsec for missing topologies (fb)' : 1804.672,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1015.764,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 581.7855,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 168.4533,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.11096,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 17.89107,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.54057,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4777404,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3403808,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2023378,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0443604,
        'SMS' : 'PV > (MET), (Z,l,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1804.672,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1015.764,
        'SMS' : 'PV > (MET), (b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 581.7855,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 168.4533,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.11096,
        'SMS' : 'PV > (MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 17.89107,
        'SMS' : 'PV > (MET), (ta,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.54057,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4777404,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3403808,
        'SMS' : 'PV > (MET), (Z,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2023378,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0443604,
        'SMS' : 'PV > (MET), (Z,l,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 153.4213,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 132.0308,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.19505,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.195453,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    }
]
}
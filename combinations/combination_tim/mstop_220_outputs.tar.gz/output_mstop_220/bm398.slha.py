smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm398.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.127587,
        'upper limit (fb)' : 1.406488,
        'expected upper limit (fb)' : 1.660807,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8017043,
        'r_expected' : 0.6789395,
        'Width (GeV)' : None,
        'likelihood' : 9.892117528353928e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.029742,
        'upper limit (fb)' : 1.436612,
        'expected upper limit (fb)' : 1.407384,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.7167852,
        'r_expected' : 0.7316711,
        'Width (GeV)' : None,
        'likelihood' : 1.1134530000000002e-20,
        'l_max' : 2.776619e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9001038,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.6667435,
        'r_expected' : 0.8824547,
        'Width (GeV)' : None,
        'likelihood' : 0.001886333,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1431531,
        'upper limit (fb)' : 0.353256,
        'expected upper limit (fb)' : 0.2625689,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4052389,
        'r_expected' : 0.5452018,
        'Width (GeV)' : None,
        'likelihood' : 1.6897850000000004e-24,
        'l_max' : 1.7374170000000003e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.08650235,
        'upper limit (fb)' : 0.2823386,
        'expected upper limit (fb)' : 0.3254736,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 201.7),
            ('C1+', 201.7),
            ('N1~', 77.8),
            ('N1', 77.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.306378,
        'r_expected' : 0.2657738,
        'Width (GeV)' : [
            ('C1-', 0.0791264825),
            ('C1+', 0.0791264825),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.184758e-40,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2924024,
        'upper limit (fb)' : 0.974,
        'expected upper limit (fb)' : 0.765,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.9),
            ('su_L', 220.9),
            ('C1-', 201.7),
            ('C1+', 201.7),
            ('N1~', 77.8),
            ('N1', 77.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_0bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.3002078,
        'r_expected' : 0.3822253,
        'Width (GeV)' : [
            ('su_L~', 0.0920027537),
            ('su_L', 0.0920027537),
            ('C1-', 0.0791264825),
            ('C1+', 0.0791264825),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.006229551,
        'l_max' : 0.006278059,
        'l_SM' : 0.004973309
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01248711,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.127,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.7),
            ('N2/N3', 208.92),
            ('N1/N1~', 77.8),
            ('N1', 77.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.1387457,
        'r_expected' : 0.09832371,
        'Width (GeV)' : [
            ('C1+/C1-', 0.079126),
            ('N2/N3', 0.052591),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1564574,
        'l_max' : 0.2014847,
        'l_SM' : 0.2014847
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.007137777,
        'upper limit (fb)' : 0.05753362,
        'expected upper limit (fb)' : 0.06039184,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.7),
            ('N2', 208.3),
            ('N1/N1~', 77.8),
            ('N1', 77.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1240627,
        'r_expected' : 0.1181911,
        'Width (GeV)' : [
            ('C1+/C1-', 0.079126),
            ('N2', 0.057001),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 8.749362e-11,
        'l_max' : 9.107398e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03551679,
        'upper limit (fb)' : 0.531,
        'expected upper limit (fb)' : 0.438,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 201.7),
            ('C1+', 201.7),
            ('N1~', 77.8),
            ('N1', 77.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWc-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.06688661,
        'r_expected' : 0.08108856,
        'Width (GeV)' : [
            ('C1-', 0.0791264825),
            ('C1+', 0.0791264825),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.02051768,
        'l_max' : 0.02164771,
        'l_SM' : 0.01893459
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02652059,
        'upper limit (fb)' : 0.4155116,
        'expected upper limit (fb)' : 0.6441444,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.06382637,
        'r_expected' : 0.04117181,
        'Width (GeV)' : None,
        'likelihood' : 9.70495589202891e-82,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02418188,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.7),
            ('N2/N3', 208.92),
            ('N1/N1~', 77.8),
            ('N1', 77.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.05757592,
        'r_expected' : 0.1272731,
        'Width (GeV)' : [
            ('C1+/C1-', 0.079126),
            ('N2/N3', 0.052599),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002157924,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg',
        'r' : 1.030855,
        'r_expected' : 1.403774,
        'likelihood' : 2.2918428469143614e-99,
        'l_max' : 1.2661139366739763e-98,
        'l_SM' : 7.815615673197284e-99
    }
],
'Total xsec for missing topologies (fb)' : 1099.369,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 967.9811,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 72.39748,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 51.96164,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.362776,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.666096,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1099.369,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 967.9811,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 72.39748,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 51.96164,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.362776,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.666096,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 64.49653,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 64.49653,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
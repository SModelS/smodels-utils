smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm248.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3566346,
        'upper limit (fb)' : 0.3162212,
        'expected upper limit (fb)' : 0.3280363,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 1.127801,
        'r_expected' : 1.08718,
        'Width (GeV)' : None,
        'likelihood' : 3.6565630000000005e-39,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2075287,
        'upper limit (fb)' : 13.292,
        'expected upper limit (fb)' : 11.561,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-/N2/N3', 194.61),
            ('C1+/C1-/N2', 187.26),
            ('N1/N1~', 111.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jlm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.01561305,
        'r_expected' : 0.01795075,
        'Width (GeV)' : [
            ('C1-/N2/N3', 0.00095837),
            ('C1+/C1-/N2', 0.0009144),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.895646e-05,
        'l_max' : 3.106569e-05,
        'l_SM' : 2.855812e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.009479464,
        'upper limit (fb)' : 0.8735264,
        'expected upper limit (fb)' : 0.5732114,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 186.6),
            ('N2', 193.0),
            ('N1/N1~', 111.0),
            ('N1', 111.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01085195,
        'r_expected' : 0.01653747,
        'Width (GeV)' : [
            ('C1+/C1-', 0.00093648),
            ('N2', 0.00072211),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.1186000000000003e-32,
        'l_max' : 1.9906800000000004e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01095887,
        'upper limit (fb)' : 1.73,
        'expected upper limit (fb)' : 1.24,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 186.6),
            ('C1+', 186.6),
            ('N1~', 111.0),
            ('N1', 111.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '4j_Meff_1400',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.006334609,
        'r_expected' : 0.008837801,
        'Width (GeV)' : [
            ('C1-', 0.00093648),
            ('C1+', 0.00093648),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.00051894,
        'l_max' : 0.000704842,
        'l_SM' : 0.0005112937
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0003176598,
        'upper limit (fb)' : 3.55,
        'expected upper limit (fb)' : 4.74,
        'TxNames' : ['T1bbbb'],
        'Mass (GeV)' : [('N3', 201.7), ('N2', 193.0), ('N1', 111.0)],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 8.948165e-05,
        'r_expected' : 6.701685e-05,
        'Width (GeV)' : [
            ('N3', 0.00118641555),
            ('N2', 0.000722106569),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0001933367,
        'l_max' : 0.0001933524,
        'l_SM' : 0.0001933524
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.504328e-05,
        'upper limit (fb)' : 0.403,
        'expected upper limit (fb)' : 0.446,
        'TxNames' : ['T1bbbb'],
        'Mass (GeV)' : [('N3', 201.7), ('N2', 193.0), ('N1', 111.0)],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_9ej50_2ibjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 6.214212e-05,
        'r_expected' : 5.615084e-05,
        'Width (GeV)' : [
            ('N3', 0.00118641555),
            ('N2', 0.000722106569),
            ('N1', 'stable')
        ],
        'likelihood' : 0.02127538,
        'l_max' : 0.02127611,
        'l_SM' : 0.02127611
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'r' : 1.127801,
        'r_expected' : 1.08718,
        'likelihood' : 3.6565630000000005e-39,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    }
],
'Total xsec for missing topologies (fb)' : 8407.484,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3755.437,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1251.566,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1249.989,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 500.1925,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 313.2863,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 245.8859,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 166.698,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 166.698,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 163.6327,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 83.45416,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 8407.484,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3755.437,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1251.566,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1249.989,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 500.1925,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 313.2863,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 245.8859,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 166.698,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 166.698,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 163.6327,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 83.45416,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 18890.4,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11254.33,
        'SMS' : 'PV > (b,jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7501.411,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 85.60493,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 23.34165,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.50453,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.819332,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.389331,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
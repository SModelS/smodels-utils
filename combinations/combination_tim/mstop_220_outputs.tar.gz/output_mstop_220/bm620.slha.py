smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012,ATLAS-SUSY-2018-16',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm620.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01858364,
        'upper limit (fb)' : 0.04688782,
        'expected upper limit (fb)' : 0.05987458,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 202.0),
            ('C1+/C1-', 196.8),
            ('N1', 185.8),
            ('N1/N1~', 185.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3963427,
        'r_expected' : 0.3103762,
        'Width (GeV)' : [
            ('N2', 8.5668e-07),
            ('C1+/C1-', 1.5699e-07),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.2221280000000003e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.118749,
        'upper limit (fb)' : 2.88,
        'expected upper limit (fb)' : 2.01,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.5),
            ('su_L', 220.5),
            ('C1-', 196.8),
            ('C1+', 196.8),
            ('N1~', 185.8),
            ('N1', 185.8)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.3884546,
        'r_expected' : 0.5565917,
        'Width (GeV)' : [
            ('su_L~', 0.13928),
            ('su_L', 0.13928),
            ('C1-', 1.5699e-07),
            ('C1+', 1.5699e-07),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0009073314,
        'l_max' : 0.0009521956,
        'l_SM' : 0.0006572509
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0722027,
        'upper limit (fb)' : 0.3349727,
        'expected upper limit (fb)' : 0.4005301,
        'TxNames' : ['TChiWWoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.215548,
        'r_expected' : 0.1802679,
        'Width (GeV)' : None,
        'likelihood' : 0.08787705,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.004310074,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [('C1+/C1-', 196.8), ('N1/N1~', 185.8)],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.001986209,
        'r_expected' : 0.002042689,
        'Width (GeV)' : [('C1+/C1-', 1.5699e-07), ('N1/N1~', 'stable')],
        'likelihood' : 0.0002988933,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001521596,
        'upper limit (fb)' : 1.147593,
        'expected upper limit (fb)' : 0.8269226,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 202.0),
            ('C1+/C1-', 196.8),
            ('N1', 185.8),
            ('N1/N1~', 185.8)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.001325902,
        'r_expected' : 0.00184007,
        'Width (GeV)' : [
            ('N2', 8.5668e-07),
            ('C1+/C1-', 1.5699e-07),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.2566016556558324e-72,
        'l_max' : 5.487133607705823e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 8.52793524304199e-05,
        'theory prediction (fb)' : 3.1016e-05,
        'upper limit (fb)' : 1.38082,
        'expected upper limit (fb)' : 0.867266,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 202.0),
            ('C1+/C1-', 196.8),
            ('N1', 185.8),
            ('N1/N1~', 185.8)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : 'AR9',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 2.246201e-05,
        'r_expected' : 3.576296e-05,
        'Width (GeV)' : [
            ('N2', 8.5668e-07),
            ('C1+/C1-', 1.5699e-07),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.0005476223,
        'l_max' : 0.001261199,
        'l_SM' : 0.0005475719
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.6779041,
        'r_expected' : 0.7724742,
        'likelihood' : 1.7717827391708973e-42,
        'l_max' : 3.343232255508956e-42,
        'l_SM' : 3.343232255508956e-42
    }
],
'Total xsec for missing topologies (fb)' : 7954.396,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3394.984,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1323.969,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1168.135,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 456.2106,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 366.4699,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 257.6608,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 156.9715,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 156.9715,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 124.063,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 89.86014,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 7954.396,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3394.984,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1323.969,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1168.135,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 456.2106,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 366.4699,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 257.6608,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 156.9715,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 156.9715,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 124.063,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 89.86014,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7869.033,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7695.776,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 127.3386,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.0253,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 16.52781,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.856264,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.508741,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
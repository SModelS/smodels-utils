smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,ATLAS-SUSY-2019-09,ATLAS-SUSY-2018-16',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm571.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.055744,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.4),
            ('su_L', 220.4),
            ('C1-', 141.2),
            ('C1+', 141.2),
            ('N1~', 115.8),
            ('N1', 115.8)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.7820329,
        'r_expected' : 1.035044,
        'Width (GeV)' : [
            ('su_L~', 1.1809),
            ('su_L', 1.1809),
            ('C1-', 7.0851e-06),
            ('C1+', 7.0851e-06),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001221534,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1437523,
        'upper limit (fb)' : 0.1935111,
        'expected upper limit (fb)' : 0.18229,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 147.4),
            ('C1+/C1-', 141.2),
            ('N1', 115.8),
            ('N1/N1~', 115.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.7428634,
        'r_expected' : 0.7885915,
        'Width (GeV)' : [
            ('N2', 1.5892e-05),
            ('C1+/C1-', 7.0851e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 1.6134620000000003e-38,
        'l_max' : 4.4630690000000004e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1430271,
        'upper limit (fb)' : 0.4261479,
        'expected upper limit (fb)' : 0.5095329,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3356278,
        'r_expected' : 0.2807024,
        'Width (GeV)' : None,
        'likelihood' : 0.07121947,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05447202,
        'upper limit (fb)' : 1.406788,
        'expected upper limit (fb)' : 1.157506,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 147.4),
            ('C1+/C1-', 141.2),
            ('N1', 115.8),
            ('N1/N1~', 115.8)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.03872086,
        'r_expected' : 0.04705982,
        'Width (GeV)' : [
            ('N2', 1.5892e-05),
            ('C1+/C1-', 7.0851e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.4280291600355233e-72,
        'l_max' : 4.744404259742896e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03935671,
        'upper limit (fb)' : 1.427311,
        'expected upper limit (fb)' : 0.7251134,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.02757403,
        'r_expected' : 0.05427662,
        'Width (GeV)' : None,
        'likelihood' : 1.3212970000000003e-32,
        'l_max' : 7.494976000000002e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01506673,
        'upper limit (fb)' : 1.923,
        'expected upper limit (fb)' : 1.5312,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1+/C1-/N2', 144.76),
            ('C1+/C1-', 141.2),
            ('N1/N1~', 115.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR6jl',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.007835011,
        'r_expected' : 0.009839816,
        'Width (GeV)' : [
            ('C1+/C1-/N2', 1.214e-05),
            ('C1+/C1-', 7.0851e-06),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.001079654,
        'l_max' : 0.001314425,
        'l_SM' : 0.001066031
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.003064301,
        'upper limit (fb)' : 1.28375,
        'expected upper limit (fb)' : 0.8390083,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 147.4),
            ('C1+/C1-', 141.2),
            ('N1', 115.8),
            ('N1/N1~', 115.8)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.002386992,
        'r_expected' : 0.003652289,
        'Width (GeV)' : [
            ('N2', 1.5892e-05),
            ('C1+/C1-', 7.0851e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.783938e-20,
        'l_max' : 4.7576290000000007e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.923214e-05,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('N3', 191.6),
            ('C1+/C1-', 141.2),
            ('N1', 115.8),
            ('N1/N1~', 115.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 1.807932e-05,
        'r_expected' : 1.859343e-05,
        'Width (GeV)' : [
            ('N3', 0.00026223),
            ('C1+/C1-', 7.0851e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.0002988251,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 1.205701,
        'r_expected' : 1.476261,
        'likelihood' : 1.4036629743348718e-42,
        'l_max' : 1.7698297218279521e-41,
        'l_SM' : 1.5358129351403325e-41
    }
],
'Total xsec for missing topologies (fb)' : 10649.07,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3656.412,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1252.682,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1225.617,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1062.89,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 754.3518,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 303.922,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 299.7844,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 262.2989,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 252.8563,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 252.8563,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 10649.07,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3656.412,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1252.682,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1225.617,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1062.89,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 754.3518,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 303.922,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 299.7844,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 262.2989,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 252.8563,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 252.8563,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7580.497,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7474.307,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 85.34617,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 16.03839,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.826443,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6878913,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1367125,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.08761062,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06687941,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,ATLAS-SUSY-2019-09,ATLAS-SUSY-2018-16',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm571.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.055744,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.4),
            ('su_L', 220.4),
            ('C1-', 141.2),
            ('C1+', 141.2),
            ('N1~', 115.8),
            ('N1', 115.8)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.7820329,
        'r_expected' : 1.035044,
        'Width (GeV)' : [
            ('su_L~', 1.1809),
            ('su_L', 1.1809),
            ('C1-', 7.0851e-06),
            ('C1+', 7.0851e-06),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001221534,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1437523,
        'upper limit (fb)' : 0.1935111,
        'expected upper limit (fb)' : 0.18229,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 147.4),
            ('C1+/C1-', 141.2),
            ('N1', 115.8),
            ('N1/N1~', 115.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.7428634,
        'r_expected' : 0.7885915,
        'Width (GeV)' : [
            ('N2', 1.5892e-05),
            ('C1+/C1-', 7.0851e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 1.6134620000000003e-38,
        'l_max' : 4.4630690000000004e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1430271,
        'upper limit (fb)' : 0.4261479,
        'expected upper limit (fb)' : 0.5095329,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3356278,
        'r_expected' : 0.2807024,
        'Width (GeV)' : None,
        'likelihood' : 0.07121947,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05447202,
        'upper limit (fb)' : 1.406788,
        'expected upper limit (fb)' : 1.157506,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 147.4),
            ('C1+/C1-', 141.2),
            ('N1', 115.8),
            ('N1/N1~', 115.8)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.03872086,
        'r_expected' : 0.04705982,
        'Width (GeV)' : [
            ('N2', 1.5892e-05),
            ('C1+/C1-', 7.0851e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.4280291600355233e-72,
        'l_max' : 4.744404259742896e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03935671,
        'upper limit (fb)' : 1.427311,
        'expected upper limit (fb)' : 0.7251134,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.02757403,
        'r_expected' : 0.05427662,
        'Width (GeV)' : None,
        'likelihood' : 1.3212970000000003e-32,
        'l_max' : 7.494976000000002e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01506673,
        'upper limit (fb)' : 1.923,
        'expected upper limit (fb)' : 1.5312,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1+/C1-/N2', 144.76),
            ('C1+/C1-', 141.2),
            ('N1/N1~', 115.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR6jl',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.007835011,
        'r_expected' : 0.009839816,
        'Width (GeV)' : [
            ('C1+/C1-/N2', 1.214e-05),
            ('C1+/C1-', 7.0851e-06),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.001079654,
        'l_max' : 0.001314425,
        'l_SM' : 0.001066031
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.003064301,
        'upper limit (fb)' : 1.28375,
        'expected upper limit (fb)' : 0.8390083,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 147.4),
            ('C1+/C1-', 141.2),
            ('N1', 115.8),
            ('N1/N1~', 115.8)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.002386992,
        'r_expected' : 0.003652289,
        'Width (GeV)' : [
            ('N2', 1.5892e-05),
            ('C1+/C1-', 7.0851e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.783938e-20,
        'l_max' : 4.7576290000000007e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.923214e-05,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('N3', 191.6),
            ('C1+/C1-', 141.2),
            ('N1', 115.8),
            ('N1/N1~', 115.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 1.807932e-05,
        'r_expected' : 1.859343e-05,
        'Width (GeV)' : [
            ('N3', 0.00026223),
            ('C1+/C1-', 7.0851e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.0002988251,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 1.205701,
        'r_expected' : 1.476261,
        'likelihood' : 1.4036629743348718e-42,
        'l_max' : 1.7698297218279521e-41,
        'l_SM' : 1.5358129351403325e-41
    }
],
'Total xsec for missing topologies (fb)' : 10649.07,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3656.412,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1252.682,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1225.617,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1062.89,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 754.3518,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 303.922,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 299.7844,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 262.2989,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 252.8563,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 252.8563,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 10649.07,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3656.412,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1252.682,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1225.617,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1062.89,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 754.3518,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 303.922,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 299.7844,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 262.2989,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 252.8563,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 252.8563,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7580.497,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7474.307,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 85.34617,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 16.03839,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.826443,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6878913,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1367125,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.08761062,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06687941,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
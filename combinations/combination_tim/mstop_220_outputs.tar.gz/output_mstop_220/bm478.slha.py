smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '1.00E+01 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,CMS-SUS-13-012,CMS-SUS-16-039-agg,ATLAS-SUSY-2019-09',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : 'mstop_220/bm478.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.185015,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 119.3),
            ('N1', 119.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 3.806646,
        'r_expected' : 3.382376,
        'Width (GeV)' : [
            ('C1-', 0.0301089343),
            ('C1+', 0.0301089343),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 5.02176e-11,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.058416,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.7840117,
        'r_expected' : 1.037663,
        'Width (GeV)' : None,
        'likelihood' : 0.001211441,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.378106,
        'upper limit (fb)' : 2.337053,
        'expected upper limit (fb)' : 1.435457,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.5896769,
        'r_expected' : 0.9600472,
        'Width (GeV)' : None,
        'likelihood' : 8.605116000000001e-20,
        'l_max' : 9.520848000000001e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0694004,
        'upper limit (fb)' : 0.3338263,
        'expected upper limit (fb)' : 0.2388734,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2078938,
        'r_expected' : 0.2905322,
        'Width (GeV)' : None,
        'likelihood' : 1.8102680000000002e-24,
        'l_max' : 1.924857e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01010695,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.127,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N3', 226.4),
            ('N1/N1~', 119.3),
            ('N1', 119.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.1122995,
        'r_expected' : 0.07958229,
        'Width (GeV)' : [
            ('C1+/C1-', 0.030109),
            ('N3', 0.0084547),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1646412,
        'l_max' : 0.2014847,
        'l_SM' : 0.2014847
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001967689,
        'upper limit (fb)' : 0.5687,
        'expected upper limit (fb)' : 0.5188,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N3', 226.4),
            ('N1/N1~', 119.3),
            ('N1', 119.3)
        ],
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : 'H_SR1',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.003459977,
        'r_expected' : 0.00379277,
        'Width (GeV)' : [
            ('C1+/C1-', 0.030109),
            ('N3', 0.0084547),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002413845,
        'l_max' : 0.0002466202,
        'l_SM' : 0.0002410039
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg',
        'r' : 3.301564,
        'r_expected' : 3.783604,
        'likelihood' : 9.47671314458971e-57,
        'l_max' : 9.340487256773573e-49,
        'l_SM' : 8.728843125789961e-49
    }
],
'Total xsec for missing topologies (fb)' : 115.0116,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 61.51796,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 53.49359,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 115.0116,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 61.51796,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 53.49359,
        'SMS' : 'PV > (MET), (Z,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}
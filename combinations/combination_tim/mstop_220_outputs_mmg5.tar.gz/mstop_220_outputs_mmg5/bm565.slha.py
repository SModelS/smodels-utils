smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2017-03,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm565.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.590184,
        'upper limit (fb)' : 1.289347,
        'expected upper limit (fb)' : 1.79685,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 1.233325,
        'r_expected' : 0.8849841,
        'Width (GeV)' : None,
        'likelihood' : 2.005678535809993e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.262031,
        'upper limit (fb)' : 1.309336,
        'expected upper limit (fb)' : 1.538938,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.9638714,
        'r_expected' : 0.8200665,
        'Width (GeV)' : None,
        'likelihood' : 3.913372e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.082991,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.8022153,
        'r_expected' : 1.061756,
        'Width (GeV)' : None,
        'likelihood' : 0.001120954,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1276479,
        'upper limit (fb)' : 0.3096883,
        'expected upper limit (fb)' : 0.3271604,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 186.6),
            ('C1+', 186.6),
            ('N1~', 54.0),
            ('N1', 54.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.412182,
        'r_expected' : 0.3901693,
        'Width (GeV)' : [
            ('C1-', 0.0852090443),
            ('C1+', 0.0852090443),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.109319e-40,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4700351,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.2,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.6),
            ('su_L', 220.6),
            ('C1-', 186.6),
            ('C1+', 186.6),
            ('N1~', 54.0),
            ('N1', 54.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_1bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.3481742,
        'r_expected' : 0.3916959,
        'Width (GeV)' : [
            ('su_L~', 0.273446539),
            ('su_L', 0.273446539),
            ('C1-', 0.0852090443),
            ('C1+', 0.0852090443),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002154407,
        'l_max' : 0.002394811,
        'l_SM' : 0.002264688
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01018416,
        'upper limit (fb)' : 0.0756,
        'expected upper limit (fb)' : 0.0842,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 186.6),
            ('N2/N3', 193.94),
            ('N1/N1~', 54.0),
            ('N1', 54.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SRLow2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1347111,
        'r_expected' : 0.120952,
        'Width (GeV)' : [
            ('C1+/C1-', 0.085209),
            ('N2/N3', 0.058166),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01236256,
        'l_max' : 0.01363736,
        'l_SM' : 0.01363736
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0771127,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 186.6),
            ('C1+', 186.6),
            ('N1~', 54.0),
            ('N1', 54.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1343427,
        'r_expected' : 0.1193695,
        'Width (GeV)' : [
            ('C1-', 0.0852090443),
            ('C1+', 0.0852090443),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.007610002,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01300046,
        'upper limit (fb)' : 0.1241549,
        'expected upper limit (fb)' : 0.1055177,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1047116,
        'r_expected' : 0.1232064,
        'Width (GeV)' : None,
        'likelihood' : 5.387168049856156e-45,
        'l_max' : 5.4471259255663993e-45,
        'l_SM' : 5.438917259567711e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0254869,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 186.6),
            ('N2/N3', 193.93),
            ('N1/N1~', 54.0),
            ('N1', 54.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.0606831,
        'r_expected' : 0.1341416,
        'Width (GeV)' : [
            ('C1+/C1-', 0.085209),
            ('N2/N3', 0.058174),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002267551,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03636908,
        'upper limit (fb)' : 0.9583416,
        'expected upper limit (fb)' : 0.4922401,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.03795002,
        'r_expected' : 0.07388483,
        'Width (GeV)' : None,
        'likelihood' : 0.2047625,
        'l_max' : 0.782548,
        'l_SM' : 0.1570112
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01402846,
        'upper limit (fb)' : 0.43,
        'expected upper limit (fb)' : 0.329,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 186.6),
            ('N2/N3', 193.94),
            ('N1/N1~', 54.0),
            ('N1', 54.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'SR2-low',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.03262432,
        'r_expected' : 0.04263969,
        'Width (GeV)' : [
            ('C1+/C1-', 0.085209),
            ('N2/N3', 0.058165),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.005383911,
        'l_max' : 0.01400734,
        'l_SM' : 0.004554925
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.007649058,
        'upper limit (fb)' : 0.256,
        'expected upper limit (fb)' : 0.33,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N2/N3', 194.36),
            ('C1+/C1-', 186.6),
            ('N1', 54.0),
            ('N1/N1~', 54.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-12',
        'DataSetID' : 'SR2tau_b',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.02987913,
        'r_expected' : 0.02317896,
        'Width (GeV)' : [
            ('N2/N3', 0.052216),
            ('C1+/C1-', 0.085209),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.05898192,
        'l_max' : 0.06174326,
        'l_SM' : 0.06174326
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.000246923,
        'upper limit (fb)' : 0.2033425,
        'expected upper limit (fb)' : 0.1528364,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 194.4), ('N2', 193.7), ('N1', 54.0)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.001214321,
        'r_expected' : 0.001615603,
        'Width (GeV)' : [
            ('N3', 0.051708826),
            ('N2', 0.0614305704),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6176480000000003e-34,
        'l_max' : 1.8955360000000004e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2017-03,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.407627,
        'r_expected' : 1.641636,
        'likelihood' : 4.995006600014986e-168,
        'l_max' : 1.9876614714736743e-166,
        'l_SM' : 1.8138219840811905e-166
    }
],
'Total xsec for missing topologies (fb)' : 1286.978,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1094.482,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 112.7481,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 45.54262,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30.24949,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.956525,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1286.978,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1094.482,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 112.7481,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 45.54262,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30.24949,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.956525,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 92.39295,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 92.39295,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
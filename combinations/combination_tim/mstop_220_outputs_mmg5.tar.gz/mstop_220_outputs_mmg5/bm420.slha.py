smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm420.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.132219,
        'upper limit (fb)' : 1.499868,
        'expected upper limit (fb)' : 1.708583,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.7548788,
        'r_expected' : 0.6626654,
        'Width (GeV)' : None,
        'likelihood' : 1.189130419539362e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9888416,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.7324752,
        'r_expected' : 0.9694525,
        'Width (GeV)' : None,
        'likelihood' : 0.001489925,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.065778,
        'upper limit (fb)' : 1.69653,
        'expected upper limit (fb)' : 1.461665,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6282107,
        'r_expected' : 0.7291537,
        'Width (GeV)' : None,
        'likelihood' : 1.9154910000000004e-20,
        'l_max' : 3.1268470000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1498318,
        'upper limit (fb)' : 0.3454308,
        'expected upper limit (fb)' : 0.2552033,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4337535,
        'r_expected' : 0.5871075,
        'Width (GeV)' : None,
        'likelihood' : 1.6885150000000003e-24,
        'l_max' : 1.768446e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1068904,
        'upper limit (fb)' : 0.2982146,
        'expected upper limit (fb)' : 0.3415297,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 87.3),
            ('N1', 87.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3584344,
        'r_expected' : 0.3129753,
        'Width (GeV)' : [
            ('C1-', 0.0737301573),
            ('C1+', 0.0737301573),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.0915e-40,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2475665,
        'upper limit (fb)' : 0.974,
        'expected upper limit (fb)' : 0.765,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.1),
            ('su_L', 220.1),
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 87.3),
            ('N1', 87.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_0bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.2541751,
        'r_expected' : 0.3236164,
        'Width (GeV)' : [
            ('su_L~', 0.0448320248),
            ('su_L', 0.0448320248),
            ('C1-', 0.0737301573),
            ('C1+', 0.0737301573),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.006278022,
        'l_max' : 0.006278059,
        'l_SM' : 0.004973309
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01429171,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.127,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 214.2),
            ('N1/N1~', 87.3),
            ('N1', 87.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.1587968,
        'r_expected' : 0.1125331,
        'Width (GeV)' : [
            ('C1+/C1-', 0.07373),
            ('N2/N3', 0.044779),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1504104,
        'l_max' : 0.2014847,
        'l_SM' : 0.2014847
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.007146324,
        'upper limit (fb)' : 0.05742721,
        'expected upper limit (fb)' : 0.06031279,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2', 213.3),
            ('N1/N1~', 87.3),
            ('N1', 87.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1244414,
        'r_expected' : 0.1184877,
        'Width (GeV)' : [
            ('C1+/C1-', 0.07373),
            ('N2', 0.052523),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 8.744576e-11,
        'l_max' : 9.107398e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0257592,
        'upper limit (fb)' : 0.3583478,
        'expected upper limit (fb)' : 0.5516621,
        'TxNames' : ['TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.07188323,
        'r_expected' : 0.04669379,
        'Width (GeV)' : None,
        'likelihood' : 9.589804174735975e-82,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02790907,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 214.2),
            ('N1/N1~', 87.3),
            ('N1', 87.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.06645016,
        'r_expected' : 0.1468898,
        'Width (GeV)' : [
            ('C1+/C1-', 0.07373),
            ('N2/N3', 0.044792),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002482231,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03100253,
        'upper limit (fb)' : 0.531,
        'expected upper limit (fb)' : 0.438,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 87.3),
            ('N1', 87.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWc-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.05838517,
        'r_expected' : 0.07078203,
        'Width (GeV)' : [
            ('C1-', 0.0737301573),
            ('C1+', 0.0737301573),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.02035167,
        'l_max' : 0.02164771,
        'l_SM' : 0.01893459
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg',
        'r' : 1.031139,
        'r_expected' : 1.478241,
        'likelihood' : 2.887586930288447e-99,
        'l_max' : 1.5361216193568828e-98,
        'l_SM' : 7.815615673197284e-99
    }
],
'Total xsec for missing topologies (fb)' : 1029.182,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 933.8871,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 68.06757,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 26.00216,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.224817,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1029.182,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 933.8871,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 68.06757,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 26.00216,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.224817,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 184.9472,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 122.4817,
        'SMS' : 'PV > (higgs,MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 62.46554,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
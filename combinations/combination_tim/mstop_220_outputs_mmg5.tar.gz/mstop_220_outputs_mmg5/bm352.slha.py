smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm352.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.054297,
        'upper limit (fb)' : 1.388552,
        'expected upper limit (fb)' : 1.659717,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.7592777,
        'r_expected' : 0.6352266,
        'Width (GeV)' : None,
        'likelihood' : 1.1059587910937172e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9095672,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.6737535,
        'r_expected' : 0.8917325,
        'Width (GeV)' : None,
        'likelihood' : 0.001842254,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9684043,
        'upper limit (fb)' : 1.462777,
        'expected upper limit (fb)' : 1.419642,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6620312,
        'r_expected' : 0.6821466,
        'Width (GeV)' : None,
        'likelihood' : 1.3146430000000002e-20,
        'l_max' : 2.7876200000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1690165,
        'upper limit (fb)' : 0.3525756,
        'expected upper limit (fb)' : 0.3026132,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4793765,
        'r_expected' : 0.5585231,
        'Width (GeV)' : None,
        'likelihood' : 1.07272e-24,
        'l_max' : 1.338204e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1286145,
        'upper limit (fb)' : 0.2847686,
        'expected upper limit (fb)' : 0.329765,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 78.2),
            ('N1', 78.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4516455,
        'r_expected' : 0.3900185,
        'Width (GeV)' : [
            ('C1-', 0.0864551285),
            ('C1+', 0.0864551285),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 8.978540234460836e-41,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04438489,
        'upper limit (fb)' : 0.35,
        'expected upper limit (fb)' : 0.383,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.89),
            ('N1/N1~', 78.2),
            ('N1', 78.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-0Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.126814,
        'r_expected' : 0.1158875,
        'Width (GeV)' : [
            ('C1+/C1-', 0.086455),
            ('N2/N3', 0.060596),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0109364,
        'l_max' : 0.01183074,
        'l_SM' : 0.01183074
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03210484,
        'upper limit (fb)' : 0.3871355,
        'expected upper limit (fb)' : 0.6983633,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.08292921,
        'r_expected' : 0.04597155,
        'Width (GeV)' : None,
        'likelihood' : 9.243933008963933e-82,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.034912,
        'upper limit (fb)' : 0.531,
        'expected upper limit (fb)' : 0.438,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 78.2),
            ('N1', 78.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWc-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.06574764,
        'r_expected' : 0.07970776,
        'Width (GeV)' : [
            ('C1-', 0.0864551285),
            ('C1+', 0.0864551285),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.02049607,
        'l_max' : 0.02164771,
        'l_SM' : 0.01893459
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02229899,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.89),
            ('N1/N1~', 78.2),
            ('N1', 78.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.05309283,
        'r_expected' : 0.1173631,
        'Width (GeV)' : [
            ('C1+/C1-', 0.086455),
            ('N2/N3', 0.060613),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002006972,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.003659494,
        'upper limit (fb)' : 0.133,
        'expected upper limit (fb)' : 0.0729,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N3', 214.9),
            ('C1+/C1-', 206.8),
            ('N1', 78.2),
            ('N1/N1~', 78.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : 'SR_LM_Low_MCT',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.027515,
        'r_expected' : 0.05019883,
        'Width (GeV)' : [
            ('N3', 0.05307),
            ('C1+/C1-', 0.086455),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.004874942,
        'l_max' : 0.01413645,
        'l_SM' : 0.004073156
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0007338669,
        'upper limit (fb)' : 0.089,
        'expected upper limit (fb)' : 0.0662,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.89),
            ('N1/N1~', 78.2),
            ('N1', 78.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SROffShell_2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.008245695,
        'r_expected' : 0.0110856,
        'Width (GeV)' : [
            ('C1+/C1-', 0.086455),
            ('N2/N3', 0.060585),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01822138,
        'l_max' : 0.02150842,
        'l_SM' : 0.01795068
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.415907e-05,
        'upper limit (fb)' : 0.03363027,
        'expected upper limit (fb)' : 0.04549886,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 214.9), ('N2', 213.4), ('N1', 78.2)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.0007183729,
        'r_expected' : 0.000530982,
        'Width (GeV)' : [
            ('N3', 0.053069831),
            ('N2', 0.0642452961),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6124440000000004e-34,
        'l_max' : 1.6144670000000003e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg',
        'r' : 1.126784,
        'r_expected' : 1.397485,
        'likelihood' : 2.3326482864099767e-87,
        'l_max' : 2.1097414626259656e-86,
        'l_SM' : 1.7255338561943313e-86
    }
],
'Total xsec for missing topologies (fb)' : 1026.263,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 930.9869,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 65.33242,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 26.88003,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.722184,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.341799,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1026.263,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 930.9869,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 65.33242,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 26.88003,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.722184,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.341799,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 80.35036,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 80.35036,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,ATLAS-SUSY-2019-09,ATLAS-SUSY-2018-16',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm151.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.083647,
        'upper limit (fb)' : 2.88,
        'expected upper limit (fb)' : 2.01,
        'TxNames' : ['T1bbbb', 'T6bbWWoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.3762662,
        'r_expected' : 0.5391277,
        'Width (GeV)' : None,
        'likelihood' : 0.0009170689,
        'l_max' : 0.0009521956,
        'l_SM' : 0.0006572509
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04627057,
        'upper limit (fb)' : 0.1422559,
        'expected upper limit (fb)' : 0.1344507,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 192.3),
            ('C1+/C1-', 186.7),
            ('N1', 166.1),
            ('N1/N1~', 166.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3252629,
        'r_expected' : 0.3441453,
        'Width (GeV)' : [
            ('N2', 7.7592e-06),
            ('C1+/C1-', 2.9941e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 3.7651920000000004e-38,
        'l_max' : 4.4922490000000003e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07671556,
        'upper limit (fb)' : 0.3405618,
        'expected upper limit (fb)' : 0.4071259,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2252618,
        'r_expected' : 0.188432,
        'Width (GeV)' : None,
        'likelihood' : 0.08652114,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01145163,
        'upper limit (fb)' : 1.243782,
        'expected upper limit (fb)' : 0.9713387,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 192.3),
            ('C1+/C1-', 186.7),
            ('N1', 166.1),
            ('N1/N1~', 166.1)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0092071,
        'r_expected' : 0.01178953,
        'Width (GeV)' : [
            ('N2', 7.7592e-06),
            ('C1+/C1-', 2.9941e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.324723747019931e-72,
        'l_max' : 5.519206074963472e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00933126,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 186.7),
            ('C1+', 186.7),
            ('N1~', 166.1),
            ('N1', 166.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.00430012,
        'r_expected' : 0.004422398,
        'Width (GeV)' : [
            ('C1-', 2.9941e-06),
            ('C1+', 2.9941e-06),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002989664,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0001919139,
        'upper limit (fb)' : 0.4667749,
        'expected upper limit (fb)' : 0.4409557,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 192.3),
            ('C1+/C1-', 186.7),
            ('N1', 166.1),
            ('N1/N1~', 166.1)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0004111487,
        'r_expected' : 0.0004352226,
        'Width (GeV)' : [
            ('N2', 7.7592e-06),
            ('C1+/C1-', 2.9941e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.7608870000000004e-20,
        'l_max' : 2.845749e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.74845e-06,
        'upper limit (fb)' : 0.43344,
        'expected upper limit (fb)' : 0.33172,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('N3', 251.1),
            ('C1+/C1-', 186.7),
            ('inv', 192.3),
            ('N1/N1~', 166.1)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR3j',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 1.787664e-05,
        'r_expected' : 2.335841e-05,
        'Width (GeV)' : [
            ('N3', 0.00086484),
            ('C1+/C1-', 2.9941e-06),
            ('inv', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.03774301,
        'l_max' : 0.04953626,
        'l_SM' : 0.03774128
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.5810131,
        'r_expected' : 0.7330348,
        'likelihood' : 2.987523277567934e-42,
        'l_max' : 4.0815567354043486e-42,
        'l_SM' : 3.343232255508956e-42
    }
],
'Total xsec for missing topologies (fb)' : 8389.011,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3600.501,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1253.102,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1210.76,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 505.2475,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 374.2253,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 292.4623,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 169.9023,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 169.9023,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 136.2137,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 92.90138,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 8389.011,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3600.501,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1253.102,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1210.76,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 505.2475,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 374.2253,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 292.4623,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 169.9023,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 169.9023,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 136.2137,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 92.90138,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7631.189,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7452.83,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 135.3389,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 32.19883,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.622442,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.836356,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2912253,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04492737,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02580495,
        'SMS' : 'PV > (MET), (l,l,MET)'
    }
]
}
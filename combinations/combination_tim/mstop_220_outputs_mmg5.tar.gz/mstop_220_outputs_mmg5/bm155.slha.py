smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-16-039-agg',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm155.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8102001,
        'upper limit (fb)' : 1.328679,
        'expected upper limit (fb)' : 1.610393,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6097785,
        'r_expected' : 0.5031072,
        'Width (GeV)' : None,
        'likelihood' : 1.6098920076666662e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1525276,
        'upper limit (fb)' : 0.2800285,
        'expected upper limit (fb)' : 0.3246143,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 78.6),
            ('N1', 78.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.5446861,
        'r_expected' : 0.4698733,
        'Width (GeV)' : [
            ('C1-', 0.0976803263),
            ('C1+', 0.0976803263),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 7.318041333045019e-41,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.7472778,
        'upper limit (fb)' : 1.484688,
        'expected upper limit (fb)' : 1.431157,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.5033231,
        'r_expected' : 0.5221494,
        'Width (GeV)' : None,
        'likelihood' : 1.8910810000000002e-20,
        'l_max' : 2.7994220000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1279201,
        'upper limit (fb)' : 0.343064,
        'expected upper limit (fb)' : 0.296909,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3728752,
        'r_expected' : 0.4308393,
        'Width (GeV)' : None,
        'likelihood' : 1.203834e-24,
        'l_max' : 1.3256150000000001e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0336618,
        'upper limit (fb)' : 0.3204888,
        'expected upper limit (fb)' : 0.5916391,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.1050327,
        'r_expected' : 0.05689583,
        'Width (GeV)' : None,
        'likelihood' : 8.861001658037324e-82,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03551674,
        'upper limit (fb)' : 0.35,
        'expected upper limit (fb)' : 0.383,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2/N3', 221.75),
            ('N1/N1~', 78.6),
            ('N1', 78.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-0Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.1014764,
        'r_expected' : 0.092733,
        'Width (GeV)' : [
            ('C1+/C1-', 0.09768),
            ('N2/N3', 0.072197),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01118126,
        'l_max' : 0.01183074,
        'l_SM' : 0.01183074
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03699123,
        'upper limit (fb)' : 0.531,
        'expected upper limit (fb)' : 0.438,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 78.6),
            ('N1', 78.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWc-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.06966333,
        'r_expected' : 0.08445486,
        'Width (GeV)' : [
            ('C1-', 0.0976803263),
            ('C1+', 0.0976803263),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.02056956,
        'l_max' : 0.02164771,
        'l_SM' : 0.01893459
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01672521,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2/N3', 221.75),
            ('N1/N1~', 78.6),
            ('N1', 78.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.03982192,
        'r_expected' : 0.0880274,
        'Width (GeV)' : [
            ('C1+/C1-', 0.09768),
            ('N2/N3', 0.072207),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001607595,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001110538,
        'upper limit (fb)' : 0.03738627,
        'expected upper limit (fb)' : 0.03126687,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.02970444,
        'r_expected' : 0.03551805,
        'Width (GeV)' : None,
        'likelihood' : 5.498253823830255e-45,
        'l_max' : 5.5408612752860855e-45,
        'l_SM' : 5.438917259567711e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.053712,
        'upper limit (fb)' : 3.55,
        'expected upper limit (fb)' : 4.74,
        'TxNames' : ['TChiWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.01513014,
        'r_expected' : 0.01133165,
        'Width (GeV)' : None,
        'likelihood' : 0.0001906638,
        'l_max' : 0.0001933524,
        'l_SM' : 0.0001933524
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0007663411,
        'upper limit (fb)' : 0.06606624,
        'expected upper limit (fb)' : 0.06407253,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.01159959,
        'r_expected' : 0.01196052,
        'Width (GeV)' : None,
        'likelihood' : 9.124661e-11,
        'l_max' : 9.139509e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0004545579,
        'upper limit (fb)' : 0.2291517,
        'expected upper limit (fb)' : 0.1744815,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 222.4), ('N2', 221.4), ('N1', 78.6)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.001983655,
        'r_expected' : 0.002605192,
        'Width (GeV)' : [
            ('N3', 0.0657601564),
            ('N2', 0.0756357998),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6213920000000003e-34,
        'l_max' : 2.0566080000000005e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-16-039-agg',
        'r' : 0.8190008,
        'r_expected' : 0.839378,
        'likelihood' : 1.6659874567625524e-84,
        'l_max' : 5.731521035442174e-84,
        'l_SM' : 5.715056292132331e-84
    }
],
'Total xsec for missing topologies (fb)' : 1018.756,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 919.2998,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 53.76022,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 41.88919,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.688011,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.118976,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1018.756,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 919.2998,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 53.76022,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 41.88919,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.688011,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.118976,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 25241.88,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 25170.53,
        'SMS' : 'PV > (W,b,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 71.34652,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
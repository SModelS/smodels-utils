smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm413.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.211128,
        'upper limit (fb)' : 1.469483,
        'expected upper limit (fb)' : 1.679974,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8241863,
        'r_expected' : 0.7209203,
        'Width (GeV)' : None,
        'likelihood' : 9.616782739846648e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.176848,
        'upper limit (fb)' : 1.620872,
        'expected upper limit (fb)' : 1.427648,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.7260587,
        'r_expected' : 0.8243266,
        'Width (GeV)' : None,
        'likelihood' : 1.3915460000000002e-20,
        'l_max' : 3.0172630000000004e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9580154,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.709641,
        'r_expected' : 0.9392308,
        'Width (GeV)' : None,
        'likelihood' : 0.00162298,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1585543,
        'upper limit (fb)' : 0.3520873,
        'expected upper limit (fb)' : 0.2622396,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4503266,
        'r_expected' : 0.6046161,
        'Width (GeV)' : None,
        'likelihood' : 1.6161660000000002e-24,
        'l_max' : 1.7238970000000002e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2782211,
        'upper limit (fb)' : 0.974,
        'expected upper limit (fb)' : 0.765,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.9),
            ('su_L', 220.9),
            ('C1-', 201.7),
            ('C1+', 201.7),
            ('N1~', 82.4),
            ('N1', 82.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_0bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.2856479,
        'r_expected' : 0.3636877,
        'Width (GeV)' : [
            ('su_L~', 0.0922488093),
            ('su_L', 0.0922488093),
            ('C1-', 0.0726625198),
            ('C1+', 0.0726625198),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.006254702,
        'l_max' : 0.006278059,
        'l_SM' : 0.004973309
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07536674,
        'upper limit (fb)' : 0.293065,
        'expected upper limit (fb)' : 0.3352243,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 201.7),
            ('C1+', 201.7),
            ('N1~', 82.4),
            ('N1', 82.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2571673,
        'r_expected' : 0.2248248,
        'Width (GeV)' : [
            ('C1-', 0.0726625198),
            ('C1+', 0.0726625198),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.291358e-40,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01444422,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.127,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.7),
            ('N2/N3', 209.18),
            ('N1/N1~', 82.4),
            ('N1', 82.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.1604913,
        'r_expected' : 0.113734,
        'Width (GeV)' : [
            ('C1+/C1-', 0.072663),
            ('N2/N3', 0.043746),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1499058,
        'l_max' : 0.2014847,
        'l_SM' : 0.2014847
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.007639249,
        'upper limit (fb)' : 0.05713959,
        'expected upper limit (fb)' : 0.06011812,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.7),
            ('N2', 208.3),
            ('N1/N1~', 82.4),
            ('N1', 82.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1336945,
        'r_expected' : 0.1270707,
        'Width (GeV)' : [
            ('C1+/C1-', 0.072663),
            ('N2', 0.051193),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 8.684477e-11,
        'l_max' : 9.107396e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02825848,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.7),
            ('N2/N3', 209.18),
            ('N1/N1~', 82.4),
            ('N1', 82.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.06728211,
        'r_expected' : 0.1487289,
        'Width (GeV)' : [
            ('C1+/C1-', 0.072663),
            ('N2/N3', 0.043759),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002514429,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0224111,
        'upper limit (fb)' : 0.3777944,
        'expected upper limit (fb)' : 0.5550616,
        'TxNames' : ['TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.0593209,
        'r_expected' : 0.04037588,
        'Width (GeV)' : None,
        'likelihood' : 9.825692631060237e-82,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03141435,
        'upper limit (fb)' : 0.531,
        'expected upper limit (fb)' : 0.438,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 201.7),
            ('C1+', 201.7),
            ('N1~', 82.4),
            ('N1', 82.4)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWc-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.05916074,
        'r_expected' : 0.07172227,
        'Width (GeV)' : [
            ('C1-', 0.0726625198),
            ('C1+', 0.0726625198),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.02036726,
        'l_max' : 0.02164771,
        'l_SM' : 0.01893459
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg',
        'r' : 1.050789,
        'r_expected' : 1.499316,
        'likelihood' : 2.5603160318160586e-99,
        'l_max' : 1.5209520129119493e-98,
        'l_SM' : 7.815615673197284e-99
    }
],
'Total xsec for missing topologies (fb)' : 1111.143,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 968.5512,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 80.7126,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 58.06655,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.69042,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.122576,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1111.143,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 968.5512,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 80.7126,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 58.06655,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.69042,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.122576,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 161.6508,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 111.135,
        'SMS' : 'PV > (higgs,MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 50.51582,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm73.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06565415,
        'upper limit (fb)' : 0.1773152,
        'expected upper limit (fb)' : 0.170936,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 207.4),
            ('C1+/C1-', 201.8),
            ('N1', 172.2),
            ('N1/N1~', 172.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.370268,
        'r_expected' : 0.3840862,
        'Width (GeV)' : [
            ('N2', 2.6975e-05),
            ('C1+/C1-', 1.4293e-05),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 3.1705660000000004e-38,
        'l_max' : 4.4270760000000007e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8518777,
        'upper limit (fb)' : 2.88,
        'expected upper limit (fb)' : 2.01,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 172.2),
            ('N1', 172.2)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.2957909,
        'r_expected' : 0.4238198,
        'Width (GeV)' : [
            ('su_L~', 0.085939),
            ('su_L', 0.085939),
            ('C1-', 1.4293e-05),
            ('C1+', 1.4293e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0009516856,
        'l_max' : 0.0009521956,
        'l_SM' : 0.0006572509
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04532709,
        'upper limit (fb)' : 0.3899511,
        'expected upper limit (fb)' : 0.8238705,
        'TxNames' : ['TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1162379,
        'r_expected' : 0.05501724,
        'Width (GeV)' : None,
        'likelihood' : 3.378449430443546e-123,
        'l_max' : 4.5339218568111875e-123,
        'l_SM' : 4.533919658110445e-123
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0249238,
        'upper limit (fb)' : 0.3639713,
        'expected upper limit (fb)' : 0.6236678,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.8),
            ('N2', 207.4),
            ('N1/N1~', 172.2),
            ('N1', 172.2)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.06847738,
        'r_expected' : 0.03996326,
        'Width (GeV)' : [
            ('C1+/C1-', 1.4293e-05),
            ('N2', 2.6975e-05),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 9.303040000000002e-33,
        'l_max' : 1.0786820000000003e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001685808,
        'upper limit (fb)' : 0.03354081,
        'expected upper limit (fb)' : 0.05014136,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-41',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.05026142,
        'r_expected' : 0.03362112,
        'Width (GeV)' : None,
        'likelihood' : 0.002163588,
        'l_max' : 0.002358157,
        'l_SM' : 0.002358157
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.006919275,
        'upper limit (fb)' : 0.2976714,
        'expected upper limit (fb)' : 0.1811966,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.02324468,
        'r_expected' : 0.03818657,
        'Width (GeV)' : None,
        'likelihood' : 1.1480736216785482e-81,
        'l_max' : 1.8495206192308238e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02016512,
        'upper limit (fb)' : 1.240822,
        'expected upper limit (fb)' : 0.9733688,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01625142,
        'r_expected' : 0.02071683,
        'Width (GeV)' : None,
        'likelihood' : 4.3511980959627315e-72,
        'l_max' : 5.012951678137894e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.004227076,
        'upper limit (fb)' : 0.50301,
        'expected upper limit (fb)' : 0.88617,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-/N2', 204.94),
            ('C1+/C1-', 201.8),
            ('N1/N1~', 172.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.008403563,
        'r_expected' : 0.004770051,
        'Width (GeV)' : [
            ('C1-/N2', 2.1407e-05),
            ('C1+/C1-', 1.4293e-05),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.001410317,
        'l_max' : 0.001434466,
        'l_SM' : 0.001434466
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0005845387,
        'upper limit (fb)' : 0.07711246,
        'expected upper limit (fb)' : 0.04213844,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.007580341,
        'r_expected' : 0.01387186,
        'Width (GeV)' : None,
        'likelihood' : 5.591495861467279e-45,
        'l_max' : 6.203837268784377e-45,
        'l_SM' : 5.438917259567711e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01061249,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 172.2),
            ('N1', 172.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.004890548,
        'r_expected' : 0.005029616,
        'Width (GeV)' : [
            ('C1-', 1.4293e-05),
            ('C1+', 1.4293e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002989838,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0002893134,
        'upper limit (fb)' : 0.564658,
        'expected upper limit (fb)' : 0.8182284,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.0005123693,
        'r_expected' : 0.0003535852,
        'Width (GeV)' : None,
        'likelihood' : 2.7583550000000006e-20,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 9.61038265361246e-07,
        'theory prediction (fb)' : 0.0001219735,
        'upper limit (fb)' : 0.813,
        'expected upper limit (fb)' : 1.19,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 172.2),
            ('N1', 172.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-SF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.000150029,
        'r_expected' : 0.0001024988,
        'Width (GeV)' : [
            ('C1-', 1.4293e-05),
            ('C1+', 1.4293e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001267279,
        'l_max' : 0.001267591,
        'l_SM' : 0.001267591
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.4698573,
        'r_expected' : 0.6077557,
        'likelihood' : 3.017381912708758e-41,
        'l_max' : 3.48865316685745e-41,
        'l_SM' : 2.909700075502617e-41
    }
],
'Total xsec for missing topologies (fb)' : 8177.011,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3693.214,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1255.398,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1235.971,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 431.4008,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 304.2114,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 254.4667,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 144.3726,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 144.3726,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 105.8002,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 71.06929,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 8177.011,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3693.214,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1255.398,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1235.971,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 431.4008,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 304.2114,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 254.4667,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 144.3726,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 144.3726,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 105.8002,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 71.06929,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7531.108,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7502.524,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 27.13103,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.093435,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2422847,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04658695,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02743845,
        'SMS' : 'PV > (b,b,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02293302,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0199083,
        'SMS' : 'PV > (MET), (l,l,MET)'
    }
]
}
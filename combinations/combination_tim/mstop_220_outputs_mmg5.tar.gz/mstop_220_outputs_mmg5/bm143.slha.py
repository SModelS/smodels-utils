smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,ATLAS-SUSY-2019-09,ATLAS-SUSY-2018-16',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm143.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.724344,
        'upper limit (fb)' : 9.5,
        'expected upper limit (fb)' : 7.42,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.4),
            ('su_L', 220.4),
            ('C1-', 214.9),
            ('C1+', 214.9),
            ('N1~', 202.6),
            ('N1', 202.6)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_500HT800_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.4972994,
        'r_expected' : 0.6367041,
        'Width (GeV)' : [
            ('su_L~', 0.0055179),
            ('su_L', 0.0055179),
            ('C1-', 2.716e-07),
            ('C1+', 2.716e-07),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 8.157702e-05,
        'l_max' : 0.0001131536,
        'l_SM' : 9.888565e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01650041,
        'upper limit (fb)' : 0.0499149,
        'expected upper limit (fb)' : 0.06068002,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 220.1),
            ('C1+/C1-', 214.9),
            ('N1', 202.6),
            ('N1/N1~', 202.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3305708,
        'r_expected' : 0.2719249,
        'Width (GeV)' : [
            ('N2', 1.2647e-06),
            ('C1+/C1-', 2.716e-07),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.69768e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05345727,
        'upper limit (fb)' : 0.3191859,
        'expected upper limit (fb)' : 0.3817654,
        'TxNames' : ['TChiWWoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1674801,
        'r_expected' : 0.1400265,
        'Width (GeV)' : None,
        'likelihood' : 0.09449234,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01970074,
        'upper limit (fb)' : 0.3277902,
        'expected upper limit (fb)' : 0.2783289,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.9),
            ('N2', 220.1),
            ('N1/N1~', 202.6),
            ('N1', 202.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.06010167,
        'r_expected' : 0.07078222,
        'Width (GeV)' : [
            ('C1+/C1-', 2.716e-07),
            ('N2', 1.2647e-06),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.1293700000000003e-32,
        'l_max' : 1.1509440000000002e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.004176484,
        'upper limit (fb)' : 2.23,
        'expected upper limit (fb)' : 1.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.9),
            ('C1+', 214.9),
            ('N1~', 202.6),
            ('N1', 202.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '2j_Meff_2100',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.001872863,
        'r_expected' : 0.003762598,
        'Width (GeV)' : [
            ('C1-', 2.716e-07),
            ('C1+', 2.716e-07),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0001343929,
        'l_max' : 0.000824375,
        'l_SM' : 0.0001323789
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.7458941,
        'r_expected' : 0.7984897,
        'likelihood' : 2.07948026786459e-43,
        'l_max' : 5.03000722489341e-43,
        'l_SM' : 5.03000722489341e-43
    }
],
'Total xsec for missing topologies (fb)' : 7614.017,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3454.897,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1305.513,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1181.252,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 392.7704,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 267.2045,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 223.729,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 134.2907,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 134.2907,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 94.74648,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 60.75435,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 7614.017,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3454.897,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1305.513,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1181.252,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 392.7704,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 267.2045,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 223.729,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 134.2907,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 134.2907,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 94.74648,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 60.75435,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7752.197,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7636.666,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 93.81945,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 16.35475,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.356733,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    }
]
}
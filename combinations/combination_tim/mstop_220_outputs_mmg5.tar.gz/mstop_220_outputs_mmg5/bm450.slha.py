smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm450.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.277798,
        'upper limit (fb)' : 1.523824,
        'expected upper limit (fb)' : 1.662951,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8385471,
        'r_expected' : 0.768392,
        'Width (GeV)' : None,
        'likelihood' : 9.505807474684418e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.025125,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.7593516,
        'r_expected' : 1.005024,
        'Width (GeV)' : None,
        'likelihood' : 0.001340715,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.078738,
        'upper limit (fb)' : 1.975216,
        'expected upper limit (fb)' : 1.461284,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.5461367,
        'r_expected' : 0.7382124,
        'Width (GeV)' : None,
        'likelihood' : 3.8438280000000006e-20,
        'l_max' : 4.5071440000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1761979,
        'upper limit (fb)' : 0.3817415,
        'expected upper limit (fb)' : 0.2790004,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4615633,
        'r_expected' : 0.6315326,
        'Width (GeV)' : None,
        'likelihood' : 1.7667220000000004e-24,
        'l_max' : 1.8642690000000003e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01908908,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.127,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.7),
            ('N2/N3', 210.13),
            ('N1/N1~', 95.9),
            ('N1', 95.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.2121009,
        'r_expected' : 0.1503077,
        'Width (GeV)' : [
            ('C1+/C1-', 0.050093),
            ('N2/N3', 0.022074),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1350481,
        'l_max' : 0.2014847,
        'l_SM' : 0.2014847
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1936669,
        'upper limit (fb)' : 0.974,
        'expected upper limit (fb)' : 0.765,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('C1-', 201.7),
            ('C1+', 201.7),
            ('N1~', 95.9),
            ('N1', 95.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_0bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1988366,
        'r_expected' : 0.2531593,
        'Width (GeV)' : [
            ('su_L~', 0.0867509534),
            ('su_L', 0.0867509534),
            ('C1-', 0.0500930926),
            ('C1+', 0.0500930926),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.006213801,
        'l_max' : 0.006278059,
        'l_SM' : 0.004973309
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.008132037,
        'upper limit (fb)' : 0.05614225,
        'expected upper limit (fb)' : 0.0593741,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.7),
            ('N2', 208.2),
            ('N1/N1~', 95.9),
            ('N1', 95.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.144847,
        'r_expected' : 0.1369627,
        'Width (GeV)' : [
            ('C1+/C1-', 0.050093),
            ('N2', 0.031256),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 8.588661e-11,
        'l_max' : 9.107397e-11,
        'l_SM' : 9.107398e-11
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04752417,
        'upper limit (fb)' : 0.3343399,
        'expected upper limit (fb)' : 0.3626202,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 201.7),
            ('C1+', 201.7),
            ('N1~', 95.9),
            ('N1', 95.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1421433,
        'r_expected' : 0.1310577,
        'Width (GeV)' : [
            ('C1-', 0.0500930926),
            ('C1+', 0.0500930926),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.561368e-40,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03799913,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.7),
            ('N2/N3', 210.11),
            ('N1/N1~', 95.9),
            ('N1', 95.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.09047412,
        'r_expected' : 0.1999954,
        'Width (GeV)' : [
            ('C1+/C1-', 0.050093),
            ('N2/N3', 0.022133),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003544535,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02423534,
        'upper limit (fb)' : 0.518,
        'expected upper limit (fb)' : 0.555,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 201.7),
            ('C1+', 201.7),
            ('N1~', 95.9),
            ('N1', 95.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWb-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.04678638,
        'r_expected' : 0.04366728,
        'Width (GeV)' : [
            ('C1-', 0.0500930926),
            ('C1+', 0.0500930926),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01402993,
        'l_max' : 0.01441039,
        'l_SM' : 0.01441039
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01455903,
        'upper limit (fb)' : 0.3704115,
        'expected upper limit (fb)' : 0.428954,
        'TxNames' : ['TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.03930502,
        'r_expected' : 0.03394078,
        'Width (GeV)' : None,
        'likelihood' : 1.0353654042490925e-81,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.122138,
        'r_expected' : 1.475546,
        'likelihood' : 1.876211251887453e-151,
        'l_max' : 1.8042907327738484e-150,
        'l_SM' : 1.2018261775526727e-150
    }
],
'Total xsec for missing topologies (fb)' : 1135.283,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 988.2853,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 92.56667,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 51.72837,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8820602,
        'SMS' : 'PV > (W,W,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4468,
        'SMS' : 'PV > (Z,W,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4404885,
        'SMS' : 'PV > (Z,higgs,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3027945,
        'SMS' : 'PV > (W,higgs,MET), (W,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1533779,
        'SMS' : 'PV > (W,higgs,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1512113,
        'SMS' : 'PV > (W,higgs,MET), (Z,higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1033712,
        'SMS' : 'PV > (Z,W,MET), (W,b,t,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1135.283,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 988.2853,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 92.56667,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 51.72837,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8820602,
        'SMS' : 'PV > (W,W,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4468,
        'SMS' : 'PV > (Z,W,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4404885,
        'SMS' : 'PV > (Z,higgs,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3027945,
        'SMS' : 'PV > (W,higgs,MET), (W,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1533779,
        'SMS' : 'PV > (W,higgs,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1512113,
        'SMS' : 'PV > (W,higgs,MET), (Z,higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1033712,
        'SMS' : 'PV > (Z,W,MET), (W,b,t,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}
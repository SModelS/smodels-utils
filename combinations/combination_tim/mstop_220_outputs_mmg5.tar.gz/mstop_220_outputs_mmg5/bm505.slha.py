smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm505.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.102668,
        'upper limit (fb)' : 1.279752,
        'expected upper limit (fb)' : 1.619878,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.861626,
        'r_expected' : 0.6807102,
        'Width (GeV)' : None,
        'likelihood' : 7.704412479067892e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8454878,
        'upper limit (fb)' : 1.018612,
        'expected upper limit (fb)' : 1.316056,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8300391,
        'r_expected' : 0.6424408,
        'Width (GeV)' : None,
        'likelihood' : 5.4422970000000005e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9565406,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.7085486,
        'r_expected' : 0.9377849,
        'Width (GeV)' : None,
        'likelihood' : 0.00162948,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1437744,
        'upper limit (fb)' : 0.284283,
        'expected upper limit (fb)' : 0.324278,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 68.9),
            ('N1', 68.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.5057439,
        'r_expected' : 0.4433678,
        'Width (GeV)' : [
            ('C1-', 0.0970017694),
            ('C1+', 0.0970017694),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 8.175576458115988e-41,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2073627,
        'upper limit (fb)' : 0.4287861,
        'expected upper limit (fb)' : 0.3700541,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4836041,
        'r_expected' : 0.5603579,
        'Width (GeV)' : None,
        'likelihood' : 1.0511030000000002e-24,
        'l_max' : 1.3283930000000001e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07804949,
        'upper limit (fb)' : 0.5607579,
        'expected upper limit (fb)' : 0.8814681,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.1391857,
        'r_expected' : 0.08854488,
        'Width (GeV)' : None,
        'likelihood' : 8.690118143282759e-82,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01560127,
        'upper limit (fb)' : 0.1255412,
        'expected upper limit (fb)' : 0.1189839,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1242721,
        'r_expected' : 0.1311209,
        'Width (GeV)' : None,
        'likelihood' : 5.028810210026258e-45,
        'l_max' : 5.438918261615645e-45,
        'l_SM' : 5.438917259567711e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07011647,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 68.9),
            ('N1', 68.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1221541,
        'r_expected' : 0.1085394,
        'Width (GeV)' : [
            ('C1-', 0.0970017694),
            ('C1+', 0.0970017694),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.007721395,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01398476,
        'upper limit (fb)' : 0.16,
        'expected upper limit (fb)' : 0.123,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.73),
            ('N1/N1~', 68.9),
            ('N1', 68.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Jb',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.08740477,
        'r_expected' : 0.1136973,
        'Width (GeV)' : [
            ('C1+/C1-', 0.097002),
            ('N2/N3', 0.071084),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.2718155,
        'l_max' : 0.2979325,
        'l_SM' : 0.2176482
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0198983,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.73),
            ('N1/N1~', 68.9),
            ('N1', 68.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.0473769,
        'r_expected' : 0.1047279,
        'Width (GeV)' : [
            ('C1+/C1-', 0.097002),
            ('N2/N3', 0.071101),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001826485,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0007577586,
        'upper limit (fb)' : 0.089,
        'expected upper limit (fb)' : 0.0662,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.73),
            ('N1/N1~', 68.9),
            ('N1', 68.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SROffShell_2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.008514141,
        'r_expected' : 0.0114465,
        'Width (GeV)' : [
            ('C1+/C1-', 0.097002),
            ('N2/N3', 0.07109),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01823004,
        'l_max' : 0.02150842,
        'l_SM' : 0.01795068
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0005247934,
        'upper limit (fb)' : 0.2254578,
        'expected upper limit (fb)' : 0.1720805,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 214.2), ('N2', 213.5), ('N1', 68.9)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.00232768,
        'r_expected' : 0.003049697,
        'Width (GeV)' : [
            ('N3', 0.0645519501),
            ('N2', 0.0742865695),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6222710000000002e-34,
        'l_max' : 2.0287930000000003e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.350625,
        'r_expected' : 1.469593,
        'likelihood' : 4.189025441605343e-186,
        'l_max' : 1.2882230049766756e-184,
        'l_SM' : 1.2527449882176404e-184
    }
],
'Total xsec for missing topologies (fb)' : 1040.471,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 938.3118,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 77.96821,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.27084,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.23762,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.483602,
        'SMS' : 'PV > (W,b,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.039145,
        'SMS' : 'PV > (W,higgs,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1301393,
        'SMS' : 'PV > (W,b,MET), (W,b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01457922,
        'SMS' : 'PV > (W,b,MET), (Z,b,t,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.008195687,
        'SMS' : 'PV > (W,b,MET), (W,t,t,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.00650681,
        'SMS' : 'PV > (W,b,MET), (b,t,higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1040.471,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 938.3118,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 77.96821,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.27084,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.23762,
        'SMS' : 'PV > (MET), (higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.483602,
        'SMS' : 'PV > (W,b,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.039145,
        'SMS' : 'PV > (W,higgs,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1301393,
        'SMS' : 'PV > (W,b,MET), (W,b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01457922,
        'SMS' : 'PV > (W,b,MET), (Z,b,t,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.008195687,
        'SMS' : 'PV > (W,b,MET), (W,t,t,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.00650681,
        'SMS' : 'PV > (W,b,MET), (b,t,higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 74.30598,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 74.30598,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm512.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.122599,
        'upper limit (fb)' : 1.296606,
        'expected upper limit (fb)' : 1.625493,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8657975,
        'r_expected' : 0.6906203,
        'Width (GeV)' : None,
        'likelihood' : 7.644254278568551e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8577746,
        'upper limit (fb)' : 1.008653,
        'expected upper limit (fb)' : 1.305416,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.8504162,
        'r_expected' : 0.6570893,
        'Width (GeV)' : None,
        'likelihood' : 5.093232e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8487383,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.628695,
        'r_expected' : 0.8320963,
        'Width (GeV)' : None,
        'likelihood' : 0.002131033,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1690223,
        'upper limit (fb)' : 0.4360577,
        'expected upper limit (fb)' : 0.3209831,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3876145,
        'r_expected' : 0.5265769,
        'Width (GeV)' : None,
        'likelihood' : 1.768003e-24,
        'l_max' : 1.793085e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1089529,
        'upper limit (fb)' : 0.2858604,
        'expected upper limit (fb)' : 0.3229383,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 201.7),
            ('C1+', 201.7),
            ('N1~', 68.6),
            ('N1', 68.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3811403,
        'r_expected' : 0.33738,
        'Width (GeV)' : [
            ('C1-', 0.0903963187),
            ('C1+', 0.0903963187),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.0640040000000001e-40,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3172414,
        'upper limit (fb)' : 0.974,
        'expected upper limit (fb)' : 0.765,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.9),
            ('su_L', 220.9),
            ('C1-', 201.7),
            ('C1+', 201.7),
            ('N1~', 68.6),
            ('N1', 68.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_0bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.3257098,
        'r_expected' : 0.4146946,
        'Width (GeV)' : [
            ('su_L~', 0.0914865318),
            ('su_L', 0.0914865318),
            ('C1-', 0.0903963187),
            ('C1+', 0.0903963187),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.00616428,
        'l_max' : 0.006278059,
        'l_SM' : 0.004973309
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0729684,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 201.7),
            ('C1+', 201.7),
            ('N1~', 68.6),
            ('N1', 68.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1271226,
        'r_expected' : 0.1129542,
        'Width (GeV)' : [
            ('C1-', 0.0903963187),
            ('C1+', 0.0903963187),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.007676262,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07154667,
        'upper limit (fb)' : 0.5882644,
        'expected upper limit (fb)' : 0.8736682,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.1216233,
        'r_expected' : 0.08189227,
        'Width (GeV)' : None,
        'likelihood' : 9.057151322167628e-82,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.005411831,
        'upper limit (fb)' : 0.0751,
        'expected upper limit (fb)' : 0.0751,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N2/N3', 209.46),
            ('C1+/C1-', 201.7),
            ('N1', 68.6),
            ('N1/N1~', 68.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : 'SR_LM_Med_MCT',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.07206167,
        'r_expected' : 0.07206167,
        'Width (GeV)' : [
            ('N2/N3', 0.057885),
            ('C1+/C1-', 0.090396),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.01496299,
        'l_max' : 0.01532956,
        'l_SM' : 0.01532956
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02059588,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.7),
            ('N2/N3', 208.81),
            ('N1/N1~', 68.6),
            ('N1', 68.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.04903782,
        'r_expected' : 0.1083994,
        'Width (GeV)' : [
            ('C1+/C1-', 0.090396),
            ('N2/N3', 0.064437),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001877577,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01212137,
        'upper limit (fb)' : 0.43,
        'expected upper limit (fb)' : 0.329,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.7),
            ('N2/N3', 208.81),
            ('N1/N1~', 68.6),
            ('N1', 68.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'SR2-low',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.02818922,
        'r_expected' : 0.03684306,
        'Width (GeV)' : [
            ('C1+/C1-', 0.090396),
            ('N2/N3', 0.064428),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.005267364,
        'l_max' : 0.01400734,
        'l_SM' : 0.004554925
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0007298045,
        'upper limit (fb)' : 0.089,
        'expected upper limit (fb)' : 0.0662,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.7),
            ('N2/N3', 208.81),
            ('N1/N1~', 68.6),
            ('N1', 68.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SROffShell_2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.00820005,
        'r_expected' : 0.01102424,
        'Width (GeV)' : [
            ('C1+/C1-', 0.090396),
            ('N2/N3', 0.06442),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0182199,
        'l_max' : 0.02150842,
        'l_SM' : 0.01795068
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0002905163,
        'upper limit (fb)' : 0.2339685,
        'expected upper limit (fb)' : 0.1714704,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 209.5), ('N2', 208.5), ('N1', 68.6)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.00124169,
        'r_expected' : 0.001694265,
        'Width (GeV)' : [
            ('N3', 0.0575330387),
            ('N2', 0.067545096),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6191990000000004e-34,
        'l_max' : 2.1468400000000004e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.117451,
        'r_expected' : 1.363369,
        'likelihood' : 1.4500527679658184e-143,
        'l_max' : 1.3971892119849401e-142,
        'l_SM' : 1.1455014408442546e-142
    }
],
'Total xsec for missing topologies (fb)' : 1098.808,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 959.1066,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 75.22404,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 49.49264,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.74629,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.238798,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1098.808,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 959.1066,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 75.22404,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 49.49264,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.74629,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.238798,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 76.29438,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 76.29438,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
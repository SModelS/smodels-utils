smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm381.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.04802,
        'upper limit (fb)' : 1.38859,
        'expected upper limit (fb)' : 1.659739,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.7547369,
        'r_expected' : 0.6314366,
        'Width (GeV)' : None,
        'likelihood' : 1.1201256029490149e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.954877,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.7073163,
        'r_expected' : 0.9361539,
        'Width (GeV)' : None,
        'likelihood' : 0.001636826,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9626183,
        'upper limit (fb)' : 1.462706,
        'expected upper limit (fb)' : 1.419621,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6581077,
        'r_expected' : 0.6780811,
        'Width (GeV)' : None,
        'likelihood' : 1.3274140000000002e-20,
        'l_max' : 2.7875790000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1684928,
        'upper limit (fb)' : 0.3520151,
        'expected upper limit (fb)' : 0.3029878,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4786521,
        'r_expected' : 0.5561041,
        'Width (GeV)' : None,
        'likelihood' : 1.0683670000000001e-24,
        'l_max' : 1.3345190000000002e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1265772,
        'upper limit (fb)' : 0.2846723,
        'expected upper limit (fb)' : 0.3298041,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 78.2),
            ('N1', 78.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4446417,
        'r_expected' : 0.3837951,
        'Width (GeV)' : [
            ('C1-', 0.0864517388),
            ('C1+', 0.0864517388),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 9.110686376911129e-41,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04411223,
        'upper limit (fb)' : 0.35,
        'expected upper limit (fb)' : 0.383,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.88),
            ('N1/N1~', 78.2),
            ('N1', 78.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-0Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.1260349,
        'r_expected' : 0.1151755,
        'Width (GeV)' : [
            ('C1+/C1-', 0.086452),
            ('N2/N3', 0.06067),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01094436,
        'l_max' : 0.01183074,
        'l_SM' : 0.01183074
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03161626,
        'upper limit (fb)' : 0.3871943,
        'expected upper limit (fb)' : 0.6986927,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.08165478,
        'r_expected' : 0.0452506,
        'Width (GeV)' : None,
        'likelihood' : 9.263215783053681e-82,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03491778,
        'upper limit (fb)' : 0.531,
        'expected upper limit (fb)' : 0.438,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 78.2),
            ('N1', 78.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWc-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.06575854,
        'r_expected' : 0.07972097,
        'Width (GeV)' : [
            ('C1-', 0.0864517388),
            ('C1+', 0.0864517388),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.02049628,
        'l_max' : 0.02164771,
        'l_SM' : 0.01893459
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02216342,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.87),
            ('N1/N1~', 78.2),
            ('N1', 78.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.05277006,
        'r_expected' : 0.1166496,
        'Width (GeV)' : [
            ('C1+/C1-', 0.086452),
            ('N2/N3', 0.060687),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001996427,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.003524867,
        'upper limit (fb)' : 0.133,
        'expected upper limit (fb)' : 0.0729,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N3', 214.9),
            ('C1+/C1-', 206.8),
            ('N1', 78.2),
            ('N1/N1~', 78.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : 'SR_LM_Low_MCT',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.02650276,
        'r_expected' : 0.04835208,
        'Width (GeV)' : [
            ('N3', 0.053),
            ('C1+/C1-', 0.086452),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.004844157,
        'l_max' : 0.01413645,
        'l_SM' : 0.004073156
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0007293257,
        'upper limit (fb)' : 0.089,
        'expected upper limit (fb)' : 0.0662,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 213.88),
            ('N1/N1~', 78.2),
            ('N1', 78.2)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SROffShell_2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.008194671,
        'r_expected' : 0.011017,
        'Width (GeV)' : [
            ('C1+/C1-', 0.086452),
            ('N2/N3', 0.060659),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01821973,
        'l_max' : 0.02150842,
        'l_SM' : 0.01795068
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.169418e-05,
        'upper limit (fb)' : 0.03362762,
        'expected upper limit (fb)' : 0.04550543,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 214.9), ('N2', 213.4), ('N1', 78.2)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.0006451298,
        'r_expected' : 0.0004767382,
        'Width (GeV)' : [
            ('N3', 0.0529998606),
            ('N2', 0.0642328991),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6126500000000002e-34,
        'l_max' : 1.6144670000000003e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039-agg',
        'r' : 1.148421,
        'r_expected' : 1.429722,
        'likelihood' : 2.1148537137324714e-87,
        'l_max' : 2.1221777966883952e-86,
        'l_SM' : 1.7255338561943313e-86
    }
],
'Total xsec for missing topologies (fb)' : 1055.551,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 943.0305,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 80.37192,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 29.10239,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.679064,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3673057,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1055.551,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 943.0305,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 80.37192,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 29.10239,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.679064,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3673057,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 72.6897,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 72.6897,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
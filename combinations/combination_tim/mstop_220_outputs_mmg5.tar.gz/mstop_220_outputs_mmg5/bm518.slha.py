smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm518.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2778471,
        'upper limit (fb)' : 0.3293345,
        'expected upper limit (fb)' : 0.3189052,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.8436624,
        'r_expected' : 0.8712532,
        'Width (GeV)' : None,
        'likelihood' : 1.1912010000000002e-38,
        'l_max' : 4.4527880000000003e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.5131919,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.5),
            ('su_L', 220.5),
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 149.8),
            ('N1', 149.8)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.3801421,
        'r_expected' : 0.5031293,
        'Width (GeV)' : [
            ('su_L~', 0.047398),
            ('su_L', 0.047398),
            ('C1-', 0.00020504),
            ('C1+', 0.00020504),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003598514,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1749267,
        'upper limit (fb)' : 1.853375,
        'expected upper limit (fb)' : 1.282682,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.09438278,
        'r_expected' : 0.1363758,
        'Width (GeV)' : None,
        'likelihood' : 5.527875256573277e-72,
        'l_max' : 7.436790146075594e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03576549,
        'upper limit (fb)' : 3.17,
        'expected upper limit (fb)' : 5.0,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-/N2/N3', 214.92),
            ('C1+/C1-/N2', 207.26),
            ('N1/N1~', 149.8)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR11_Njet7_Nb1_HT300_MHT300',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.01128249,
        'r_expected' : 0.007153098,
        'Width (GeV)' : [
            ('C1-/N2/N3', 0.00016758),
            ('C1+/C1-/N2', 0.00020817),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.287212e-05,
        'l_max' : 4.347692e-05,
        'l_SM' : 4.347692e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02188851,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 149.8),
            ('N1', 149.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.01008687,
        'r_expected' : 0.0103737,
        'Width (GeV)' : [
            ('C1-', 0.00020504),
            ('C1+', 0.00020504),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002991162,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001234619,
        'upper limit (fb)' : 0.256,
        'expected upper limit (fb)' : 0.291,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 212.7),
            ('C1+/C1-', 206.8),
            ('N1', 149.8),
            ('N1/N1~', 149.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-12',
        'DataSetID' : 'SR0tau_a_Bin16',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.004822729,
        'r_expected' : 0.004242675,
        'Width (GeV)' : [
            ('N2', 0.00024474),
            ('C1+/C1-', 0.00020504),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.04289596,
        'l_max' : 0.04315095,
        'l_SM' : 0.04315095
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.005511528,
        'upper limit (fb)' : 1.980739,
        'expected upper limit (fb)' : 1.033559,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.002782562,
        'r_expected' : 0.005332574,
        'Width (GeV)' : None,
        'likelihood' : 2.8179430000000003e-20,
        'l_max' : 1.3746400000000002e-19,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03493953,
        'upper limit (fb)' : 13.292,
        'expected upper limit (fb)' : 11.561,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 149.8),
            ('N1', 149.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jlm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.002628613,
        'r_expected' : 0.003022189,
        'Width (GeV)' : [
            ('C1-', 0.00020504),
            ('C1+', 0.00020504),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.862729e-05,
        'l_max' : 3.106569e-05,
        'l_SM' : 2.855812e-05
    },
    {
        'maxcond' : 1.5943468427396595e-06,
        'theory prediction (fb)' : 0.001576118,
        'upper limit (fb)' : 1.07,
        'expected upper limit (fb)' : 1.17,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 149.8),
            ('N1', 149.8)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.001473007,
        'r_expected' : 0.001347109,
        'Width (GeV)' : [
            ('C1-', 0.00020504),
            ('C1+', 0.00020504),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002289299,
        'l_max' : 0.002291271,
        'l_SM' : 0.002291271
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.000491384,
        'upper limit (fb)' : 0.351,
        'expected upper limit (fb)' : 0.292,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2', 212.7),
            ('N1/N1~', 149.8),
            ('N1', 149.8)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : 'stop_lowMET_PT_5to12',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.001399954,
        'r_expected' : 0.001682822,
        'Width (GeV)' : [
            ('C1+/C1-', 0.00020504),
            ('N2', 0.00024474),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01562259,
        'l_max' : 0.01720959,
        'l_SM' : 0.01559495
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.668002e-06,
        'upper limit (fb)' : 0.974,
        'expected upper limit (fb)' : 0.765,
        'TxNames' : ['T1bbbb'],
        'Mass (GeV)' : [('N3', 227.7), ('N2', 212.7), ('N1', 149.8)],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_0bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 5.819304e-06,
        'r_expected' : 7.409153e-06,
        'Width (GeV)' : [
            ('N3', 3.62801295e-05),
            ('N2', 0.000244737178),
            ('N1', 'stable')
        ],
        'likelihood' : 0.004973363,
        'l_max' : 0.006278059,
        'l_SM' : 0.004973309
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 0.8501919,
        'r_expected' : 1.044734,
        'likelihood' : 2.3695540482817178e-112,
        'l_max' : 6.838448990831834e-112,
        'l_SM' : 5.6730356743010315e-112
    }
],
'Total xsec for missing topologies (fb)' : 7921.417,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3685.213,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1231.475,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1229.04,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 403.0218,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 306.6527,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 184.3687,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 134.4101,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 134.4101,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 114.8739,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 67.07223,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 7921.417,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3685.213,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1231.475,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1229.04,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 403.0218,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 306.6527,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 184.3687,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 134.4101,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 134.4101,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 114.8739,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 67.07223,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7457.151,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7385.025,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 51.37924,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 12.52523,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.010734,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.211498,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
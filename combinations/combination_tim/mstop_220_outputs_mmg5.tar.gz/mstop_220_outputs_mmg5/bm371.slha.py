smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm371.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2316187,
        'upper limit (fb)' : 0.3078955,
        'expected upper limit (fb)' : 0.2927477,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.7522639,
        'r_expected' : 0.7911887,
        'Width (GeV)' : None,
        'likelihood' : 1.6193650000000002e-38,
        'l_max' : 4.4698570000000004e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.5538896,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.0),
            ('su_L', 220.0),
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 151.6),
            ('N1', 151.6)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.4102886,
        'r_expected' : 0.543029,
        'Width (GeV)' : [
            ('su_L~', 0.083791),
            ('su_L', 0.083791),
            ('C1-', 0.0001202),
            ('C1+', 0.0001202),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003465488,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1169877,
        'upper limit (fb)' : 1.73567,
        'expected upper limit (fb)' : 1.177266,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.06740204,
        'r_expected' : 0.09937239,
        'Width (GeV)' : None,
        'likelihood' : 5.253927547723852e-72,
        'l_max' : 7.827576307095294e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.009613586,
        'upper limit (fb)' : 0.4873379,
        'expected upper limit (fb)' : 0.5186823,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.01972674,
        'r_expected' : 0.01853463,
        'Width (GeV)' : None,
        'likelihood' : 1.0688760000000003e-32,
        'l_max' : 1.0786820000000003e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03470703,
        'upper limit (fb)' : 3.17,
        'expected upper limit (fb)' : 5.0,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-/N2/N3', 208.64),
            ('C1+/C1-/N2', 202.07),
            ('N1/N1~', 151.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR11_Njet7_Nb1_HT300_MHT300',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.01094859,
        'r_expected' : 0.006941406,
        'Width (GeV)' : [
            ('C1-/N2/N3', 0.00011582),
            ('C1+/C1-/N2', 0.00012192),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.289004e-05,
        'l_max' : 4.347692e-05,
        'l_SM' : 4.347692e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01832119,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 151.6),
            ('N1', 151.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.008442943,
        'r_expected' : 0.008683026,
        'Width (GeV)' : [
            ('C1-', 0.0001202),
            ('C1+', 0.0001202),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002990785,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04438488,
        'upper limit (fb)' : 5.418835,
        'expected upper limit (fb)' : 2.548485,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 201.8),
            ('N2', 207.7),
            ('N1/N1~', 151.6),
            ('N1', 151.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.008190852,
        'r_expected' : 0.01741618,
        'Width (GeV)' : [
            ('C1+/C1-', 0.0001202),
            ('N2', 0.00015719),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 4.834475619562187e-123,
        'l_max' : 6.196070767191066e-123,
        'l_SM' : 4.533919658110445e-123
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001501061,
        'upper limit (fb)' : 0.43344,
        'expected upper limit (fb)' : 0.33172,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 151.6),
            ('N1', 151.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR3j',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.003463136,
        'r_expected' : 0.004525086,
        'Width (GeV)' : [
            ('C1-', 0.0001202),
            ('C1+', 0.0001202),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.03807494,
        'l_max' : 0.04953626,
        'l_SM' : 0.03774128
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.003072102,
        'upper limit (fb)' : 1.604124,
        'expected upper limit (fb)' : 0.7741772,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.001915127,
        'r_expected' : 0.003968216,
        'Width (GeV)' : None,
        'likelihood' : 2.811805e-20,
        'l_max' : 1.9259840000000002e-19,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 1.4745181328429879e-06,
        'theory prediction (fb)' : 0.0009051169,
        'upper limit (fb)' : 1.07,
        'expected upper limit (fb)' : 1.17,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 201.8),
            ('C1+', 201.8),
            ('N1~', 151.6),
            ('N1', 151.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.0008459036,
        'r_expected' : 0.0007736042,
        'Width (GeV)' : [
            ('C1-', 0.0001202),
            ('C1+', 0.0001202),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002290141,
        'l_max' : 0.002291271,
        'l_SM' : 0.002291271
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.8237016,
        'r_expected' : 0.9913112,
        'likelihood' : 5.611891583080304e-41,
        'l_max' : 1.545359e-40,
        'l_SM' : 1.3366570000000001e-40
    }
],
'Total xsec for missing topologies (fb)' : 8171.733,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3741.958,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1252.921,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1248.455,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 425.5929,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 311.0014,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 205.2717,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 141.9935,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 141.9935,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 115.1137,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 70.74369,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 8171.733,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3741.958,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1252.921,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1248.455,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 425.5929,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 311.0014,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 205.2717,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 141.9935,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 141.9935,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 115.1137,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 70.74369,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7560.165,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7510.686,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 42.33465,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.401959,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6104293,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1072901,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01645215,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.008196754,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
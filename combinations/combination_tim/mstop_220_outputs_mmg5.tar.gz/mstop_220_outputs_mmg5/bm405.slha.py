smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm405.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2875354,
        'upper limit (fb)' : 0.3261744,
        'expected upper limit (fb)' : 0.3226894,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.8815389,
        'r_expected' : 0.8910594,
        'Width (GeV)' : None,
        'likelihood' : 1.004457e-38,
        'l_max' : 4.4315030000000003e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1770439,
        'upper limit (fb)' : 1.842805,
        'expected upper limit (fb)' : 1.282594,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.09607307,
        'r_expected' : 0.1380358,
        'Width (GeV)' : None,
        'likelihood' : 5.513649588716241e-72,
        'l_max' : 7.326013518444811e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.020559,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 155.6),
            ('N1', 155.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.009474196,
        'r_expected' : 0.009743604,
        'Width (GeV)' : [
            ('C1-', 0.00024531),
            ('C1+', 0.00024531),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002991026,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02746417,
        'upper limit (fb)' : 4.1,
        'expected upper limit (fb)' : 3.72,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 155.6),
            ('N1', 155.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-033',
        'DataSetID' : 'SR3_Njet5_Nb0_HT500_MHT_500',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.006698577,
        'r_expected' : 0.00738284,
        'Width (GeV)' : [
            ('C1-', 0.00024531),
            ('C1+', 0.00024531),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 9.584103e-05,
        'l_max' : 9.755716e-05,
        'l_SM' : 9.555076e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001209359,
        'upper limit (fb)' : 0.241,
        'expected upper limit (fb)' : 0.272,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2', 220.7),
            ('N1/N1~', 155.6),
            ('N1', 155.6)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : 'stop_highMET_PT_20to30',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.005018088,
        'r_expected' : 0.004446174,
        'Width (GeV)' : [
            ('C1+/C1-', 0.00024531),
            ('N2', 0.00028465),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0203072,
        'l_max' : 0.02036404,
        'l_SM' : 0.02036404
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00684303,
        'upper limit (fb)' : 2.054285,
        'expected upper limit (fb)' : 1.096757,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.003331101,
        'r_expected' : 0.006239332,
        'Width (GeV)' : None,
        'likelihood' : 2.834308e-20,
        'l_max' : 1.6952180000000003e-19,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03117134,
        'upper limit (fb)' : 13.292,
        'expected upper limit (fb)' : 11.561,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 155.6),
            ('N1', 155.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jlm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.002345121,
        'r_expected' : 0.00269625,
        'Width (GeV)' : [
            ('C1-', 0.00024531),
            ('C1+', 0.00024531),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.861987e-05,
        'l_max' : 3.106569e-05,
        'l_SM' : 2.855812e-05
    },
    {
        'maxcond' : 1.6822542516358e-06,
        'theory prediction (fb)' : 0.001467733,
        'upper limit (fb)' : 1.07,
        'expected upper limit (fb)' : 1.17,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 155.6),
            ('N1', 155.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.001371713,
        'r_expected' : 0.001254472,
        'Width (GeV)' : [
            ('C1-', 0.00024531),
            ('C1+', 0.00024531),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002289435,
        'l_max' : 0.002291271,
        'l_SM' : 0.002291271
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.943589e-05,
        'upper limit (fb)' : 1.04,
        'expected upper limit (fb)' : 0.936,
        'TxNames' : ['T1bbbb'],
        'Mass (GeV)' : [('N3', 234.9), ('N2', 220.7), ('N1', 155.6)],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_1000HT1250_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 5.714989e-05,
        'r_expected' : 6.349988e-05,
        'Width (GeV)' : [
            ('N3', 4.20000077e-05),
            ('N2', 0.00028465486),
            ('N1', 'stable')
        ],
        'likelihood' : 0.004373397,
        'l_max' : 0.004463612,
        'l_SM' : 0.004373275
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2019-09,CMS-SUS-16-039',
        'r' : 0.8399896,
        'r_expected' : 0.8986118,
        'likelihood' : 5.538222348022417e-110,
        'l_max' : 1.9209078655238386e-109,
        'l_SM' : 1.8789383998185617e-109
    }
],
'Total xsec for missing topologies (fb)' : 7756.114,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3660.21,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1222.432,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1220.568,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 388.4129,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 304.6768,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 161.554,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 129.5238,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 129.5238,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 98.04526,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 64.66319,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 7756.114,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3660.21,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1222.432,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1220.568,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 388.4129,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 304.6768,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 161.554,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 129.5238,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 129.5238,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 98.04526,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 64.66319,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,ta,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 18389.36,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10992.91,
        'SMS' : 'PV > (b,jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7331.597,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 45.45534,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11.87038,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.424875,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.093219,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0135649,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    }
]
}
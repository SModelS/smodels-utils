smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm562.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.547073,
        'upper limit (fb)' : 1.306238,
        'expected upper limit (fb)' : 1.66932,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 1.184373,
        'r_expected' : 0.9267681,
        'Width (GeV)' : None,
        'likelihood' : 2.515718403188734e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.171905,
        'upper limit (fb)' : 1.162155,
        'expected upper limit (fb)' : 1.413677,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 1.00839,
        'r_expected' : 0.8289765,
        'Width (GeV)' : None,
        'likelihood' : 3.2659000000000006e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.893411,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.6617859,
        'r_expected' : 0.8758932,
        'Width (GeV)' : None,
        'likelihood' : 0.001917722,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1725668,
        'upper limit (fb)' : 0.3596956,
        'expected upper limit (fb)' : 0.2646603,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4797579,
        'r_expected' : 0.6520314,
        'Width (GeV)' : None,
        'likelihood' : 1.655576e-24,
        'l_max' : 1.7985830000000003e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1092863,
        'upper limit (fb)' : 0.2977883,
        'expected upper limit (fb)' : 0.3258741,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 63.5),
            ('N1', 63.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3669933,
        'r_expected' : 0.3353636,
        'Width (GeV)' : [
            ('C1-', 0.0820436002),
            ('C1+', 0.0820436002),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.138716e-40,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4023906,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.2,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.5),
            ('su_L', 220.5),
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 63.5),
            ('N1', 63.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_1bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.2980671,
        'r_expected' : 0.3353255,
        'Width (GeV)' : [
            ('su_L~', 0.201057698),
            ('su_L', 0.201057698),
            ('C1-', 0.0820436002),
            ('C1+', 0.0820436002),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002255401,
        'l_max' : 0.002394811,
        'l_SM' : 0.002264688
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01094198,
        'upper limit (fb)' : 0.0756,
        'expected upper limit (fb)' : 0.0842,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 191.7),
            ('N2/N3', 198.85),
            ('N1/N1~', 63.5),
            ('N1', 63.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SRLow2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1447351,
        'r_expected' : 0.1299522,
        'Width (GeV)' : [
            ('C1+/C1-', 0.082044),
            ('N2/N3', 0.055828),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01223404,
        'l_max' : 0.01363736,
        'l_SM' : 0.01363736
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.08220762,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 191.7),
            ('C1+', 191.7),
            ('N1~', 63.5),
            ('N1', 63.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1432189,
        'r_expected' : 0.1272564,
        'Width (GeV)' : [
            ('C1-', 0.0820436002),
            ('C1+', 0.0820436002),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.007527494,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02630901,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 191.7),
            ('N2/N3', 198.85),
            ('N1/N1~', 63.5),
            ('N1', 63.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.06264049,
        'r_expected' : 0.1384685,
        'Width (GeV)' : [
            ('C1+/C1-', 0.082044),
            ('N2/N3', 0.055839),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002338764,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01450092,
        'upper limit (fb)' : 0.43,
        'expected upper limit (fb)' : 0.329,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 191.7),
            ('N2/N3', 198.85),
            ('N1/N1~', 63.5),
            ('N1', 63.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'SR2-low',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.03372306,
        'r_expected' : 0.04407573,
        'Width (GeV)' : [
            ('C1+/C1-', 0.082044),
            ('N2/N3', 0.055826),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.005412959,
        'l_max' : 0.01400734,
        'l_SM' : 0.004554925
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.495759e-05,
        'upper limit (fb)' : 0.2451829,
        'expected upper limit (fb)' : 0.195824,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 199.7), ('N2', 198.5), ('N1', 63.5)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.0001833635,
        'r_expected' : 0.0002295816,
        'Width (GeV)' : [
            ('N3', 0.0483257903),
            ('N2', 0.0588856052),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6148580000000004e-34,
        'l_max' : 1.7954680000000004e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-05-ewk,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.350152,
        'r_expected' : 1.534005,
        'likelihood' : 1.8891070737500008e-146,
        'l_max' : 7.729461535975496e-145,
        'l_SM' : 7.113593515157425e-145
    }
],
'Total xsec for missing topologies (fb)' : 1205.942,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1052.459,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 95.92723,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 49.94514,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.481556,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.129615,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1205.942,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1052.459,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 95.92723,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 49.94514,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.481556,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.129615,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 222.4669,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 152.3441,
        'SMS' : 'PV > (higgs,MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 70.12282,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
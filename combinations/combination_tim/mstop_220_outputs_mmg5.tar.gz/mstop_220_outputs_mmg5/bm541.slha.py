smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm541.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.303467,
        'upper limit (fb)' : 1.238338,
        'expected upper limit (fb)' : 1.787331,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 1.052594,
        'r_expected' : 0.7292813,
        'Width (GeV)' : None,
        'likelihood' : 3.7074965420055265e-73,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8822167,
        'upper limit (fb)' : 0.9757857,
        'expected upper limit (fb)' : 1.329768,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.9041091,
        'r_expected' : 0.6634367,
        'Width (GeV)' : None,
        'likelihood' : 4.035366e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.054228,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.7809093,
        'r_expected' : 1.033556,
        'Width (GeV)' : None,
        'likelihood' : 0.001227287,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1382879,
        'upper limit (fb)' : 0.29382,
        'expected upper limit (fb)' : 0.3165217,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 196.7),
            ('C1+', 196.7),
            ('N1~', 54.5),
            ('N1', 54.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4706552,
        'r_expected' : 0.4368987,
        'Width (GeV)' : [
            ('C1-', 0.0974707692),
            ('C1+', 0.0974707692),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 9.614767057244592e-41,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1975309,
        'upper limit (fb)' : 0.4210011,
        'expected upper limit (fb)' : 0.3196366,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4691932,
        'r_expected' : 0.6179858,
        'Width (GeV)' : None,
        'likelihood' : 1.5006320000000002e-24,
        'l_max' : 1.6513490000000002e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2201085,
        'upper limit (fb)' : 0.974,
        'expected upper limit (fb)' : 0.765,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 221.0),
            ('su_L', 221.0),
            ('C1-', 196.7),
            ('C1+', 196.7),
            ('N1~', 54.5),
            ('N1', 54.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_0bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.225984,
        'r_expected' : 0.2877235,
        'Width (GeV)' : [
            ('su_L~', 0.144842314),
            ('su_L', 0.144842314),
            ('C1-', 0.0974707692),
            ('C1+', 0.0974707692),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.006262155,
        'l_max' : 0.006278059,
        'l_SM' : 0.004973309
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.09000827,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 196.7),
            ('C1+', 196.7),
            ('N1~', 54.5),
            ('N1', 54.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1568088,
        'r_expected' : 0.1393317,
        'Width (GeV)' : [
            ('C1-', 0.0974707692),
            ('C1+', 0.0974707692),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.007399069,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.009972709,
        'upper limit (fb)' : 0.08234625,
        'expected upper limit (fb)' : 0.06340339,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.121107,
        'r_expected' : 0.1572899,
        'Width (GeV)' : None,
        'likelihood' : 5.118357890585987e-45,
        'l_max' : 5.438917671506243e-45,
        'l_SM' : 5.438917259567711e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.006521324,
        'upper limit (fb)' : 0.0756,
        'expected upper limit (fb)' : 0.0842,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 196.7),
            ('N2', 203.6),
            ('N1/N1~', 54.5),
            ('N1', 54.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-05-ewk',
        'DataSetID' : 'SRLow2_cuts',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0862609,
        'r_expected' : 0.0774504,
        'Width (GeV)' : [
            ('C1+/C1-', 0.097471),
            ('N2', 0.073883),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0129241,
        'l_max' : 0.01363736,
        'l_SM' : 0.01363736
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0207548,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 196.7),
            ('N2/N3', 203.66),
            ('N1/N1~', 54.5),
            ('N1', 54.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.04941619,
        'r_expected' : 0.1092358,
        'Width (GeV)' : [
            ('C1+/C1-', 0.097471),
            ('N2/N3', 0.071105),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001889369,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02690416,
        'upper limit (fb)' : 0.8006248,
        'expected upper limit (fb)' : 1.246934,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.03360395,
        'r_expected' : 0.02157626,
        'Width (GeV)' : None,
        'likelihood' : 1.012288001302816e-81,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01263235,
        'upper limit (fb)' : 0.43,
        'expected upper limit (fb)' : 0.329,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 196.7),
            ('N2/N3', 203.66),
            ('N1/N1~', 54.5),
            ('N1', 54.5)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'SR2-low',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.02937757,
        'r_expected' : 0.03839621,
        'Width (GeV)' : [
            ('C1+/C1-', 0.097471),
            ('N2/N3', 0.071103),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.00529848,
        'l_max' : 0.01400734,
        'l_SM' : 0.004554925
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0007304618,
        'upper limit (fb)' : 0.1944378,
        'expected upper limit (fb)' : 0.1550695,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 203.8), ('N2', 203.6), ('N1', 54.5)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.003756789,
        'r_expected' : 0.004710544,
        'Width (GeV)' : [
            ('N3', 0.0639185522),
            ('N2', 0.0738828282),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6224440000000004e-34,
        'l_max' : 1.7998370000000004e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-13-012,CMS-SUS-16-039',
        'r' : 1.376752,
        'r_expected' : 1.573489,
        'likelihood' : 1.5569374253003595e-188,
        'l_max' : 6.757320834591059e-187,
        'l_SM' : 6.230287557467409e-187
    }
],
'Total xsec for missing topologies (fb)' : 1072.136,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 961.4115,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 72.91604,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 23.15849,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 13.50297,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.146845,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1072.136,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 961.4115,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 72.91604,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 23.15849,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 13.50297,
        'SMS' : 'PV > (MET), (MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.146845,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 89.65395,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 89.65395,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,CMS-SUS-16-039-agg,ATLAS-SUSY-2013-04,ATLAS-SUSY-2016-24',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm424.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9970095,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.7385255,
        'r_expected' : 0.9774603,
        'Width (GeV)' : None,
        'likelihood' : 0.001455612,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.542766,
        'upper limit (fb)' : 2.43227,
        'expected upper limit (fb)' : 1.507745,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6342907,
        'r_expected' : 1.023228,
        'Width (GeV)' : None,
        'likelihood' : 7.469077e-20,
        'l_max' : 8.858855000000001e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2727861,
        'upper limit (fb)' : 1.04,
        'expected upper limit (fb)' : 1.23,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.3),
            ('su_L', 220.3),
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 109.6),
            ('N1', 109.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_2ibjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.2622943,
        'r_expected' : 0.2217773,
        'Width (GeV)' : [
            ('su_L~', 0.0456895174),
            ('su_L', 0.0456895174),
            ('C1-', 0.0332631359),
            ('C1+', 0.0332631359),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001520162,
        'l_max' : 0.002115684,
        'l_SM' : 0.002115684
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02021045,
        'upper limit (fb)' : 0.09,
        'expected upper limit (fb)' : 0.127,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 215.75),
            ('N1/N1~', 109.6),
            ('N1', 109.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-1Ja',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.2245606,
        'r_expected' : 0.1591374,
        'Width (GeV)' : [
            ('C1+/C1-', 0.033263),
            ('N2/N3', 0.012803),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.1316134,
        'l_max' : 0.2014847,
        'l_SM' : 0.2014847
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01815045,
        'upper limit (fb)' : 0.518,
        'expected upper limit (fb)' : 0.555,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 206.8),
            ('C1+', 206.8),
            ('N1~', 109.6),
            ('N1', 109.6)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWb-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.03503947,
        'r_expected' : 0.03270351,
        'Width (GeV)' : [
            ('C1-', 0.0332631359),
            ('C1+', 0.0332631359),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.01413695,
        'l_max' : 0.01441039,
        'l_SM' : 0.01441039
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.002780975,
        'upper limit (fb)' : 0.5687,
        'expected upper limit (fb)' : 0.5188,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 206.8),
            ('N2/N3', 215.9),
            ('N1/N1~', 109.6),
            ('N1', 109.6)
        ],
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : 'H_SR1',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.004890057,
        'r_expected' : 0.005360399,
        'Width (GeV)' : [
            ('C1+/C1-', 0.033263),
            ('N2/N3', 0.012597),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.000241538,
        'l_max' : 0.0002466202,
        'l_SM' : 0.0002410039
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,ATLAS-SUSY-2016-24,CMS-SUS-13-012,CMS-SUS-16-039-agg',
        'r' : 0.9981937,
        'r_expected' : 1.557742,
        'likelihood' : 2.1752160000000003e-26,
        'l_max' : 9.028915000000002e-26,
        'l_SM' : 3.552327e-26
    }
],
'Total xsec for missing topologies (fb)' : 1059.704,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 932.3339,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 89.43901,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 32.52305,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.749878,
        'SMS' : 'PV > (W,W,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8833576,
        'SMS' : 'PV > (Z,W,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8652893,
        'SMS' : 'PV > (Z,higgs,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6030132,
        'SMS' : 'PV > (W,higgs,MET), (W,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3044077,
        'SMS' : 'PV > (W,higgs,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2981813,
        'SMS' : 'PV > (W,higgs,MET), (Z,higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2050423,
        'SMS' : 'PV > (Z,W,MET), (W,b,t,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1059.704,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 932.3339,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 89.43901,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 32.52305,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.749878,
        'SMS' : 'PV > (W,W,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8833576,
        'SMS' : 'PV > (Z,W,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8652893,
        'SMS' : 'PV > (Z,higgs,MET), (Z,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6030132,
        'SMS' : 'PV > (W,higgs,MET), (W,W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3044077,
        'SMS' : 'PV > (W,higgs,MET), (Z,Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2981813,
        'SMS' : 'PV > (W,higgs,MET), (Z,higgs,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2050423,
        'SMS' : 'PV > (Z,W,MET), (W,b,t,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}
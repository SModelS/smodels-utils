smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm292.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1745794,
        'upper limit (fb)' : 0.2265999,
        'expected upper limit (fb)' : 0.227844,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.7704301,
        'r_expected' : 0.7662235,
        'Width (GeV)' : None,
        'likelihood' : 1.3077120000000002e-38,
        'l_max' : 4.4270770000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.7117747,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.4),
            ('su_L', 220.4),
            ('C1-', 171.5),
            ('C1+', 171.5),
            ('N1~', 135.9),
            ('N1', 135.9)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.5272406,
        'r_expected' : 0.6978184,
        'Width (GeV)' : [
            ('su_L~', 0.52671),
            ('su_L', 0.52671),
            ('C1-', 2.9497e-05),
            ('C1+', 2.9497e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002796686,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02415021,
        'upper limit (fb)' : 0.3830305,
        'expected upper limit (fb)' : 0.6448556,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.06305036,
        'r_expected' : 0.03745058,
        'Width (GeV)' : None,
        'likelihood' : 9.477634000000002e-33,
        'l_max' : 1.0786820000000003e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02232781,
        'upper limit (fb)' : 0.366506,
        'expected upper limit (fb)' : 0.4382842,
        'TxNames' : ['TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.06092073,
        'r_expected' : 0.05094368,
        'Width (GeV)' : None,
        'likelihood' : 0.1081495,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05874549,
        'upper limit (fb)' : 1.294969,
        'expected upper limit (fb)' : 1.121442,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.04536441,
        'r_expected' : 0.0523839,
        'Width (GeV)' : None,
        'likelihood' : 4.40325545284206e-72,
        'l_max' : 4.563967003688144e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001189055,
        'upper limit (fb)' : 0.03403597,
        'expected upper limit (fb)' : 0.05067315,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-41',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.03493526,
        'r_expected' : 0.0234652,
        'Width (GeV)' : None,
        'likelihood' : 0.002223305,
        'l_max' : 0.002358157,
        'l_SM' : 0.002358157
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00484113,
        'upper limit (fb)' : 0.232828,
        'expected upper limit (fb)' : 0.1479299,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.02079273,
        'r_expected' : 0.03272583,
        'Width (GeV)' : None,
        'likelihood' : 1.120435788713915e-81,
        'l_max' : 1.5085822951005114e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01267318,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-/N3', 172.15),
            ('C1+/C1-/N2', 171.53),
            ('N1/N1~', 135.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.005840174,
        'r_expected' : 0.006006245,
        'Width (GeV)' : [
            ('C1-/N3', 3.0084e-05),
            ('C1+/C1-/N2', 2.9595e-05),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.0002990109,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0004187056,
        'upper limit (fb)' : 0.07885089,
        'expected upper limit (fb)' : 0.04444978,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.005310094,
        'r_expected' : 0.009419745,
        'Width (GeV)' : None,
        'likelihood' : 5.5418154938818006e-45,
        'l_max' : 5.955305044733274e-45,
        'l_SM' : 5.438917259567711e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05293346,
        'upper limit (fb)' : 13.292,
        'expected upper limit (fb)' : 11.561,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-/N2', 175.07),
            ('C1+/C1-', 171.5),
            ('N1/N1~', 135.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR4jlm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.003982355,
        'r_expected' : 0.004578623,
        'Width (GeV)' : [
            ('C1-/N2', 4.1194e-05),
            ('C1+/C1-', 2.9497e-05),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.866259e-05,
        'l_max' : 3.106569e-05,
        'l_SM' : 2.855812e-05
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001228811,
        'upper limit (fb)' : 1.160359,
        'expected upper limit (fb)' : 1.151291,
        'TxNames' : ['TChiWZ', 'TChiWZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.001058993,
        'r_expected' : 0.001067333,
        'Width (GeV)' : None,
        'likelihood' : 2.7599200000000004e-20,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 1.0433305007218975e-06,
        'theory prediction (fb)' : 0.0008639616,
        'upper limit (fb)' : 1.07,
        'expected upper limit (fb)' : 1.17,
        'TxNames' : ['TChiWWoff'],
        'Mass (GeV)' : [
            ('C1-', 171.5),
            ('C1+', 171.5),
            ('N1~', 135.9),
            ('N1', 135.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWa-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.0008074408,
        'r_expected' : 0.0007384287,
        'Width (GeV)' : [
            ('C1-', 2.9497e-05),
            ('C1+', 2.9497e-05),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.002290192,
        'l_max' : 0.002291271,
        'l_SM' : 0.002291271
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.933687,
        'r_expected' : 1.119907,
        'likelihood' : 3.657260541178682e-41,
        'l_max' : 1.463826e-40,
        'l_SM' : 1.3366570000000001e-40
    }
],
'Total xsec for missing topologies (fb)' : 9056.241,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3717.923,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1254.903,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1242.452,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 555.4429,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 434.2008,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 307.5311,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 185.6173,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 185.6173,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 171.7487,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 110.0378,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 9056.241,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3717.923,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1254.903,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1242.452,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 555.4429,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 434.2008,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 307.5311,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 185.6173,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 185.6173,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 171.7487,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 110.0378,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7560.087,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7510.363,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 46.27342,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.79799,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4578149,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.08830304,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06362121,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04371346,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,ATLAS-SUSY-2013-04',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm501.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.113253,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWW', 'TChiWW', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.8246319,
        'r_expected' : 1.091425,
        'Width (GeV)' : None,
        'likelihood' : 0.001015475,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8625876,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.2,
        'TxNames' : ['T6bbWW'],
        'Mass (GeV)' : [
            ('su_L~', 220.1),
            ('su_L', 220.1),
            ('C1-', 136.2),
            ('C1+', 136.2),
            ('N1~', 49.9),
            ('N1', 49.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-04',
        'DataSetID' : 'GtGrid_SR_8ej50_1bjet',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.6389538,
        'r_expected' : 0.718823,
        'Width (GeV)' : [
            ('su_L~', 1.29563665),
            ('su_L', 1.29563665),
            ('C1-', 0.0123083452),
            ('C1+', 0.0123083452),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001286524,
        'l_max' : 0.002394811,
        'l_SM' : 0.002264688
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05304854,
        'upper limit (fb)' : 0.518,
        'expected upper limit (fb)' : 0.555,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 136.2),
            ('C1+', 136.2),
            ('N1~', 49.9),
            ('N1', 49.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'WWb-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1024103,
        'r_expected' : 0.09558296,
        'Width (GeV)' : [
            ('C1-', 0.0123083452),
            ('C1+', 0.0123083452),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0134283,
        'l_max' : 0.01441039,
        'l_SM' : 0.01441039
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07585054,
        'upper limit (fb)' : 1.311814,
        'expected upper limit (fb)' : 0.8505167,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 136.2),
            ('C1+', 136.2),
            ('N1~', 49.9),
            ('N1', 49.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-02',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.05782112,
        'r_expected' : 0.08918172,
        'Width (GeV)' : [
            ('C1-', 0.0123083452),
            ('C1+', 0.0123083452),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 2.871346e-40,
        'l_max' : 5.73313e-40,
        'l_SM' : 2.291911e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0003372989,
        'upper limit (fb)' : 0.02431,
        'expected upper limit (fb)' : 0.0251,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 136.2),
            ('N3', 148.9),
            ('N1/N1~', 49.9),
            ('N1', 49.9)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : 'SRWZ_20',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0138749,
        'r_expected' : 0.0134382,
        'Width (GeV)' : [
            ('C1+/C1-', 0.012308),
            ('N3', 0.0082848),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.11942,
        'l_max' : 1.124701,
        'l_SM' : 1.124701
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-04,CMS-SUS-13-012',
        'r' : 1.092152,
        'r_expected' : 1.445078,
        'likelihood' : 1.306434e-06,
        'l_max' : 9.283065e-06,
        'l_SM' : 6.837721e-06
    }
],
'Total xsec for missing topologies (fb)' : 2566.658,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1705.932,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 534.4633,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 236.1493,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 90.11301,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 2566.658,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1705.932,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 534.4633,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 236.1493,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 90.11301,
        'SMS' : 'PV > (MET), (MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}
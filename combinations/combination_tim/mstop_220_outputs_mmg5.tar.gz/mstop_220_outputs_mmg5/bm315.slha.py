smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-16-039',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm315.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8496681,
        'upper limit (fb)' : 1.233561,
        'expected upper limit (fb)' : 1.576678,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6887928,
        'r_expected' : 0.5388978,
        'Width (GeV)' : None,
        'likelihood' : 1.244661716287856e-72,
        'l_max' : 4.2441968280598925e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.6545833,
        'upper limit (fb)' : 1.02972,
        'expected upper limit (fb)' : 1.326349,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.6356905,
        'r_expected' : 0.4935228,
        'Width (GeV)' : None,
        'likelihood' : 9.253677000000001e-21,
        'l_max' : 2.7600510000000006e-20,
        'l_SM' : 2.7600510000000006e-20
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1628259,
        'upper limit (fb)' : 0.2794548,
        'expected upper limit (fb)' : 0.3206796,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 69.3),
            ('N1', 69.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2018-32',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.5826556,
        'r_expected' : 0.5077526,
        'Width (GeV)' : [
            ('C1-', 0.107135041),
            ('C1+', 0.107135041),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 6.788939373981043e-41,
        'l_max' : 1.715991e-40,
        'l_SM' : 1.715991e-40
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1831461,
        'upper limit (fb)' : 0.3871506,
        'expected upper limit (fb)' : 0.3682616,
        'TxNames' : ['TChiWH', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4730616,
        'r_expected' : 0.497326,
        'Width (GeV)' : None,
        'likelihood' : 8.533108e-25,
        'l_max' : 1.2200320000000001e-24,
        'l_SM' : 1.2066700000000002e-24
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02311791,
        'upper limit (fb)' : 0.1,
        'expected upper limit (fb)' : 0.124,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2/N3', 221.61),
            ('N1/N1~', 69.3),
            ('N1', 69.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-24',
        'DataSetID' : 'WZ-0Jb',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.2311791,
        'r_expected' : 0.1864348,
        'Width (GeV)' : [
            ('C1+/C1-', 0.10714),
            ('N2/N3', 0.081277),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0876163,
        'l_max' : 0.151876,
        'l_SM' : 0.151876
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01875444,
        'upper limit (fb)' : 0.1244034,
        'expected upper limit (fb)' : 0.117735,
        'TxNames' : ['TChiWH'],
        'Mass (GeV)' : [
            ('N2/N3', 221.79),
            ('C1+/C1-', 214.8),
            ('N1', 69.3),
            ('N1/N1~', 69.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-08',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.150755,
        'r_expected' : 0.1592937,
        'Width (GeV)' : [
            ('N2/N3', 0.075444),
            ('C1+/C1-', 0.10714),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.917121274446615e-45,
        'l_max' : 5.438918254065253e-45,
        'l_SM' : 5.438917259567711e-45
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06714732,
        'upper limit (fb)' : 0.574,
        'expected upper limit (fb)' : 0.646,
        'TxNames' : ['TChiWW'],
        'Mass (GeV)' : [
            ('C1-', 214.8),
            ('C1+', 214.8),
            ('N1~', 69.3),
            ('N1', 69.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2013-11',
        'DataSetID' : 'mT2-90-DF',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 0.1169814,
        'r_expected' : 0.1039432,
        'Width (GeV)' : [
            ('C1-', 0.107135041),
            ('C1+', 0.107135041),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.007767967,
        'l_max' : 0.008680571,
        'l_SM' : 0.008680571
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06309136,
        'upper limit (fb)' : 0.6427491,
        'expected upper limit (fb)' : 0.7434822,
        'TxNames' : ['TChiWH', 'TChiWW', 'TChiWZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-21-002',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.09815862,
        'r_expected' : 0.08485927,
        'Width (GeV)' : None,
        'likelihood' : 1.0035853666804555e-81,
        'l_max' : 1.0563691620387707e-81,
        'l_SM' : 1.0563691620387707e-81
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01496397,
        'upper limit (fb)' : 0.42,
        'expected upper limit (fb)' : 0.19,
        'TxNames' : ['TChiWZ'],
        'Mass (GeV)' : [
            ('C1+/C1-', 214.8),
            ('N2/N3', 221.61),
            ('N1/N1~', 69.3),
            ('N1', 69.3)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2017-03',
        'DataSetID' : 'SR3l_ISR',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.03562851,
        'r_expected' : 0.07875775,
        'Width (GeV)' : [
            ('C1+/C1-', 0.10714),
            ('N2/N3', 0.081286),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.001495314,
        'l_max' : 0.0456262,
        'l_SM' : 0.0007714575
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0270064,
        'upper limit (fb)' : 2.88,
        'expected upper limit (fb)' : 2.01,
        'TxNames' : ['TChiWW', 'TChiWZ', 'TChiZZ'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '3NJet6_800HT1000_450MHT600',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.009377224,
        'r_expected' : 0.01343602,
        'Width (GeV)' : None,
        'likelihood' : 0.0006732974,
        'l_max' : 0.0009521956,
        'l_SM' : 0.0006572509
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00102468,
        'upper limit (fb)' : 0.2384627,
        'expected upper limit (fb)' : 0.1825071,
        'TxNames' : ['TChiHH'],
        'Mass (GeV)' : [('N3', 221.8), ('N2', 221.5), ('N1', 69.3)],
        'AnalysisID' : 'CMS-SUS-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.004297023,
        'r_expected' : 0.005614464,
        'Width (GeV)' : [
            ('N3', 0.074978853),
            ('N2', 0.0848167767),
            ('N1', 'stable')
        ],
        'likelihood' : 1.6282060000000003e-34,
        'l_max' : 1.9999530000000004e-34,
        'l_SM' : 1.6144670000000003e-34
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2013-11,ATLAS-SUSY-2018-32,ATLAS-SUSY-2019-08,ATLAS-SUSY-2019-09,CMS-SUS-16-039',
        'r' : 1.164726,
        'r_expected' : 0.9549861,
        'likelihood' : 2.7540943574714906e-183,
        'l_max' : 4.14915540581799e-182,
        'l_SM' : 4.14915540581799e-182
    }
],
'Total xsec for missing topologies (fb)' : 973.7686,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 873.9641,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 56.64582,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 39.58296,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.575746,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 973.7686,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 873.9641,
        'SMS' : 'PV > (W,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 56.64582,
        'SMS' : 'PV > (MET), (W,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 39.58296,
        'SMS' : 'PV > (MET), (Z,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.575746,
        'SMS' : 'PV > (MET), (higgs,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 25391.47,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 25326.08,
        'SMS' : 'PV > (W,b,MET), (W,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 65.39405,
        'SMS' : 'PV > (higgs,MET), (Z,MET)'
    }
]
}
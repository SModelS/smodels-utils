smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : '1.00E-03 [fb]',
    'minmassgap' : '5.00E+00 [GeV]',
    'maxcond' : 0.2,
    'ncpus' : 35,
    'model' : 'share.models.mssm',
    'promptWidth' : '1.00E-11 [GeV]',
    'stableWidth' : '1.00E-25 [GeV]',
    'checkInput' : True,
    'invisibleCompress' : True,
    'massCompress' : True,
    'computestatistics' : False,
    'testcoverage' : True,
    'combineSRs' : True,
    'combineanas' : 'CMS-SUS-13-012,ATLAS-SUSY-2019-09,ATLAS-SUSY-2018-16',
    'reportallsrs' : False,
    'experimentalFeatures' : False,
    'useNonValidated' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : './mstop_220/bm129.slha',
    'database version' : '3.0.0-beta',
    'smodels version' : '3.0.0-beta'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.6466578,
        'upper limit (fb)' : 1.35,
        'expected upper limit (fb)' : 1.02,
        'TxNames' : ['T6bbWWoff'],
        'Mass (GeV)' : [
            ('su_L~', 220.4),
            ('su_L', 220.4),
            ('C1-', 161.5),
            ('C1+', 161.5),
            ('N1~', 143.0),
            ('N1', 143.0)
        ],
        'AnalysisID' : 'CMS-SUS-13-012',
        'DataSetID' : '6NJet8_800HT1000_300MHT450',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.5,
        'dataType' : 'efficiencyMap',
        'r' : 0.4790058,
        'r_expected' : 0.6339782,
        'Width (GeV)' : [
            ('su_L~', 0.72908),
            ('su_L', 0.72908),
            ('C1-', 1.7883e-06),
            ('C1+', 1.7883e-06),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.003095343,
        'l_max' : 0.003889583,
        'l_SM' : 0.003019277
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05516761,
        'upper limit (fb)' : 0.1196743,
        'expected upper limit (fb)' : 0.1208123,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 167.2),
            ('C1+/C1-', 161.5),
            ('N1', 143.0),
            ('N1/N1~', 143.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2019-09',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4609812,
        'r_expected' : 0.4566392,
        'Width (GeV)' : [
            ('N2', 5.2965e-06),
            ('C1+/C1-', 1.7883e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 2.717153e-38,
        'l_max' : 4.4273690000000006e-38,
        'l_SM' : 4.4270760000000007e-38
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1613614,
        'upper limit (fb)' : 0.5003876,
        'expected upper limit (fb)' : 0.59848,
        'TxNames' : ['TChiWWoff', 'TChiWZoff', 'TChiZoff'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'ATLAS-SUSY-2018-16',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3224728,
        'r_expected' : 0.2696186,
        'Width (GeV)' : None,
        'likelihood' : 0.07302995,
        'l_max' : 0.1148995,
        'l_SM' : 0.1148995
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02686265,
        'upper limit (fb)' : 0.5852843,
        'expected upper limit (fb)' : 0.4466435,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('C1+/C1-', 161.5),
            ('N2', 167.2),
            ('N1/N1~', 143.0),
            ('N1', 143.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-048',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.04589676,
        'r_expected' : 0.06014339,
        'Width (GeV)' : [
            ('C1+/C1-', 1.7883e-06),
            ('N2', 5.2965e-06),
            ('N1/N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 1.1637510000000003e-32,
        'l_max' : 1.3491240000000004e-32,
        'l_SM' : 1.0786820000000003e-32
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.007530292,
        'upper limit (fb)' : 0.8827585,
        'expected upper limit (fb)' : 0.811056,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 167.2),
            ('C1+/C1-', 161.5),
            ('N1', 143.0),
            ('N1/N1~', 143.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-039',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'combined',
        'r' : 0.00853041,
        'r_expected' : 0.009284552,
        'Width (GeV)' : [
            ('N2', 5.2965e-06),
            ('C1+/C1-', 1.7883e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 4.265379679235189e-72,
        'l_max' : 4.3693331299031937e-72,
        'l_SM' : 4.2441968280598925e-72
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00807475,
        'upper limit (fb)' : 2.17,
        'expected upper limit (fb)' : 2.11,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [
            ('C1-', 161.5),
            ('C1+', 161.5),
            ('N1~', 143.0),
            ('N1', 143.0)
        ],
        'AnalysisID' : 'ATLAS-SUSY-2016-07',
        'DataSetID' : '6j_Meff_1200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 36.1,
        'dataType' : 'efficiencyMap',
        'r' : 0.003721083,
        'r_expected' : 0.003826896,
        'Width (GeV)' : [
            ('C1-', 1.7883e-06),
            ('C1+', 1.7883e-06),
            ('N1~', 'stable'),
            ('N1', 'stable')
        ],
        'likelihood' : 0.0002989488,
        'l_max' : 0.0002992847,
        'l_SM' : 0.0002988245
    },
    {
        'maxcond' : 2.6904655862389435e-05,
        'theory prediction (fb)' : 0.0001937405,
        'upper limit (fb)' : 0.099176,
        'expected upper limit (fb)' : 0.095198,
        'TxNames' : ['TChiWZoff'],
        'Mass (GeV)' : [
            ('N2', 167.2),
            ('C1+/C1-', 161.5),
            ('N1', 143.0),
            ('N1/N1~', 143.0)
        ],
        'AnalysisID' : 'CMS-SUS-16-039-agg',
        'DataSetID' : 'AR5',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 35.9,
        'dataType' : 'efficiencyMap',
        'r' : 0.001953502,
        'r_expected' : 0.002035132,
        'Width (GeV)' : [
            ('N2', 5.2965e-06),
            ('C1+/C1-', 1.7883e-06),
            ('N1', 'stable'),
            ('N1/N1~', 'stable')
        ],
        'likelihood' : 0.2778715,
        'l_max' : 0.2788521,
        'l_SM' : 0.2777165
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0002919753,
        'upper limit (fb)' : 4.2419,
        'expected upper limit (fb)' : 5.5524,
        'TxNames' : ['T1'],
        'Mass (GeV)' : [('N3', 234.1), ('N2', 167.2), ('N1', 143.0)],
        'AnalysisID' : 'ATLAS-SUSY-2013-02',
        'DataSetID' : 'SR2jm',
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'efficiencyMap',
        'r' : 6.883125e-05,
        'r_expected' : 5.258542e-05,
        'Width (GeV)' : [
            ('N3', 0.003048),
            ('N2', 5.2965e-06),
            ('N1', 'stable')
        ],
        'likelihood' : 8.69208e-05,
        'l_max' : 8.692799e-05,
        'l_SM' : 8.692799e-05
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-16,ATLAS-SUSY-2019-09,CMS-SUS-13-012',
        'r' : 0.8126977,
        'r_expected' : 0.9489348,
        'likelihood' : 6.14219886085464e-42,
        'l_max' : 1.656737299500102e-41,
        'l_SM' : 1.5358129351403325e-41
    }
],
'Total xsec for missing topologies (fb)' : 9379.151,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3664.362,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1289.679,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1235.05,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 712.2367,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 603.7023,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 295.6839,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 215.3283,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 203.4741,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 203.4741,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 176.0261,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 9379.151,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3664.362,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1289.679,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1235.05,
        'SMS' : 'PV > (b,nu,l,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 712.2367,
        'SMS' : 'PV > (MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 603.7023,
        'SMS' : 'PV > (jet,jet,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 295.6839,
        'SMS' : 'PV > (b,nu,ta,MET), (b,nu,ta,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 215.3283,
        'SMS' : 'PV > (jet,jet,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 203.4741,
        'SMS' : 'PV > (jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 203.4741,
        'SMS' : 'PV > (nu,l,MET), (b,jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 176.0261,
        'SMS' : 'PV > (MET), (nu,l,MET)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 7940.649,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7652.886,
        'SMS' : 'PV > (b,jet,jet,MET), (b,nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 221.0362,
        'SMS' : 'PV > (jet,jet,MET), (jet,jet,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 52.31445,
        'SMS' : 'PV > (jet,jet,MET), (b,b,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11.86956,
        'SMS' : 'PV > (nu,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.48854,
        'SMS' : 'PV > (jet,jet,MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4857803,
        'SMS' : 'PV > (l,l,MET), (nu,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3356167,
        'SMS' : 'PV > (MET), (l,l,MET)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2326018,
        'SMS' : 'PV > (l,l,MET), (nu,ta,MET)'
    }
]
}
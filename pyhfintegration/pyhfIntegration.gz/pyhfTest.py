#!/usr/bin/env python3
import sys
sys.path.insert(0,"/home/alguero/Work/smodels")
import json
from pyhfInterface import PyhfData
from pyhfInterface import PyhfUpperLimitComputer
from smodels.experiment.databaseObj import Database
from smodels.tools.physicsUnits import pb, fb, GeV

# SUSY-2018-04
jsoninputs = []
with open("SUSY-2018-04_likelihoods/Region-combined/BkgOnly.json", "r") as f:
    jsoninputs.append(json.load(f))
effs = [0.00078238, 0.00077732]
lumi = 139
# Upper limit calculation
data = PyhfData(effs,
                            lumi,
                            jsoninputs)
ulcomputer = PyhfUpperLimitComputer(data)
result = ulcomputer.ulSigma()
print("sigma95 = ", result)
